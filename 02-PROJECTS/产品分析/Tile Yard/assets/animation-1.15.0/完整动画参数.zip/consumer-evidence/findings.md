# Tile Yard 1.15.0 道具动画：原生消费者与硬编码阶段

2026-11-24。来源：同构建ARM64 libil2cpp.so（SHA256 1e47be316de6cf32bcaad539059f272459b9e3d6cd1e119b0c446aa5abb5f4a0）、metadata（34c10212967c4d8dc4992d1270e9db679a94b07d1c7e8ae70c51ce9c03e6e69b）。Capstone直接读ELF+RELATIVE重定位，REA元数据父证据ev_3d9137470b39df0f142dcb47e9455ecc9b4a945647ab5b4518e0ae8f3e41ee0c；Cpp2IL DiffableCs仅补字段偏移/枚举，不当作方法体。全部时间为静态名义游戏时间，未实机测量。

## 0. 参数来源与绘图入口

实际Prefab值来自同目录上一级animation-parameters/serialized-components.json（主agent解析完整对象字节）：

| 路线 | speed | zoom | deflection | 消费方式 |
|---|---:|---:|---:|---|
| 棋盘奖励牌：Hint/Pickax/Boom9/Reshuffle/Automove |1.5|1|1|SpecialTileBehaviour；T=1/speed=0.666667秒|
| 底栏库存道具飞行 |1.7|0.6|0.4|DropPowerUp模板resources.assets/71127；T=0.588235秒|
| 开局Booster飞行 |1.7|0.3|0.4|DropBooster模板70606；之前还有0.3秒登场|

不要使用构造默认值替代以上值。SpecialTile与DropPowerUp构造默认均为deflection0.7、speed2.5、zoom0.5，但本包Prefab覆盖。

`animation-formulas.json`含101个相位样本，可直接画曲线。样本只为中性fromSize=1及对应toSize的演算，实际父级缩放仍需乘入；不是实测尺寸。

## 1. 共用缓动函数（已核原始指令）

以下先将输入夹到[0,1]，记c=clamp(t,0,1)：

- E2(t)=2c²(c<.5)，否则-1+(4-2c)c。AnimFunc.easeInOutQuad 0x3a4eb18。
- E3(t)=4c³(c<.5)，否则1+4(c-1)³。easeInOutCubic 0x3a4ebb0。
- E4(t)=8c⁴(c<.5)，否则1-8(c-1)⁴。easeInOutQuart 0x3a4ec68。
- E5(t)=16c⁵(c<.5)，否则1+16(c-1)⁵。easeInOutQuint 0x3a4ecf4。
- O3(t)=1+(c-1)³。easeOutCubic 0x3a4eb80。
- Exp(t)=2^(10c-10)。easeInExpo 0x3a4ed5c。这里没有“t=0直接返回0”的分支，因此Exp(0)=1/1024。ELF .rela.plt核对0x3fbb430→GOT0x42d03e8=exp2f、0x3fbb440→GOT0x42d03f0=sinf，未仅凭函数形状猜数学库。

## 2. 棋盘奖励牌：SpecialTileBehaviour

入口：HintFeature.FlyToTarget 0x3969424；PickaxFeature.FlyToTarget 0x396b52c；Boom9Feature.FlyToFieldPosition 0x396130c；ReshuffleFeature.FlyToFieldCenter 0x396c4bc，均创建SpecialTileBehaviour并Activate(机制回调)。

### 阶段时间轴

Active状态每帧t += speed*Time.deltaTime，Update 0x38785b0：

| 阶段 | 判定 | 本包speed1.5的名义时间 | 动作 |
|---|---|---:|---|
| Start | 组件Start |0|Init，随机一个_whooshSpecialSounds并Sounds.SoundPlay；振动code4=Effect_6|
| 飞行前段 |0<t<.75|0～0.500s|位移、放大、随机弯曲、整圈旋转同步推进|
| 预波纹 |跨过t=.75|0.500s|SpawnRipple，向目标屏幕位置追加相机波纹|
| 命中特效 |跨过t=.95|0.633s|SpawnEffect，实例化_effectTemplate并激活；振动code5=Effect_8|
| 机制生效 |跨过t=1|0.667s|FieldReaction或DropFieldReaction，调用_activator，然后Destroy飞行物并记录收集|

事件用old<=threshold且new>threshold判断，因此最多滞后一帧；.95FX比机制回调提前约0.0333s。效果模板可带自己的AudioSource/粒子，代码SpawnEffect此处没有额外Sounds.SoundPlay调用。

### 精确运动公式

记F=_fromPos、D=_toPos、s0=_fromSize、s1=_toSize、q=_flightZoom，a=_divpower∈[-deflection,+deflection]，n=normalize(Vector3.forward × (D-F))。Init 0x3877d44取起点localPosition+10*Vector3.back，s0=localScale.x，s1=s0/2；随机a<0时rotatedir=+1，否则-1。

```
t += speed * dt
P(t) = lerp(F,D,E3(t))
     + n * a * sin(pi*E2(t))
     + (0,0,-4 - 0.3*sin(pi*t))
S(t) = s0 + (s1-s0)*E4(t)
     + q*sin(pi*E2(t*t))
     + (q/5)*sin(pi*O3(t))^2
R(t) = identity之后绕Vector3.forward旋转(rotatedir*360*E5(t))度
```

证据：P主体0x3878b00～0x3878d70；S0x3878d74～0x3878e04；R0x3878e08～0x3878ed4。pi字面量0xcd1d54；-0.3字面量0xcd1f44。

这是位移、缩放、旋转分别取不同缓动，并叠加两次不同节奏的缩放波峰，不能用一条“EaseInOut”概括。中性s0=1/s1=.5/q=1时，101点抽样缩放峰值约1.532出现在t=.70（约0.467s）；这只是公式样例，实际s0跟棋盘及父级缩放有关。

### 目标和个体差异

- Hint：目标使用ITileBase的位置；效果资源由HintConfigSO._template决定，命中效果为YellowSharpImpact（主agent资源映射）。
- Pickax：目标在收藏槽时，设置TargetInCollector，逐帧追踪目标Transform并转到本地坐标；Reaction切为bulk3。命中棋盘目标时使用固定TargetFieldPos和默认bulk2。消费者0x396b52c、set_TargetInCollector0x3877f8c、Update0x3878a78～0x3878afc。
- Boom9：GetFieldPositions选出的坐标作为目标，传给TileToSpecialTile显式target重载；命中资源BlueShockwaveImpact。
- Reshuffle：把Field._fieldCenter经父Transform.InverseTransformPoint转为飞行目标；命中资源RiftExplosionPurple。激活前AcquireStateLock，回调之后进入棋盘牌的洗牌动画。
- 默认Reaction字符串为bulk2（构造0x3879058）；实际波形由Field/DropFieldCollector反应消费者产生，不凭这个字符串称为“屏幕震动”。

### 未使用奖励牌的销毁分支

Destroy(pausebefore) 0x3878f04只有Idle时生效：state=Destroy，t=-pausebefore。Update用t+=5*dt；t>=0后S=s0*(1-t³)，t跨1时在_fromPos实例化_effectIfNotUsed、Effect_8、记录并销毁。因计时速度为5，参数pausebefore不是直接秒：总名义时间=(pausebefore+1)/5，真正缩小阶段0.2秒，前置等待pausebefore/5。不要把参数名误当秒数。

## 3. 底栏库存道具：UIPowerUp → DropPowerUp

UseAndAnimate 0x3a7967c先Field.OnBeginPowerupUse，movingtype=1，设置UIPowerUpProperties.EffectCallBack，再从_icon.ImageWithShadow创建DropPowerUp。四种库存道具共享飞行模板；不与棋盘黄色奖励牌模板混淆。

FlyTo 0x3a56e10设fromSize=1、toSize=0、记录_startScale2；a从[-deflection,+deflection]抽取。若有EffectAppear则先在起点实例化；播放properties.SoundEffect，Effect_8。DOTween Sequence安排：

| 时间 | 本包speed1.7 | 动作 |
|---|---:|---|
|0|0|起点粒子、SoundEffect、Effect_8|
|.75/speed|.441176s|仅IsFieldEffect时追加Ripple|
|.95/speed|.558824s|FieldReaction(bulk2,2)或DropFieldReaction(bulk2)，在终点实例化properties.EffectPrefab|
|1/speed|.588235s|Effect_8，调用properties.EffectCallBack|

UIPowerUp回调0x3a79a3c销毁飞行GameObject、UpdateVisuals、movingtype=0，最终Field.PowerUpGo(properties.Index)。所以机制变化发生在飞行完成，命中特效先于机制约0.029412秒。

### DropPowerUp缩放与曲线

CalculateMoving2 0x3a57370，记t=_t1 += speed*dt：

```
Pxy(t) = lerp(Fxy,Dxy,E4(t))
       + normalize(forward × (D-F)).xy * a * sin(pi*E2(t))
worldZ每帧强制=-10
Sscalar(t) = 1 - E4(t)
           + 7*q*sin(pi*E2(sqrt(t*t*t)))
           + (q/3)*sin(pi*O3(t))^3
localScale = _startScale2 * Sscalar
TrailMaterial.color = (1,1,1, t - Exp(t))
```

对应0x3a573d0（E4位移）、0x3a575f0～0x3a576a4（缩放）、0x3a576a8～0x3a57700（拖尾alpha）。这是t^(3/2)及sin³，和SpecialTile的t²及sin²不同。先构造的z偏移随后被worldZ=-10覆盖，所以绘2D轨迹应展示XY。没有看到该消费者额外旋转图标；不能套SpecialTile的整圈旋转。

中性_startScale2=1、q=.6抽样标量峰值约4.357在t=.62；它是UI来源比例的乘数，不能说屏幕上图标达到棋盘牌4.357倍。开局Booster使用q=.3，峰值减弱。

## 4. 开局Booster：先展示再飞行

BoosterApplier.Show 0x3a4f890：GameObject/icon激活；DOTween Sequence同时将CanvasGroup.alpha从0到1、icon.localScale从.5到1，duration均硬编码.3秒，缩放Ease.OutBack=27（本包DOTween枚举核对）。在.06秒InsertCallback实例化_effectAppear；Sequence完成才调用onCompleted。

FlyTo 0x3a4f6e0复用DropPowerUp，隐藏原icon，完成回调先Destroy飞行物再调用onFlown。实际累计：登场0.300s → 波纹0.741176s → 命中FX0.858824s → 机制开始0.888235s。FadeOutAndDeactivate 0x3a4f838的方法名虽像淡出，本构建方法体实际仅新建并返回空Sequence；不能据名字宣称背光做0.2秒淡出。

## 5. RemoveColor连发节奏与目标弹出

RemoveColorBooster.Animate 0x3a6fc38保存activateOne回调，timer初始设为_speed。Update 0x3a6fc60只有未Finished且“收藏槽全部静止或仍有空位”时推进；timer<_speed只加dt，达到阈值的下一次检查才timer=0并调用activateOne，一帧至多一张；回调返回false即清理_active并OnFinished。

本包_speed=.05秒是每牌投放间隔阈值，不能写成飞行速度20单位/秒或固定精确20张/秒。首张可立即，之后有帧量化且收藏槽阻塞会延长。连发只是启动间隔，不等于每张视觉动画只有.05秒。

DropTileRemoveColor.CalculateMoving 0x3a5b17c把其总体进度分为弹出、原位等待、普通飞行三段。Init计算appearRatio=_appearTime/_dropFlightTime、pauseRatio=_pauseTime/_dropFlightTime；注意第二值是第二边界，不是appear+pause。实际参数_dropFlightTime=1、appearTime=.07、pauseTime=.2：0～.07s弹出；.07～.20s原位；.20～1s走基类DropTile运动。

UpdatePopping0x3a5b20c先基类CalculateMoving(0)固定起点；被目标集合标记的牌额外S=fromSize*(1+0.2*sin(pi*u))，其中u为弹出段归一化相位；u>=.3且尚未播效时只实例化一次_effectAppear，故初始名义约.021s启动该FX。是否被标记由field配置数组决定，不能说每张所有对象都必弹。

基类DropTile/Tile共享移动、撤回、洗牌及消除公式由另一Agent核对，本文只保留已导出原始证据affected-tiles*.txt供交叉复核，主报告避免重复录两套公式。

## 6. 波纹：相机效果引用

SpecialTile.SpawnRipple0x38783c4不是实例化独立Prefab：把_toPos转世界后经ICameraService slot6转屏幕/viewport，GameObject.Find("Main Camera")→GetComponent<Camera>()→gameObject.GetComponent<RippleEffect>()→AppendRipple(x,y)。库存DropPowerUp的.75T回调则从field相机Component取RippleEffect。

本包关内MainCamera=level1/pathID363，序列化speed1.3、power.03、radius.4、scale.5、reflectionStrength1；其它场景不混用。

Droplet.Update 0x3734098及RippleEffect.Update 0x3733e1c内联执行 `age += _speed*Time.deltaTime`；AppendRipple 0x37340cc起始age=0，打开组件。IsPlaying 0x373430c判`age<2`，Update内的RemoveAll谓词0x3734390移除age>=2者，列表空时停用组件。因此_speed单位是“相位/游戏秒”，不是世界距离/秒；本包名义保留时长`2/1.3=1.538462s`（帧量化）。

MakeShaderParameter 0x3733cbc和UpdateShaderParameters中的内联版本把年龄夹到[0,1]，并传Vector4(x*aspect,y,clamp(age),0)。本包前`1/1.3=.769231s`相位从0推进到1，后`.769231s`保持传入1直至移除。不要用保留时长直接绘制均匀0～1相位。

```
age = 1.3 * elapsedGameSeconds
alive = age < 2
shaderPhase = clamp(age, 0, 1)
_Drop1 = (inputX * cameraAspect, inputY, shaderPhase, 0)
_Params1 = (cameraAspect, 1, _power, _radius)
         = (cameraAspect, 1, .03, .4)
_Params2 = (1, 1/cameraAspect, 1/_scale, _reflectionStrength)
         = (1, 1/cameraAspect, 2, 1)
_Reflection = _reflectionColor
```

参数写入0x3733c04～0x3733c90。循环上限明确`Math.Min(_droplets.Count,1)`（0x3733b48～0x3733b5c），所以本构建只向材质写首个_Drop1，即使列表可存多项；不能据List宣称多处波纹同时叠加。首个波纹移除后下一项会以已推进的age接替；这是消费者推论，未做实机重叠验证。

Awake 0x3733ce4只验证_gradTexture/_fadeTexture存在，创建Material，将其分别赋给`_GradTex`/`_FadeTex`；OnRenderImage 0x37341f8用该Material Graphics.Blit。检查本类全部运行方法，无读取_waveform@0x20或_fadeform@0x28，也无AnimationCurve.Evaluate或生成Texture2D的方法。故序列化7key/3key是保留曲线数据，当前运行消费者实际输入是预置纹理；尚不能证明这两张纹理必然由这两条曲线生成。

_radius=.4与_scale=.5目前只能精确表述为Shader输入及倒数映射；CPU没有据radius设终止或世界半径公式。波前半径/扰动衰减的最终空间公式需要对应Shader，不能将.4当作0.4米或40%屏宽。

### 命中特效根Transform：两条路线的父缩放处理不同

SpecialTileBehaviour.SpawnEffect 0x38781bc执行单参`Object.Instantiate<GameObject>(_effectTemplate)`（0x3878260；泛型0x2070d74→Internal_CloneSingle）；先设根`position = 飞行SpecialTile当前transform.position`（0x387828c～29c），然后`parent = _field.transform.parent`（0x38782c0～2e0）。注意没有直接用_toPos，.95阈值触发处调用先于本帧运动公式更新，效果生成点来自飞行物当时已有的世界位置。

`Transform.set_parent`0x3d3ccc0在0x3d3cd80明确将worldPositionStays传true。因此此层没有额外尺寸曲线或`set_localScale`；根重挂父级时保留原世界Transform，局部缩放由父级逆补偿。按根Prefab尺度Yellow1、Small1、Blue1、Rift.7、Auto1.2，单独克隆时的根世界尺度为这些值；重挂父级当下仍保留，而不能把Prefab根值直接称为最终localScale。粒子自身模块和子节点缩放仍需分别乘入。

库存DropPowerUp的.95回调0x3a577f4则执行`Object.Instantiate<ParticleSystem>(properties.EffectPrefab, _field.transform.parent)`（0x3a57924～930），泛型包装0x2070fdc在0x2071040明确转为三参Instantiate并传worldPositionStays=false；随后根`position = _toPos`（世界坐标setter0x3a57950～95c）。该消费者也没有`set_localScale`，所以根localScale沿用Prefab，世界尺度受父级层级相乘。与前一条保留世界尺度的路线不能合并描述。

用统一缩放、无旋转/剪切的简化场景表达：令p为Prefab根尺度、g为field父级世界尺度；SpecialTile命中特效生成后worldScale=p、localScale=p/g；库存命中特效localScale=p、worldScale=g*p。一般非均匀缩放/旋转层级应以Transform矩阵为准。原始证据effect-root-instantiation.txt同时保存两种Instantiate包装和set_parent，避免只凭Unity API习惯推断。

## 7. 击打感构成与结论边界

代码支持的组合为：曲线路径与尺寸变化 + 旋转（仅SpecialTile路线）+ 目标前置波纹 + .95相位的粒子/反应 + 1相位的机制回调 + 分段震动。效果Prefab自身粒子和AudioSource参数由主agent资源证据承接。

振动code4/5在VibrationEffectPredefines中分别名为Effect_6/Effect_8；本轮没还原设备平台的实际脉冲波形，不能直接翻成“轻震/重震”或毫秒长度。函数和参数只能证明配置与消费，真实帧率、TimeScale、安全区/父缩放下屏幕大小和主观手感仍需实机。

## 证据文件

- easing-and-imports.txt：缓动函数、exp2f/sinf的PLT/GOT绑定。
- specialtile-native.txt / specialtile-annotated.txt：共用奖励牌原始指令及元数据注释。
- feature-visual-wrappers.txt：Hint/Pickax/Boom9/Reshuffle适配到共用消费者。
- inventory-powerup*.txt、closures-DropPowerUp.txt：库存道具、回调与时间点。
- booster*.txt、closures-BoosterApplier.txt：登场OutBack、飞行、RemoveColor逐牌门控与目标弹出。
- target-motion*.txt、closures-各Algorithm.txt：机制回调及目标激活；只作为证据，不冒充全部已解释。
- animation-formulas.json：带假设的绘图演算输入和101相位样本。
- ripple-native.txt / ripple-annotated.txt：Ripple全类、Droplet及RemoveAll谓词原始指令。
- effect-root-instantiation.txt：特效根位置、parent、worldPositionStays与无额外localScale覆盖的证据。

