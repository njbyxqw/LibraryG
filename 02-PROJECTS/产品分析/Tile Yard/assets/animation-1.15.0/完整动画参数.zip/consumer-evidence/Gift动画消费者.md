# Gift 原盘礼物的动画消费者

Tile Yard Android 1.15.0 静态证据，2026-11-24。这里的 Gift 为 `Nevosoft.TY.Core.GiftFeature / GiftBehaviour`，不是 `SpecialTile`、库存道具，也不是外围礼物弹窗。原生方法未设置固定缩放／速度曲线，而是驱动 Animator 参数；实际变换曲线需与 GiftConfigSO.Template 所指 Prefab／AnimatorController／AnimationClip 对位。

## 绑定与初始化

- `GiftConfigSO.get_Template 0x3966a3c` 返回 `_template`（内存字段0x18，GiftBehaviour引用）。
- `GiftFeature.SpawnPawn 0x3966c84`：已有可用 pawn则返回；否则从 Config.Template 实例化，`AttachTo(_tile)`，再同步 availability。
- `GiftBehaviour.Awake 0x3966220`：使用序列化 `_animator`；若Unity对象无效则从本对象 GetComponent<Animator> 补取。
- `GiftBehaviour.AttachTo 0x39662f8`：挂在 Tile 的 Transform 下，localScale=Vector3.one、localPosition=Vector3.zero，然后设 Animator 参数。

| 参数 | Animator API | 原生赋值 |
|---|---|---|
| `skin` | SetInteger | `CountOf(FeatureTag.HasObstacle)<2 ? 1 : 0` |
| `withBow` | SetBool | `CountOf(FeatureTag.HasObstacle)>1 || Has(FeatureTag.HasBonus)` |
| `available` | SetBool | `GiftFeature.SetPawnAvailability` 把 `Tile.IsTileOrObstacleAvailable` 传入 `GiftBehaviour.SetAvailable` |

`skin`、`withBow` 由共存特征决定，不宜仅按名称解释为随机颜色皮肤或固定装饰。

## 出现

`GiftFeature.StartLevelAction(delay) 0x3967378` 先 SpawnPawn，再启动 pawn.Appear_cr(delay)。

`GiftBehaviour.Appear(delay) 0x3966734` 同样启动 Appear_cr；迭代器创建函数 `0x3966754`；真正消费者 `MoveNext 0x396691c`：

1. `yield return new WaitForSeconds(delay)`；这是调用者提供的游戏时间等待，不是Appear Clip的固定时长。
2. `Animator.SetTrigger("appear")`。
3. 结束协程。

没有在这段消费者中调用 Animator.Play、设置 normalizedTime 或覆盖 Animator.speed；Appear 的具体缩放与速度取决于Controller/Clip。

## 消失及回调

`GiftFeature.OnRemove 0x3967458` 在pawn存在时执行基类虚调用，然后让pawn脱离Tile、调用 `GiftBehaviour.Disappear(finalizer,newParent)`，清空自身pawn引用并上报障碍销毁。传入的缓存finalizer为 `<OnRemove>b__15_0 (0x39677e0)`，方法体只有ret，为空动作。

`GiftBehaviour.Disappear 0x39667f8` 顺序：

1. `transform.parent=newParent`，保留为另一父节点下的视觉对象。
2. 若已有 `_destroyCallback`，先调用旧回调。
3. 保存本次 finalizer。
4. `Animator.SetTrigger("disappear")`。

`GiftBehaviour.OnDisappear 0x39668a4`：`Destroy(gameObject)`。这应由动画事件或状态逻辑调用；事件是否在每个对应Clip中存在由资源解析核对。

`GiftBehaviour.OnDestroy 0x39662c4`：如destroyCallback非空则执行，然后清空。注意OnDisappear本身不直接调用finalizer，析构回调才执行。

`GiftFeature.EndLevelAction(delay) 0x39673bc` 也启动协程；其 `MoveNext 0x3967674` 等 `WaitForSeconds(delay)` 后调用OnRemove，随后才触发视觉消失。关卡结束延迟和Disappear Clip的时长是两层时间，不能合成一个未经绑定验证的固定数值。

## 方法／参数证据

- `available` 字符串来自 GOT `0x42a1688`。
- `skin` 字符串来自 GOT `0x427e8f0`。
- `withBow` 字符串来自 GOT `0x42a8680`。
- `appear` 字符串来自 GOT `0x42a16a8`。
- `disappear` 字符串来自 GOT `0x42a16a0`。
- 本目录数字文件名即IL2CPP方法索引，如 `18950.asm`（AttachTo）、`18954.asm`（Disappear）、`18959.asm`（Appear迭代器）、`18982.asm`（关卡结束迭代器）。

结论范围：代码只确认以上Animator输入和回调，不据此填造appearance/disappearance的曲线、时长、粒子和音效。无需把Gift误放进SpecialTile的DOTween曲线表。
