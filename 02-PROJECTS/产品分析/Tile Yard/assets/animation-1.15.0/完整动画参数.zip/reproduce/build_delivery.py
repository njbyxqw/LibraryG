"""Package evidence and plot recovered animation curves; no game rendering."""
import json,math,collections,hashlib,zipfile,csv,io
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from extract_serialized import ROOT,OUT

DEST=Path(r'D:\LibraryG\02-PROJECTS\产品分析\Tile Yard\assets\animation-1.15.0')
DEST.mkdir(parents=True,exist_ok=True)
plt.rcParams['font.sans-serif']=['Microsoft YaHei','DejaVu Sans']
plt.rcParams['axes.unicode_minus']=False
plt.rcParams['axes.spines.top']=False
plt.rcParams['axes.spines.right']=False
plt.rcParams['figure.facecolor']='#f8fafc'

def cubic(t):return np.where(t<.5,4*t**3,1-(-2*t+2)**3/2)
def quart(t):return np.where(t<.5,8*t**4,1-(-2*t+2)**4/2)
def quint(t):return np.where(t<.5,16*t**5,1-(-2*t+2)**5/2)
def quad(t):return np.where(t<.5,2*t*t,1-(-2*t+2)**2/2)

def curve_at(curve,t):
    keys=curve.get('keys',curve.get('m_Curve',[]))
    if not keys:return 0.0
    if t<=keys[0]['time']:return keys[0]['value']
    if t>=keys[-1]['time']:return keys[-1]['value']
    for a,b in zip(keys,keys[1:]):
        if a['time']<=t<=b['time']:break
    dt=b['time']-a['time'];u=(t-a['time'])/dt
    m0=a['outSlope'];m1=b['inSlope']
    if isinstance(m0,str) or isinstance(m1,str):return a['value']
    wm0=a.get('weightedMode',0);wm1=b.get('weightedMode',0)
    if wm0&2 or wm1&1:
        w0=a.get('outWeight',1/3) if wm0&2 else 1/3
        w1=b.get('inWeight',1/3) if wm1&1 else 1/3
        lo,hi=0.0,1.0
        for _ in range(45):
            q=(lo+hi)/2;x=3*(1-q)**2*q*w0+3*(1-q)*q*q*(1-w1)+q**3
            if x<u:lo=q
            else:hi=q
        q=(lo+hi)/2
        return (1-q)**3*a['value']+3*(1-q)**2*q*(a['value']+m0*dt*w0)+3*(1-q)*q*q*(b['value']-m1*dt*w1)+q**3*b['value']
    return (2*u**3-3*u*u+1)*a['value']+(u**3-2*u*u+u)*dt*m0+(-2*u**3+3*u*u)*b['value']+(u**3-u*u)*dt*m1

def main():
    rows=json.loads((OUT/'serialized-components.json').read_text(encoding='utf-8'))
    details=json.loads((OUT/'effect-components.json').read_text(encoding='utf-8'))
    custom=json.loads((OUT/'effect-custom-scripts.json').read_text(encoding='utf-8'))
    used={(x['file'],x['path_id']) for x in custom}
    core=[x for x in rows if x['class']!='DestroySoundAfterPlay' and (x['class']!='SoundRandomPitch' or (x['file'],x['path_id']) in used) and not (x['class']=='RippleEffect' and x['file']!='level1') and x['class']!='AnimFunc']
    refs=json.loads((OUT/'effect-references.json').read_text(encoding='utf-8'))
    graphs=json.loads((OUT/'effect-hierarchies.json').read_text(encoding='utf-8'))
    particle_rows=[]
    for k,x in details.items():
        if x['type']!='ParticleSystem':continue
        groups=[]
        for g in graphs:
            for h in g['hierarchy']:
                if (h['file'],h['path_id'])==(x['file'],x['path_id']):groups.append(h['path'])
        particle_rows.append({**x,'paths':sorted(set(groups))})
    trails=[x for x in details.values() if x['type']=='TrailRenderer']
    sounds=[x for x in details.values() if x['type']=='AudioSource']
    curves={}
    for x in core:
        for k,v in x['data'].items():
            if isinstance(v,dict) and 'keys' in v:curves[f"{x['file']}:{x['path_id']}:{k}"]=v
    manifest={'product':'Tile Yard','version':'1.15.0 (9872)','date':'2026-11-24','source':'User XAPK','xapk_sha256':'158aef95a7dadb405f836b053cc0481fe9007760d454e34ef0663c55e9def4e2','evidence':'static serialized values + native consumers; no runtime observation','counts':{'core_components':len(core),'particle_systems':len(particle_rows),'trail_renderers':len(trails),'audio_sources':len(sounds)},'curve_evaluation':'Hermite with slopes; weighted Bezier if weightedMode requests it. Main MonoBehaviour curves are unweighted. Plots are formula evaluation, not game footage.'}
    payloads={'manifest.json':manifest,'core-components.json':core,'curve-keyframes.json':curves,'particle-systems.json':particle_rows,'trail-renderers.json':trails,'audio-sources.json':sounds,'effect-bindings.json':refs,'effect-hierarchies.json':graphs,'selected-hierarchy-components.json':details}
    native=ROOT/'04-ReverseEngineering/animation-native/animation-formulas.json'
    if native.exists():payloads['native-formulas.json']=json.loads(native.read_text(encoding='utf-8'))
    for fn in ['gift-clip-curves.json','gift-controller-states.json','_gradTexture-samples.json','_fadeTexture-samples.json']:
        if (OUT/fn).exists():payloads[fn]=json.loads((OUT/fn).read_text(encoding='utf-8'))
    manifest['counts']['gift_animation_clips']=len(payloads.get('gift-clip-curves.json',[]))
    main_data={'manifest':manifest,'components':core,'curve_keyframes':curves}
    (DEST/'核心动画参数.json').write_text(json.dumps(main_data,ensure_ascii=False,indent=2),encoding='utf-8')
    with zipfile.ZipFile(DEST/'完整动画参数.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        digests={}
        for name,data in payloads.items():
            raw=json.dumps(data,ensure_ascii=False,indent=2).encode('utf-8');z.writestr(name,raw);digests[name]=hashlib.sha256(raw).hexdigest()
        for p in [OUT/'extract_serialized.py',OUT/'extract_effect_graph.py',OUT/'decode_gift_clips.py',Path(__file__)]:
            raw=p.read_bytes();name='reproduce/'+p.name;z.writestr(name,raw);digests[name]=hashlib.sha256(raw).hexdigest()
        for p in [ROOT/'04-ReverseEngineering/animation-native/findings.md',ROOT/'04-ReverseEngineering/animation-shared/共享运动与打击反馈.md',ROOT/'04-ReverseEngineering/animation-shared/gift/Gift动画消费者.md',ROOT/'04-ReverseEngineering/animation-native/extra-slot-native.txt']:
            if p.exists():
                raw=p.read_bytes();name='consumer-evidence/'+p.name;z.writestr(name,raw);digests[name]=hashlib.sha256(raw).hexdigest()
        z.writestr('contents-sha256.json',json.dumps(digests,ensure_ascii=False,indent=2))
    t=np.linspace(0,1,1201)
    scene=next(x for x in rows if x['file']=='level1' and x['path_id']==428)['data']
    last=next(x for x in rows if x['file']=='level1' and x['path_id']==436)['data']
    z=np.array([curve_at(scene['_zoomCurve'],a) for a in t]);zl=np.array([curve_at(last['_zoomCurve'],a) for a in t])
    fig,axs=plt.subplots(2,2,figsize=(14,9),layout='constrained')
    ax=axs[0,0]
    for y,l in [(cubic(t),'普通入槽：InOutCubic'),(quart(t),'尺寸基底：InOutQuart'),(quint(t),'整圈旋转：InOutQuint'),(cubic(1-(1-t)**3),'末张位移：Cubic(OutCubic)')]:ax.plot(t,y,label=l,lw=2)
    ax.set(title='不同运动通道采用不同的缓动',xlabel='归一化相位 p',ylabel='进度');ax.legend(fontsize=9)
    ax=axs[0,1];ax.plot(t,z*.25,label='普通牌：0.25 × zoomCurve',lw=2);ax.plot(t,zl*.9,label='末张牌：0.90 × zoomCurve',lw=2)
    ax.set(title='飞行鼓包是加到绝对缩放上的增量',xlabel='归一化时间 p',ylabel='额外缩放量 ΔS');ax.legend(fontsize=9)
    ax=axs[1,0];ax.plot(t*.5,1+1.25*.17*np.sin(np.pi*t),lw=2,label='洗牌：最大 1.2125 倍');ax.axvline(.075,color='#b45309',ls='--',label='换色阈值：0.15 / 2 = 75 ms')
    ax.plot(t*.1,1-t**3,lw=2,label='普通三消：100 ms 收缩');ax.set(title='洗牌与消除的节奏差异',xlabel='游戏时间（秒）',ylabel='相对基准大小');ax.legend(fontsize=9)
    ax=axs[1,1]
    for a,l in [(.015,'普通落槽 bulk2'),(.04,'三消 bulk'),(.08,'镐子命中槽牌 bulk3'),(.15,'bulk4（通道存在，未证本次道具调用）')]:ax.plot(t*.4,1+a*np.sin(-2.5*np.pi*t)*(1-t)**2,label=l,lw=2)
    ax.axhline(1,color='#94a3b8',lw=.8);ax.set(title='整槽先压后回弹：四档阻尼脉冲',xlabel='触发后的游戏时间（秒）',ylabel='槽容器缩放倍率');ax.legend(fontsize=9)
    for ax in axs.flat:ax.grid(alpha=.15)
    fig.suptitle('Tile Yard 1.15.0 · 缩放与速度曲线\n包内实际参数＋已核消费者的数学复算；非实机帧序列',fontsize=17)
    fig.savefig(DEST/'缩放与速度曲线.png',dpi=160);plt.close(fig)
    fig,axs=plt.subplots(2,2,figsize=(14,8),layout='constrained')
    axs[0,0].plot(t/1.5,cubic(t),label='黄色奖励牌：InOutCubic',lw=2)
    axs[0,0].plot(t/1.7,quart(t),label='库存道具：InOutQuart',lw=2)
    axs[0,0].set(title='主位移进度',xlabel='游戏时间（秒）',ylabel='起点到终点的进度')
    axs[0,1].plot(t/1.5,np.gradient(cubic(t),t/1.5),label='黄色奖励牌：峰值 4.5 /s',lw=2)
    axs[0,1].plot(t/1.7,np.gradient(quart(t),t/1.7),label='库存道具：峰值 6.8 /s',lw=2)
    axs[0,1].set(title='主位移速度（曲线一阶导数）',xlabel='游戏时间（秒）',ylabel='每秒通过的起终点距离倍数')
    special=1-.5*quart(t)+np.sin(np.pi*quad(t*t))+.2*np.sin(np.pi*(1-(1-t)**3))**2
    def stock(q):return 1-quart(t)+7*q*np.sin(np.pi*quad(t**1.5))+(q/3)*np.sin(np.pi*(1-(1-t)**3))**3
    axs[1,0].plot(t/1.5,special,label='假设起点 S=1、终点 S=0.5',lw=2)
    axs[1,0].set(title='黄色奖励牌：绝对缩放公式示例',xlabel='游戏时间（秒）',ylabel='绝对 localScale 标量（示例单位）')
    axs[1,1].plot(t/1.7,stock(.6),label='库存道具 q=0.6',lw=2);axs[1,1].plot(t/1.7,stock(.3),label='开局 Booster q=0.3',lw=2)
    axs[1,1].set(title='UI 飞行物：独立比例乘数',xlabel='起飞后的游戏时间（秒）',ylabel='相对起始 UI localScale 的乘数')
    for ax in axs.flat:ax.grid(alpha=.15);ax.legend(fontsize=9)
    fig.suptitle('飞行轨迹速度与两种缩放公式\n速度不含侧偏；两条缩放路线单位不同，不能直接当屏幕大小比较',fontsize=16)
    fig.savefig(DEST/'道具飞行缩放与速度.png',dpi=160);plt.close(fig)
    # Particle curves: preserve first moment, rapid impact and decay on independent lifetime axes.
    fig,axs=plt.subplots(1,2,figsize=(14,4.6),layout='constrained')
    for key,label in [('resources.assets:28328','魔杖 YellowSharpImpact'),('resources.assets:28333','3×3 BlueShockwaveImpact'),('resources.assets:28423','洗牌 RiftExplosionPurple')]:
        d=details[key]['data'];mm=d['SizeModule']['curve'];cc=mm['maxCurve'];values=np.array([curve_at(cc,float(v)) for v in t])*mm['scalar'];axs[0].plot(t,values,label=label,lw=2)
    axs[0].set(title='核心粒子 Size over Lifetime',xlabel='单粒子归一化寿命',ylabel='初始粒径的乘数');axs[0].legend(fontsize=9)
    for key,label in [('resources.assets:28323','魔杖闪光 Glow：0.15s'),('resources.assets:28509','魔杖尘屑 Dust：0.15–1.30s'),('resources.assets:28331','魔杖线条 Lines：0.15–0.30s')]:
        mm=details[key]['data']['SizeModule']['curve'];values=np.array([curve_at(mm['maxCurve'],float(v)) for v in t])*mm['scalar'];axs[1].plot(t,values,label=label,lw=2)
    axs[1].set(title='冲击层迅速扩张，闪光与尘屑衰减',xlabel='各自单粒子的归一化寿命',ylabel='初始粒径的乘数');axs[1].legend(fontsize=9)
    for ax in axs:ax.grid(alpha=.15)
    fig.suptitle('粒子曲线按各自寿命求值；不把发射器 duration 当可见时间',fontsize=15);fig.savefig(DEST/'命中粒子缩放曲线.png',dpi=160);plt.close(fig)
    fig,ax=plt.subplots(figsize=(14,3.5),layout='constrained')
    tracks=[('棋盘黄色道具',0,1/1.5,[(.75/1.5,'涟漪'),(.95/1.5,'特效／震动'),(1/1.5,'机制')]),('库存道具',0,1/1.7,[(.75/1.7,'涟漪'),(.95/1.7,'特效'),(1/1.7,'机制')]),('加槽／超级魔杖',.3,.3+1/1.7,[(.06,'出现特效'),(.3,'起飞'),(.3+.75/1.7,'涟漪'),(.3+.95/1.7,'特效'),(.3+1/1.7,'机制')])]
    for y,(name,start,end,events) in enumerate(tracks):
        ax.barh(y,end-start,left=start,height=.25,color=['#38bdf8','#a78bfa','#fb923c'][y],alpha=.7)
        if start:ax.barh(y,start,left=0,height=.25,color='#fed7aa',alpha=.7)
        for i,(tm,label) in enumerate(events):
            ax.plot(tm,y,'o',color='#162c40',ms=5);ax.annotate(f'{label}\n{tm*1000:.0f} ms',(tm,y),xytext=(0,18 if i%2 else -34),textcoords='offset points',ha='center',fontsize=8)
    ax.set_yticks(range(3),[x[0] for x in tracks]);ax.invert_yaxis();ax.set_xlim(-.015,1.02);ax.set_xlabel('从开始后的游戏时间（秒）');ax.grid(axis='x',alpha=.15)
    fig.suptitle('命中特效先于机制回调：约 29–33 ms 的名义间隔\nTime.deltaTime 驱动；实际阈值触发受帧率量化影响',fontsize=15);fig.savefig(DEST/'道具命中时序.png',dpi=160);plt.close(fig)
    # Gift Animator uses optimized streamed polynomial segments, not the flight formula.
    def gift_eval(ch,t):
        if ch['storage']=='constant':return ch['value']
        if ch['storage']=='dense':
            i=max(0,min(len(ch['values'])-1,int(round((t-ch['begin'])*ch['sample_rate']))));return ch['values'][i]
        keys=ch['keys'];k=keys[0]
        for v in keys:
            if v['time']<=t:k=v
            else:break
        dt=max(0,t-k['time']);a,b,c,d=k['coefficients'];return ((a*dt+b)*dt+c)*dt+d
    gift=payloads.get('gift-clip-curves.json',[])
    if gift:
        fig,axs=plt.subplots(1,2,figsize=(14,4.4),layout='constrained')
        for clipname,at in [('Gift-Open-bow',0),('Gift-Disappear',1)]:
            clip=next(x for x in gift if x['name']==clipname);tt=np.linspace(0,clip['stop'],601)
            for b in clip['bindings']:
                if b['attribute']!='localScale' or all(c['storage']=='constant' for c in b['channels']):continue
                for axis in range(min(2,len(b['channels']))):
                    label=(b['path'].replace('path-hash:1989126404','tile（路径哈希）'))+'.'+('xy'[axis]);axs[at].plot(tt,[gift_eval(b['channels'][axis],float(t)) for t in tt],label=label,lw=2,ls='-' if axis==0 else '--')
            axs[at].set(title=clipname,xlabel='Clip 内时间（秒）',ylabel='节点 localScale');axs[at].grid(alpha=.15);axs[at].legend(fontsize=9)
        fig.suptitle('礼物的烘焙缩放曲线 · Controller 状态 speed=1\n优化流多项式复算；不代表多层 Animator 混合后的实机画面',fontsize=15);fig.savefig(DEST/'礼物缩放曲线.png',dpi=160);plt.close(fig)
    # Human-readable complete particle/trail/audio index; the ZIP keeps all module curves.
    def f(v):return f'{v:.6g}' if isinstance(v,(int,float)) else str(v)
    def mm(v):
        state=v.get('minMaxState',0)
        if state==0:return f(v['scalar'])
        if state==3:return f(v['minScalar'])+'–'+f(v['scalar'])
        return ('Curve' if state==1 else 'TwoCurves')+' × '+f(v['scalar'])
    lines=['---','title: Tile Yard 局内动画粒子拖尾音效附表-1.15.0','date: 2026-11-24','type: reference','status: needs-review','tags: [TileYard, 动画, 证据]','---','','# 粒子、拖尾与音效参数附表','','同版本包内静态值；没有运行观测。93个ParticleSystem是相关层级中的存在量，不是同时播放量。完整字段和关键帧见同目录`完整动画参数.zip`。','','## 粒子系统','','寿命、延迟为游戏秒；速度/大小是粒子系统局部单位，须结合scalingMode、Transform、父级和相机。mode=0只用scalar，mode=3为minScalar至scalar，不把无效minScalar当下限。','','| 关联层级 | 对象ID | Duration / SimSpeed | 延迟 | 单粒子寿命 | 初速 | 初始大小 | 发射 / 大小模块 | Burst时间:数量 |','|---|---|---|---|---|---|---|---|---|']
    for x in sorted(particle_rows,key=lambda x:x['paths']):
        d=x['data'];i=d['InitialModule'];burst=', '.join(f(b['time'])+':'+mm(b['countCurve']) for b in d['EmissionModule']['m_Bursts']) or '—'
        path='<br>'.join(x['paths']);lines.append(f"| {path} | {x['file']}:{x['path_id']} | {f(d['lengthInSec'])} / {f(d['simulationSpeed'])} | {mm(d['startDelay'])} | {mm(i['startLifetime'])} | {mm(i['startSpeed'])} | {mm(i['startSize'])} | {d['EmissionModule']['enabled']} / {d['SizeModule']['enabled']} | {burst} |")
    lines+=['','## 拖尾','','| 文件:对象ID | 对象 | Time | MinVertexDistance | WidthMultiplier | WidthCurve (t,value,inSlope,outSlope) |','|---|---|---|---|---|---|']
    for x in trails:
        d=x['data'];p=d['m_Parameters'];keys='; '.join('('+','.join(f(k[q]) for q in ['time','value','inSlope','outSlope'])+')' for k in p['widthCurve']['m_Curve']);lines.append(f"| {x['file']}:{x['path_id']} | {x['gameobject']} | {f(d['m_Time'])} | {f(d['m_MinVertexDistance'])} | {f(p['widthMultiplier'])} | {keys} |")
    lines+=['','## AudioSource','','静态音量和pitch不等于实际混音响度；SoundRandomPitch可能在运行时覆盖pitch。没有恢复扬声器、Mixer与设备振动的声压／脉冲参数。','','| 文件:对象ID | 对象 | AudioClip PPtr | Volume | Pitch | PlayOnAwake | Loop / Mute |','|---|---|---|---|---|---|---|']
    for x in sounds:
        d=x['data'];p=d['m_audioClip'];lines.append(f"| {x['file']}:{x['path_id']} | {x['gameobject']} | {p['m_FileID']}:{p['m_PathID']} | {f(d['m_Volume'])} | {f(d['m_Pitch'])} | {d['m_PlayOnAwake']} | {d['Loop']} / {d['Mute']} |")
    lines+=['','## 关联','','- [[02-PROJECTS/产品分析/Tile Yard/游戏逻辑/局内道具动画参数-1.15.0|动画主报告]]','- [[02-PROJECTS/产品分析/Tile Yard/_MOC|Tile Yard 入口]]','']
    (DEST/'粒子拖尾音效附表.md').write_text('\n'.join(lines),encoding='utf-8')
    (DEST/'参数清单.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False))
    print('delivery',[(x.name,x.stat().st_size) for x in DEST.iterdir()])

if __name__=='__main__':main()
