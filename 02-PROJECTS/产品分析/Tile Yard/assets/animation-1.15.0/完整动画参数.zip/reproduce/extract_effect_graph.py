import json,re,math,collections
from pathlib import Path
import UnityPy
from UnityPy.classes.PPtr import PPtr
from extract_serialized import ROOT,OUT,normalize

def main():
    e=UnityPy.load(str(ROOT/'01-Decoded/assets/bin/Data/data.unity3d'))
    objects={(o.assets_file.name,o.path_id):o for o in e.objects}
    rows=json.loads((OUT/'serialized-components.json').read_text(encoding='utf-8'))
    roots={};pointers=[]
    def resolve(source,p):
        try:return PPtr(m_FileID=p['file_id'],m_PathID=p['path_id'],assetsfile=source.assets_file).deref()
        except:return None
    def key(o):return (o.assets_file.name,o.path_id)
    def label(o):
        d=o.read(check_read=False)
        try:go=d.m_GameObject.read().m_Name
        except:go=None
        return {'file':o.assets_file.name,'path_id':o.path_id,'type':o.type.name,'name':getattr(d,'m_Name',None),'gameobject':go}
    def as_go(o):
        if o.type.name=='GameObject':return o
        try:return o.read(check_read=False).m_GameObject.deref()
        except:return None
    def add_root(o,reason):
        go=as_go(o)
        if go and go.path_id:roots.setdefault(key(go),{'object':go,'reasons':[]})['reasons'].append(reason)
    def walk(v,path,source):
        if isinstance(v,dict):
            if set(v)=={'file_id','path_id'}:
                if v['path_id']:
                    target=resolve(source,v)
                    if target:
                        pointers.append({'source_file':source.assets_file.name,'source_path_id':source.path_id,'field':path,'target':label(target)})
                        if re.search('effect|sound|trail|flightObj|undoParticle',path,re.I):add_root(target,path)
                return
            for k,x in v.items():walk(x,path+'.'+k,source)
        elif isinstance(v,list):
            for i,x in enumerate(v):walk(x,f'{path}[{i}]',source)
    for row in rows:
        source=objects[(row['file'],row['path_id'])]
        walk(row['data'],row['class'],source)
        if row['class'] in ['SpecialTileBehaviour','DropPowerUp','DropTile','DropTileRemoveColor','DropTileLast','RemoveColorBooster','ExtraSlotBoosterApplier','UIExtraSlot','Nevosoft.TY.Core.GiftBehaviour']:add_root(source,row['class'])
    selected={};root_graph=[];clip_keys=set();controllers=set()
    def go_tree(go,path,visited):
        if key(go) in visited:return []
        visited.add(key(go));d=go.read();path=path+'/'+d.m_Name;result=[];tr=None
        selected[key(go)]=go
        for entry in d.m_Component:
            ptr=entry.component if hasattr(entry,'component') else entry[1]
            try:o=ptr.deref()
            except:continue
            selected[key(o)]=o;result.append({'path':path,**label(o)})
            if o.type.name in ('Transform','RectTransform'):tr=o.read()
            if o.type.name=='Animation':
                data=o.read_typetree()
                for p in [data.get('m_Animation',{})]+data.get('m_Animations',[]):
                    if p.get('m_PathID'):
                        try:c=PPtr(**p,assetsfile=o.assets_file).deref();clip_keys.add(key(c))
                        except:pass
            if o.type.name=='Animator':
                try:controllers.add(key(o.read().m_Controller.deref()))
                except:pass
        if tr:
            for child in tr.m_Children:
                try:result+=go_tree(child.read().m_GameObject.deref(),path,visited)
                except:pass
        return result
    for k,v in roots.items():root_graph.append({'root':label(v['object']),'reasons':v['reasons'],'hierarchy':go_tree(v['object'],'',set())})
    for k in controllers:
        o=objects[k];data=o.read_typetree();selected[k]=o
        for p in data.get('m_AnimationClips',[]):
            if p['m_PathID']:
                try:c=PPtr(**p,assetsfile=o.assets_file).deref();clip_keys.add(key(c))
                except:pass
    detail={};custom=[]
    for k,o in selected.items():
        if o.type.name in ('GameObject','ParticleSystem','ParticleSystemRenderer','TrailRenderer','Animation','Animator','AnimatorController','AudioSource','Transform','RectTransform'):
            detail[f'{k[0]}:{k[1]}']={**label(o),'data':o.read_typetree()}
        elif o.type.name=='MonoBehaviour':
            d=o.read(check_read=False)
            try:s=d.m_Script.read();custom.append({**label(o),'class':s.m_ClassName,'namespace':s.m_Namespace})
            except:pass
    clips=[]
    for o in e.objects:
        if o.type.name!='AnimationClip':continue
        data=o.read_typetree();k=key(o)
        clips.append({**label(o),'selected':k in clip_keys,'sample_rate':data['m_SampleRate'],'events':data['m_Events'],'scale_curves':data['m_ScaleCurves'],'position_curves':data['m_PositionCurves'],'float_curves':data['m_FloatCurves'],'euler_curves':data['m_EulerCurves'],'rotation_curves':data['m_RotationCurves'],'stop_time':data.get('m_MuscleClip',{}).get('m_StopTime')})
        if k in clip_keys:detail[f'{k[0]}:{k[1]}']={**label(o),'data':data}
    for fn,data in [('effect-references.json',pointers),('effect-hierarchies.json',root_graph),('effect-components.json',detail),('effect-custom-scripts.json',custom),('animation-clips.json',clips)]:
        (OUT/fn).write_text(json.dumps(normalize(data),ensure_ascii=False,indent=2),encoding='utf-8')
    print('roots',len(roots),'components',len(selected),'detail',len(detail),'controllers',len(controllers),'selected_clips',len(clip_keys))
    print('custom',dict(collections.Counter(x['class'] for x in custom)))
    print('clips',[(x['name'],x['selected'],x['stop_time']) for x in clips if x['selected']])

if __name__=='__main__':main()
