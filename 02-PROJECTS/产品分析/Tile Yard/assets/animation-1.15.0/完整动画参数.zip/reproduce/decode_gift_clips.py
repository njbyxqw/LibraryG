"""Decode retained Unity optimized clip data without executing Animator."""
import json,struct,zlib,math,collections
from pathlib import Path
from extract_serialized import OUT

def main():
    objects=json.loads((OUT/'effect-components.json').read_text(encoding='utf-8'))
    graph=next(g for g in json.loads((OUT/'effect-hierarchies.json').read_text(encoding='utf-8')) if 'GiftBehaviour' in str(g['reasons']))
    paths={0:''}
    for h in graph['hierarchy']:
        if h['path'].startswith('/GiftBehaviour/animator/'):
            p=h['path'].split('/GiftBehaviour/animator/',1)[1];paths[zlib.crc32(p.encode())]=p
    attrs={zlib.crc32(x.encode()):x for x in ['m_Color.a','m_Color.r','m_Color.g','m_Color.b','m_Enabled','m_IsActive','m_FlipX','m_FlipY','m_Sprite','m_SpriteKey']}
    output=[]
    for k,x in objects.items():
        if x['type']!='AnimationClip' or not x['name'].startswith('Gift-'):continue
        a=x['data'];mc=a['m_MuscleClip'];clip=mc['m_Clip']['data'];stream=clip['m_StreamedClip'];dense=clip['m_DenseClip'];const=clip['m_ConstantClip'];raw=struct.pack('<'+'I'*len(stream['data']),*stream['data']);p=0;channels=collections.defaultdict(list)
        frames=[]
        while p<len(raw):
            time,count=struct.unpack_from('<fi',raw,p);p+=8
            assert 0<=count<10000
            keys=[]
            for _ in range(count):
                index,*co=struct.unpack_from('<i4f',raw,p);p+=20
                channels[index].append({'time':time,'coefficients':co,'value':co[3]});keys.append(index)
            frames.append({'time':time,'indices':keys})
        assert p==len(raw)
        offset=0;bindings=[];samples={};continuity=[]
        for b in a['m_ClipBindingConstant']['genericBindings']:
            attr=b['attribute'];n=3 if b['typeID']==4 and attr in [1,3,4] else 4 if b['typeID']==4 and attr==2 else 1
            name={1:'localPosition',2:'localRotation',3:'localScale',4:'localEulerAngles'}.get(attr,attrs.get(attr,f'hash:{attr}')) if b['typeID']==4 else attrs.get(attr,f'hash:{attr}')
            route=paths.get(b['path'],f'path-hash:{b["path"]}')
            vals=[]
            for c in range(n):
                index=offset+c
                if index<stream['curveCount']:
                    keys=channels.get(index,[]);v={'storage':'streamed','keys':[v for v in keys if abs(v['time'])<1e10]}
                    for aa,bb in zip(v['keys'],v['keys'][1:]):
                        dt=bb['time']-aa['time'];co=aa['coefficients'];value=((co[0]*dt+co[1])*dt+co[2])*dt+co[3];continuity.append(abs(value-bb['value']))
                elif index<stream['curveCount']+dense['m_CurveCount']:
                    ci=index-stream['curveCount'];v={'storage':'dense','sample_rate':dense['m_SampleRate'],'begin':dense['m_BeginTime'],'values':dense['m_SampleArray'][ci::dense['m_CurveCount']]}
                else:
                    ci=index-stream['curveCount']-dense['m_CurveCount'];v={'storage':'constant','value':const['data'][ci]}
                vals.append(v)
            bindings.append({'path':route,'attribute':name,'binding':b,'first_channel':offset,'channels':vals})
            offset+=n
        assert offset==stream['curveCount']+dense['m_CurveCount']+len(const['data']),(x['name'],offset,stream['curveCount'],dense['m_CurveCount'],len(const['data']))
        output.append({'file':x['file'],'path_id':x['path_id'],'name':x['name'],'sample_rate':a['m_SampleRate'],'start':mc['m_StartTime'],'stop':mc['m_StopTime'],'loop':mc['m_LoopTime'],'events':a['m_Events'],'bindings':bindings,'channel_count':offset,'max_segment_endpoint_error':max(continuity,default=0)})
    (OUT/'gift-clip-curves.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    for x in output:
        print(x['name'],x['stop'],'channels',x['channel_count'],'endpoint_error',x['max_segment_endpoint_error'])
        for b in x['bindings']:
            if b['attribute']=='localScale':print('SCALE',b['path'],b['channels'])

if __name__=='__main__':main()
