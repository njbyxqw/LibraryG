"""Read selected stripped Unity MonoBehaviours against recovered C# field schemas.
Does not execute game code. Every object must consume its complete serialized body.
"""
import json, re, struct, math, sys, collections, hashlib
from pathlib import Path
import UnityPy

ROOT=Path(__file__).resolve().parents[2]
CS=ROOT/'04-ReverseEngineering/cpp2il-cs/DiffableCs'
OUT=Path(__file__).resolve().parent
SCHEMAS={}
ENUMS={}

def init_schemas():
    for p in (CS/'TYLib').rglob('*.cs'):
        lines=p.read_text(encoding='utf-8').splitlines()
        namespace=next((l[10:].strip('; ') for l in lines if l.startswith('namespace ')), '')
        depth=0; attrs=[]; fields=[]; parent=''; cls=''; enum=False
        for line in lines:
            s=line.strip()
            if depth==0:
                m=re.match(r'(?:public|internal).*?\b(class|struct|enum)\s+([^ :]+)(?:\s*:\s*(.*))?',s)
                if m:
                    cls=p.stem.split('`')[0];parent=(m[3] or '').split(',')[0].strip();enum=m[1]=='enum'
            if depth==1:
                if s.startswith('['):attrs.append(s)
                elif '//Field offset:' in s:
                    m=re.match(r'(?P<mods>(?:(?:public|protected|private|internal|readonly|static|const|override|sealed)\s+)+)(?P<type>.+?)\s+(?P<name>[^ ;]+);',s)
                    if m:
                        mods=m['mods'];typ=m['type'];name=m['name'];is_serial=('public ' in mods or '[SerializeField]' in attrs)
                        if is_serial and not any(x in mods for x in ['static ','const ','readonly ']) and not any('NonSerialized' in a for a in attrs) and not any(x in typ for x in ['Action','Func<','Dictionary<','IEnumerable<']):
                            fields.append((typ,name))
                    attrs=[]
                elif s and not s.startswith('['):attrs=[]
            depth+=line.count('{')-line.count('}')
        if cls:
            name=(namespace+'.' if namespace else '')+cls
            if '`' not in p.stem:SCHEMAS[name]={'fields':fields,'parent':parent,'file':str(p)}
            if enum:ENUMS[cls]=True
    # Nested enums are serialized as Int32. Record names without trying to read class bodies.
    for p in (CS/'TYLib').rglob('*.cs'):
        text=p.read_text(encoding='utf-8')
        for en in re.findall(r'\benum\s+(\w+)',text):ENUMS[en]=True

class Reader:
    def __init__(self,b):self.b=b;self.p=0
    def take(self,n):
        assert n>=0 and self.p+n<=len(self.b),(self.p,n,len(self.b))
        v=self.b[self.p:self.p+n];self.p+=n;return v
    def fmt(self,f):return struct.unpack('<'+f,self.take(struct.calcsize('<'+f)))[0]
    def align(self):self.p=(self.p+3)&~3
    def string(self):
        n=self.fmt('i');assert 0<=n<10000000
        s=self.take(n).decode('utf-8');self.align();return s
    def ptr(self):return {'file_id':self.fmt('i'),'path_id':self.fmt('q')}

def resolve(typ):
    typ=typ.replace('UnityEngine.','').replace('System.','')
    if typ in SCHEMAS:return typ
    hits=[k for k in SCHEMAS if k.rsplit('.',1)[-1]==typ]
    if len(hits)==1:return hits[0]
    return typ

def object_type(typ,seen=None):
    typ=resolve(typ);seen=seen or set()
    if typ in seen:return False
    seen.add(typ)
    if typ in ['MonoBehaviour','ScriptableObject','Component','Behaviour','Object','GameObject','Transform','RectTransform','Sprite','AudioSource','AudioClip','ParticleSystem','TrailRenderer','TextMeshPro','TextMeshProUGUI','SpriteRenderer','Image','Animator','Animation','AnimationClip','Camera','MeshRenderer','Canvas','Material','RenderTexture','Texture2D','Shader','Collider2D','BoxCollider2D','Button','CanvasGroup','SortingGroup']:return True
    if typ in SCHEMAS:return object_type(SCHEMAS[typ]['parent'],seen)
    return False

def fields_for(typ):
    typ=resolve(typ);s=SCHEMAS[typ];base=resolve(s['parent'])
    return (fields_for(base) if base in SCHEMAS else [])+s['fields']

def read_value(r,typ):
    typ=typ.replace('UnityEngine.','')
    if typ.endswith('[]'):
        n=r.fmt('i');assert 0<=n<100000
        return [read_value(r,typ[:-2]) for _ in range(n)]
    if typ.startswith('List<') or typ.startswith('System.Collections.Generic.List<'):
        elem=typ[typ.index('<')+1:-1];n=r.fmt('i');assert 0<=n<100000
        return [read_value(r,elem) for _ in range(n)]
    if typ in ('float','Single'):return r.fmt('f')
    if typ in ('int','Int32'):return r.fmt('i')
    if typ in ('uint','UInt32'):return r.fmt('I')
    if typ in ('bool','Boolean'):
        v=bool(r.fmt('B'));r.align();return v
    if typ=='string':return r.string()
    vec={'Vector2':2,'Vector3':3,'Vec3':3,'Vector4':4,'Quaternion':4,'Color':4,'Rect':4}
    if typ in vec:return [r.fmt('f') for _ in range(vec[typ])]
    if typ=='AnimationCurve':
        n=r.fmt('i');assert 0<=n<10000,(r.p,n)
        keys=[]
        for _ in range(n):
            k={s:r.fmt('f') for s in ['time','value','inSlope','outSlope']};k['weightedMode']=r.fmt('i');k['inWeight']=r.fmt('f');k['outWeight']=r.fmt('f');keys.append(k)
        return {'keys':keys,'preInfinity':r.fmt('i'),'postInfinity':r.fmt('i'),'rotationOrder':r.fmt('i')}
    if typ.rsplit('.',1)[-1] in ENUMS:return r.fmt('i')
    if object_type(typ):return r.ptr()
    q=resolve(typ)
    if q in SCHEMAS:return {name:read_value(r,t) for t,name in fields_for(q)}
    raise ValueError('Unknown serialized type '+typ)

def normalize(x):
    if isinstance(x,float):return x if math.isfinite(x) else str(x)
    if isinstance(x,dict):return {k:normalize(v) for k,v in x.items()}
    if isinstance(x,list):return [normalize(v) for v in x]
    return x

def main():
    init_schemas()
    wanted={'DropTile','DropTileRemoveColor','Tile','Field','DropField','DropFieldCollector','PowerUp','DropPowerUp','UIPowerUp','UIPowerUpProperties','SpecialTileBehaviour','RemoveColorBooster','ExtraSlotBoosterApplier','UIExtraSlot','HintConfigSO','PickaxConfigSO','Boom9ConfigSO','ReshuffleConfigSO','AnimFunc','ShadowObject'}
    e=UnityPy.load(str(ROOT/'01-Decoded/assets/bin/Data/data.unity3d'));rows=[];errors=[];inventory=[]
    for o in e.objects:
        if o.type.name!='MonoBehaviour':continue
        try:
            d=o.read(check_read=False);s=d.m_Script.read();cls=s.m_ClassName;ns=s.m_Namespace
        except:continue
        name=(ns+'.' if ns else '')+cls
        if (cls not in wanted and cls not in ('RippleEffect','SoundRandomPitch','DestroySoundAfterPlay','GiftBehaviour','GiftConfigSO') and not cls.startswith('DropTile')) or name not in SCHEMAS:continue
        raw=o.get_raw_data();r=Reader(raw)
        r.take(28);mname=r.string()
        try:go=d.m_GameObject.read().m_Name
        except:go=None
        item={'file':o.assets_file.name,'path_id':o.path_id,'class':name,'name':mname,'gameobject':go,'bytes':len(raw),'serialized_sha256':hashlib.sha256(raw).hexdigest(),'schema':fields_for(name)}
        try:
            item['data']={};item['field_byte_ranges']={}
            for ft,fn in fields_for(name):
                start=r.p;item['data'][fn]=read_value(r,ft);item['field_byte_ranges'][fn]=[start,r.p]
            item['parsed_bytes']=r.p
            assert r.p==len(raw),(r.p,len(raw))
            rows.append(item)
        except Exception as ex:item['parsed_bytes']=r.p;item['error']=repr(ex);errors.append(item)
        inventory.append({k:v for k,v in item.items() if k not in ('data','schema')})
    OUT.mkdir(exist_ok=True)
    (OUT/'serialized-components.json').write_text(json.dumps(normalize(rows),ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'serialization-errors.json').write_text(json.dumps(normalize(errors),ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'serialization-schemas.json').write_text(json.dumps({x['class']:x['schema'] for x in rows+errors},ensure_ascii=False,indent=2),encoding='utf-8')
    print('complete',dict(collections.Counter(x['class'] for x in rows)))
    print('errors',dict(collections.Counter(x['class'] for x in errors)))
    for x in errors[:12]:print(x['class'],x['gameobject'],x['error'],x['parsed_bytes'],x['bytes'])

if __name__=='__main__':main()
