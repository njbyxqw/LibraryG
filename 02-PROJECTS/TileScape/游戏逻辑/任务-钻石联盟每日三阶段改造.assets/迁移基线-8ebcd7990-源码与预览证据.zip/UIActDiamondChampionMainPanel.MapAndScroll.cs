using TransformUtils = Module.Utils.UtilsTransform;
using System.Collections.Generic;
using Module.Activity.DiamondChampion;
using Betta.Framework;
using BettaSDK;

using UnityEngine;
using UnityEngine.UI;

public partial class UIActDiamondChampionMainPanel
{
    private const string MapBackgroundPath =
        "Assets/Module/Activity/DiamondChampion/ResDLC/Default/Panel/Prefab/MapSections/DiamondChampionMapBackground.prefab";

    private const float MapBackgroundHeight = 824f;

    private void InitMap()
    {
        _mapSections = new List<UIDiamondChampionMapSection>();

        var maxLevel = _activity.MaxLevel();

        _activity.EnsureMapSeedInitialized();

        for (var i = 0; i <= maxLevel; i++)
        {
            UIDiamondChampionMapSection section;
            if (i == 0)
            {
                section = new UIDiamondChampionMapSection(trans_MapRoot, DiamondChampionMapSectionType.Bottom, trans_ClickArea);
            }
            else if (i == _activity.MaxLevel())
            {
                section = new UIDiamondChampionMapSection(trans_MapRoot, DiamondChampionMapSectionType.Top, trans_ClickArea);
            }
            else
            {
                section = new UIDiamondChampionMapSection(trans_MapRoot,
                    i % 2 == 0 ? DiamondChampionMapSectionType.MiddleLeft : DiamondChampionMapSectionType.MiddleRight, trans_ClickArea);
            }

            var layoutData = _activity.GetMapSectionLayoutData(i, maxLevel);
            section.RefreshUI(layoutData, i, i == maxLevel);

            section.Transform.name = "MapSection" + i;
            section.Transform.SetAsFirstSibling();
            _mapSections.Add(section);
        }

        var progressForDisplay = GetMapProgressForDisplay();
        for (int i = 0; i < progressForDisplay; i++)
        {
            _mapSections[i].Hide();
        }

        LayoutRebuilder.ForceRebuildLayoutImmediate(trans_MapRoot);

        Canvas.ForceUpdateCanvases();

        var targetHeight = trans_MapRoot.GetComponent<VerticalLayoutGroup>().preferredHeight;
        var count = targetHeight / MapBackgroundHeight;
        for (int i = 0; i < count; i++)
        {
            var go = ResourceHub.LoadGameObject(MapBackgroundPath);
            TransformUtils.SetParent(go.transform, trans_BackgroundRoot);
        }

        BuildFinalRewardDisplay();
        BuildUnclaimedMidChestsOnMap();
    }

    private void BuildFinalRewardDisplay()
    {
        _rewardDisplayPanel?.OnRelease();
        _rewardDisplayPanel = null;

        if (_mapSections == null || _mapSections.Count == 0)
        {
            return;
        }

        var topSection = _mapSections[_activity.MaxLevel()];
        var rewardRoot = TransformUtils.Find<Transform>(topSection.Transform, "Root/Background/Treasure");
        if (rewardRoot == null)
        {
            return;
        }

        _rewardDisplayPanel = new UIActDiamondChampionRewardDisplayPanel(rewardRoot);
        _rewardDisplayPanel.Refresh(_activity);
    }

    private void InitAvatars()
    {
        _animPortraits = new List<UIActDiamondChampionAnimPortrait>();
        var count = trans_ItemParent.childCount;
        var leftNum = _activity.LastLeftNumOfPeople() - 1;
        for (int i = count - 1; i >= 0; i--)
        {
            var trans = trans_ItemParent.GetChild(i);
            if (trans.name == "MyPortrait")
            {
                _myAnimPortrait = new UIActDiamondChampionAnimPortrait(trans);
                var playerInfo = ImplementHub.Instance.Get<Interface.PlayerInfo.IPlayerInfo>();
                _myAnimPortrait.Show(playerInfo.GetAvatarId(), playerInfo.GetFrameId(), 0);
                _myAnimPortrait.SetPosition(_myAnimPortrait.Transform.GetComponent<RectTransform>().anchoredPosition);
            }
            else if (i > count - 1 - leftNum)
            {
                var portrait = new UIActDiamondChampionAnimPortrait(trans);
                portrait.ShowRandom();
                portrait.SetPosition(portrait.Transform.GetComponent<RectTransform>().anchoredPosition);
                _animPortraits.Add(portrait);
            }
            else
            {
                trans.gameObject.SetActive(false);
            }
        }

        var itemParent = _mapSections[GetMapProgressForDisplay()].GetItemParent();
        trans_ItemParent.position = itemParent.position;
    }

    private void SetScrollVerticalNormalizedPosition()
    {
        scrollRect_Map.verticalNormalizedPosition = CalculateVerticalNormalizedPosition(GetMapProgressForDisplay());
    }

    private int GetMapProgressForDisplay()
    {
        if (_activity == null)
        {
            return 0;
        }

        if (_activity.MainViewStateView == DiamondChampionMainViewState.SettleFail)
        {
            return Mathf.Clamp(_activity.FailProgressBeforeSettle(), 0, _activity.MaxLevel());
        }

        return Mathf.Clamp(_activity.LastLevel(), 0, _activity.MaxLevel());
    }

    private float CalculateVerticalNormalizedPosition(int level, float offsetY = 0)
    {
        var contentHeight = scrollRect_Map.content.GetComponent<RectTransform>().rect.height;
        var viewportHeight = scrollRect_Map.viewport.GetComponent<RectTransform>().rect.height;
        if (contentHeight <= viewportHeight)
        {
            return 1;
        }

        var totalProgressHeight = contentHeight - viewportHeight;

        var progressHeight = offsetY;
        for (var i = 0; i < level; i++)
        {
            progressHeight += _mapSections[i].Transform.GetComponent<RectTransform>().rect.height;
        }

        return Mathf.Clamp01(progressHeight / totalProgressHeight);
    }

    private float CalculateVerticalNormalizedPositionForMidChestCenter(int level, float targetWorldY)
    {
        if (_mapSections == null || level < 0 || level >= _mapSections.Count)
        {
            return scrollRect_Map != null ? scrollRect_Map.verticalNormalizedPosition : 1f;
        }

        var baseNorm = CalculateVerticalNormalizedPosition(level);
        var contentRect = scrollRect_Map.content as RectTransform;
        var viewportRect = scrollRect_Map.viewport as RectTransform;
        if (contentRect == null || viewportRect == null)
        {
            return baseNorm;
        }

        var totalScrollableHeight = contentRect.rect.height - viewportRect.rect.height;
        if (totalScrollableHeight <= 0.0001f)
        {
            return baseNorm;
        }

        var originalNorm = scrollRect_Map.verticalNormalizedPosition;
        var targetNorm = baseNorm;
        var deltaNorm = Mathf.Abs((targetWorldY - _mapSections[level].Transform.GetComponent<RectTransform>().rect.height) / totalScrollableHeight);
        targetNorm = Mathf.Clamp01(targetNorm - deltaNorm);

        scrollRect_Map.verticalNormalizedPosition = originalNorm;
        Canvas.ForceUpdateCanvases();
        return targetNorm;
    }
}
