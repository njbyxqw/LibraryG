using Interface.Activity;
using Module.Activity;
using TransformUtils = Module.Utils.UtilsTransform;
using Betta.Framework;
using BettaSDK;
using BettaSDK.Profile;
using DG.Tweening;
using Module.DiamondChampion.Config;

using UnityEngine;
using UnityEngine.UI;

namespace Module.Activity.DiamondChampion
{
    public class UIDiamondChampionMapSection
    {
    public Transform Transform { get; private set; }
    public RectTransform RectTransform => Transform as RectTransform;

        private readonly string[] PillarPath = new[]
        {
            "Assets/Module/Activity/DiamondChampion/ResDLC/Default/TexturePackerScene/DiamondChampion_pillar1.png",
            "Assets/Module/Activity/DiamondChampion/ResDLC/Default/TexturePackerScene/DiamondChampion_pillar2.png",
            "Assets/Module/Activity/DiamondChampion/ResDLC/Default/TexturePackerScene/DiamondChampion_pillar3.png",
        };

        private string AssetPath
        {
            get => _mapSectionType switch
            {
                DiamondChampionMapSectionType.Top => "Assets/Module/Activity/DiamondChampion/ResDLC/Default/Panel/Prefab/MapSections/DiamondChampionMapSectionTop.prefab",
                DiamondChampionMapSectionType.MiddleLeft => "Assets/Module/Activity/DiamondChampion/ResDLC/Default/Panel/Prefab/MapSections/DiamondChampionMapSectionMiddleLeft.prefab",
                DiamondChampionMapSectionType.MiddleRight => "Assets/Module/Activity/DiamondChampion/ResDLC/Default/Panel/Prefab/MapSections/DiamondChampionMapSectionMiddleRight.prefab",
                DiamondChampionMapSectionType.Bottom => "Assets/Module/Activity/DiamondChampion/ResDLC/Default/Panel/Prefab/MapSections/DiamondChampionMapSectionBottom.prefab",
                _ => "",
            };
        }

        private DiamondChampionMapSectionType _mapSectionType;

        private ActDiamondChampion _activity;

        private RectTransform _itemRoot;

        private UIButtonBetta _button;

        private RectTransform _pillarRoot;

        private Vector2 _posOffset;

        private Animator _animator;

        private Image _pillarImage;

        private int _level;

        private bool _isMax;

        private RectTransform _clickArea;

        private readonly int _pillarBreak = Animator.StringToHash("PillarBreak");
        private readonly int _pillarBroken = Animator.StringToHash("PillarBroken");
        private readonly int _pillarIdle = Animator.StringToHash("PillarIdle");

        private Module.Reward.UIRewardBoxItem _midChestBox;
        private MidChest _midChestCfg;
        private int[][] _midChestRewards;

        public UIDiamondChampionMapSection(Transform parent, DiamondChampionMapSectionType mapSectionType, RectTransform clickArea)
        {
            _mapSectionType = mapSectionType;
            _clickArea = clickArea;
            _activity = ImplementHub.Instance.Get<IActivitySystem>().GetActivity<ActDiamondChampion>();
            Transform = ResourceHub.LoadGameObject(AssetPath).transform;
        Transform.SetParent(parent, false);
            FindComponents();
            RegisterEvents();
        }

        private void FindComponents()
        {
            _itemRoot = TransformUtils.Find<RectTransform>(Transform, "Root/Background/ItemRoot");
            _pillarRoot = TransformUtils.Find<RectTransform>(Transform, "Root");
            _pillarImage = TransformUtils.Find<Image>(Transform, "Root/Background");
            _button = TransformUtils.Find<UIButtonBetta>(Transform, "Root/Background/Button");

            _animator = TransformUtils.Find<Animator>(Transform, "Root");
        }

        private void RegisterEvents()
        {
            _button.onClick.AddListener(OnClickButton);
        }

        private void UnRegisterEvents()
        {
            _button.onClick.RemoveListener(OnClickButton);
        }

        private void OnClickButton()
        {
            if (!IsButtonValid())
            {
                return;
            }
            if (_isMax)
            {
                if (_activity.GetRawTotalDiamondCount() > 0)
                {
                    ImplementHub.Instance.Get<Interface.Reward.IRewardSystem>()?.TryShowTips(new Interface.Reward.RewardTipsRequest
                    {
                        Text = LocaleManager.GetText("str_id_DiamondChampion_GrandPrizeTips"),
                        AnchorUIPoint = _button.transform.position,
                        YOffset = 230,
                        PreferAbove = true,
                        SourceKey = "DiamondChampion.Map." + _level,
                    }, out _);
                }
                else
                {
                    ImplementHub.Instance.Get<Interface.Reward.IRewardSystem>()?.TryShowTips(new Interface.Reward.RewardTipsRequest
                    {
                        Text = LocaleManager.GetText("str_id_DiamondChampion_GrandPrizeTips2"),
                        AnchorUIPoint = _button.transform.position,
                        YOffset = 230,
                        PreferAbove = true,
                        SourceKey = "DiamondChampion.Map." + _level,
                    }, out _);
                }
            }
            else if (_level == (_activity.MainViewStateView == DiamondChampionMainViewState.SettleFail
                         ? _activity.FailProgressBeforeSettle()
                         : _activity.CurrentLevel()))
            {
                ImplementHub.Instance.Get<Interface.Reward.IRewardSystem>()?.TryShowTips(new Interface.Reward.RewardTipsRequest
                    {
                        Text = string.Format(LocaleManager.GetText("str_id_DiamondChampion_PlayerTips"), _activity.LeftNumOfPeople()),
                        AnchorUIPoint = _button.transform.position,
                        YOffset = 100,
                        PreferAbove = true,
                        SourceKey = "DiamondChampion.Map." + _level,
                    }, out _);
            }
            else if (_level != 0)
            {
                ImplementHub.Instance.Get<Interface.Reward.IRewardSystem>()?.TryShowTips(new Interface.Reward.RewardTipsRequest
                    {
                        Text = LocaleManager.GetText("str_id_DiamondChampion_PillarTips"),
                        AnchorUIPoint = _button.transform.position,
                        YOffset = 0,
                        PreferAbove = true,
                        SourceKey = "DiamondChampion.Map." + _level,
                    }, out _);
            }
        }

        private bool IsButtonValid()
        {
            var clickBounds = new Vector3[4];
            _clickArea.GetWorldCorners(clickBounds);
            var buttonBounds = new Vector3[4];
            _button.GetComponent<RectTransform>().GetWorldCorners(buttonBounds);
            var center = new Vector2((buttonBounds[0].x + buttonBounds[2].x) / 2f,
                (buttonBounds[0].y + buttonBounds[2].y) / 2f);
            return clickBounds[0].x <= center.x
                   && clickBounds[0].y <= center.y
                   && clickBounds[2].x > center.x
                   && clickBounds[2].y > center.y;
        }

        public DiamondChampionMapData RefreshUI(DiamondChampionMapData data = null, int level = 0, bool isMax = false)
        {
            _level = level;
            _isMax = isMax;
            if (data == null)
            {
                data = new DiamondChampionMapData();
                if (_mapSectionType == DiamondChampionMapSectionType.MiddleLeft || _mapSectionType == DiamondChampionMapSectionType.MiddleRight)
                {
                    var isMiddleLeft = _mapSectionType == DiamondChampionMapSectionType.MiddleLeft;
                    DiamondChampionMapPillarLayout.SampleUnity(isMiddleLeft, data, PillarPath.Length);
                    _posOffset = new Vector2(data.OffsetX, data.OffsetY);
                    _pillarRoot.anchoredPosition += _posOffset;

                    _pillarImage.sprite = ResourceHub.LoadSprite(PillarPath[data.SpriteIndex], _pillarImage.gameObject);
                }
                else
                {
                    data.OffsetX = 0;
                    data.OffsetY = 0;
                    data.SpriteIndex = 0;
                }
            }
            else
            {
                if (_mapSectionType == DiamondChampionMapSectionType.MiddleLeft || _mapSectionType == DiamondChampionMapSectionType.MiddleRight)
                {
                    _pillarRoot.anchoredPosition += new Vector2(data.OffsetX, data.OffsetY);

                    _pillarImage.sprite = ResourceHub.LoadSprite(PillarPath[data.SpriteIndex], _pillarImage.gameObject);
                }
            }

            if (_animator != null)
            {
                _animator.Play(_pillarIdle);
            }

            return data;
        }

        public void OnRelease()
        {
            UnRegisterEvents();
            _midChestBox?.Release();
        }

        public RectTransform GetItemParent()
        {
            return _itemRoot;
        }

        public Vector2 GetRandomFailPosOffset()
        {
            if (_mapSectionType == DiamondChampionMapSectionType.Bottom)
            {
                return new Vector2(Random.Range(-300, 200), Random.Range(400, 500));
            }
            if (_mapSectionType == DiamondChampionMapSectionType.MiddleLeft)
            {
                return new Vector2(Random.Range(200, 500), Random.Range(-100, 10)) - _posOffset;
            }
            if (_mapSectionType == DiamondChampionMapSectionType.MiddleRight)
            {
                return new Vector2(Random.Range(-400, -200), Random.Range(-100, 10)) + _posOffset;
            }
            if (_mapSectionType == DiamondChampionMapSectionType.Top)
            {
                return new Vector2(Random.Range(-400, 400), Random.Range(-200, -100));
            }

            return Vector2.zero;
        }

        public void Hide()
        {
            if (_animator != null)
            {
                _animator.Play(_pillarBroken);
            }
        }

        public void PillarBreak()
        {
            if (_animator == null)
            {
                return;
            }
            ImplementHub.Instance.Get<Interface.Sound.IAudioSystem>()?.PlayAudio(Module.Audio.SoundConst.SFX_Temple_StoneBreak, false, -1f);
            _animator.Play(_pillarBreak);
        }

        public void SetMidChest(MidChest chestCfg)
        {
            _midChestCfg = chestCfg;
            _midChestRewards = _activity.GetResolvedMidChestRewards(chestCfg);
            if (chestCfg == null || _isMax)
            {
                SetMidChestVisible(false);
                UpdatePillarClickButtonState(false);
                return;
            }

            _midChestBox?.Release();
            _midChestBox = new Module.Reward.UIRewardBoxItem(_itemRoot, chestCfg.assetPath, _midChestRewards, 150f);
            SetMidChestVisible(true);
            UpdatePillarClickButtonState(true);
        }

        private void UpdatePillarClickButtonState(bool hasMidChest)
        {
            if (_button == null)
            {
                return;
            }

            var isMiddleSection = _mapSectionType == DiamondChampionMapSectionType.MiddleLeft ||
                                  _mapSectionType == DiamondChampionMapSectionType.MiddleRight;
            var shouldHideButton = hasMidChest && isMiddleSection;
            _button.gameObject.SetActive(!shouldHideButton);
        }

        public void SetMidChestVisible(bool isVisible)
        {
            if (_midChestBox != null)
            {
                _midChestBox.Transform.gameObject.SetActive(isVisible);
            }
        }

        public bool HasMidChest()
        {
            return _midChestBox != null && _midChestBox.Transform != null && _midChestBox.Transform.gameObject.activeSelf;
        }

        public Vector3 GetMidChestWorldPosition()
        {
            if (_midChestBox != null && _midChestBox.Transform != null && _midChestBox.Transform.gameObject.activeInHierarchy)
            {
                return _midChestBox.Transform.position;
            }
            return _pillarRoot.position;
        }

        public MidChest GetMidChestConfig()
        {
            return _midChestCfg;
        }

        public int[][] GetMidChestRewards()
        {
            return _midChestRewards;
        }

        public void PlayMidChestOpenAnim()
        {
            if (_midChestBox == null || _midChestBox.Transform == null || !_midChestBox.Transform.gameObject.activeInHierarchy)
            {
                return;
            }
            _midChestBox.Transform.DOKill();
            _midChestBox.Transform.localScale = Vector3.one;
            _midChestBox.Transform.DOPunchScale(new Vector3(0.22f, 0.22f, 0f), 0.25f, 1, 0f)
                .SetLink(_midChestBox.Transform.gameObject);
        }

        public void SetChestTipsVisible(bool isVisible)
        {
            if (!HasMidChest()) return;

            _midChestBox?.SetTipsVisible(isVisible);
        }
    }
}
