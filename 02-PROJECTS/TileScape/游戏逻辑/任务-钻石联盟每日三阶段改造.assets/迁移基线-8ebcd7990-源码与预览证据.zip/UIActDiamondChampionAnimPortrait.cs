using TransformUtils = Module.Utils.UtilsTransform;
using Module.Activity.Robot;
using Betta.Framework;
using BettaSDK;
using DG.Tweening;
using Game;
using Module.PlayerInfo;

using UnityEngine;

namespace Module.Activity.DiamondChampion
{
    public class UIActDiamondChampionAnimPortrait
    {
    public Transform Transform { get; private set; }
    public RectTransform RectTransform => Transform as RectTransform;

        // 水平平台（首/末关）边缘落点不在矩形平台同一几何口径，避免穿帮需要对落点做微调。
        private const float FromFirstLevelUpFactor = 0.12f;
        private const float FromFirstLevelUpMin = 70f;
        private const float FromFirstLevelUpMax = 140f;

        private string AssetPath => "Assets/Module/Activity/DiamondChampion/ResDLC/Default/Panel/Prefab/ActDiamondChampionAnimPortrait.prefab";

        private Animator _animator;

        private Transform _portraitTransform;

        private UIPortraitView _portraitView;

        private Vector2 _anchoredPosition;

        private Transform _effect;

        private int _avatarId;
        private int _frameId;
        private int _badgeId;

        private readonly int _appear = Animator.StringToHash("Appear");
        private readonly int _disappear = Animator.StringToHash("Disappear");

        private Sequence _seq;

        public UIActDiamondChampionAnimPortrait(Transform transform)
        {
            Transform = transform;
            FindComponents();
            InitProperties();
            RegisterEvents();
        }

        private void FindComponents()
        {
            _animator = Transform.GetComponent<Animator>();
            _portraitTransform = TransformUtils.Find(Transform, "AnimRoot/ScaleRoot/UIPortraitView");
            _effect = TransformUtils.Find(Transform, "AnimRoot/ScaleRoot/Effect");
        }

        private void InitProperties()
        {
            _portraitView = new UIPortraitView(_portraitTransform);
            _avatarId = PortraitConfig.DefaultAvatarId;
            _frameId = PortraitConfig.DefaultFrameId;
            _badgeId = 0;
        }

        private void RegisterEvents()
        {

        }

        private void UnregisterEvents()
        {

        }

        public void OnRelease()
        {
            UnregisterEvents();
            _portraitView.OnRelease();
            if (_seq != null)
            {
                _seq.Kill();
            }
        }

        public void Show(int avatarId, int frameId, int badgeId)
        {
            _portraitView.Show(avatarId, frameId);
        }

        public void ShowRandom()
        {
            _avatarId = ImplementHub.Instance.Get<Interface.PlayerInfo.IPlayerInfo>().GetRandomId(PortraitType.Avatar);
            _frameId = ImplementHub.Instance.Get<Interface.PlayerInfo.IPlayerInfo>().GetRandomId(PortraitType.Frame);
            _badgeId = 0;

            _portraitView.Show(_avatarId, _frameId, false);
        }

        public void SetPosition(Vector2 position)
        {
            _anchoredPosition = position;
        }

        public void Appear()
        {
            if (_animator != null)
            {
                _animator.Play(_appear);
            }

            DOVirtual.DelayedCall(0.2f, () =>
            {
                HapticsHub.Instance.DoHaptic(HapticsTypes.Light);
            }, false).SetLink(Transform.gameObject);
        }

        public void CompleteAppear()
        {
            if (_animator == null)
            {
                return;
            }

            _animator.Play(_appear, 0, 1f);
            _animator.Update(0f);
        }

        public void JumpToNext(Transform target, float duration, bool withEffect = false)
        {
            _seq?.Kill();

            var originPos = Transform.GetComponent<RectTransform>().anchoredPosition;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(Transform.parent.GetComponent<RectTransform>(), ImplementHub.Instance.Get<Interface.Cameras.ICameraModule>().UICamera.WorldToScreenPoint(target.position), ImplementHub.Instance.Get<Interface.Cameras.ICameraModule>().UICamera, out var targetPos);
            targetPos += _anchoredPosition;

            var yOffset = Mathf.Abs(originPos.y - targetPos.y) / 2 * 1.3f;
            var xOffset = Mathf.Abs(originPos.x - targetPos.x) * 0.2f;

            var middlePos = new Vector2((originPos.x + targetPos.x) / 2 + xOffset, (originPos.y + targetPos.y) / 2 + yOffset);

            var path = new Vector3[]
            {
                originPos,
                middlePos,
                targetPos,
            };

            var toLeft = targetPos.x < middlePos.x;

            _seq = DOTween.Sequence();
            _seq.SetLink(Transform.gameObject);

            _seq.AppendInterval(0.25f);
            var anim = JumpToAnim(path, toLeft, duration, withEffect);
            _seq.Append(anim);
            _seq.AppendInterval(0.5f);

            _seq.OnComplete(() =>
            {
                anim.Kill();
                Transform.GetComponent<RectTransform>().localPosition = targetPos;
            });
        }

        private Sequence JumpToAnim(Vector3[] path, bool toLeft, float duration, bool withEffect)
        {
            var seq = DOTween.Sequence();
            seq.SetLink(Transform.gameObject);
            if (_effect != null)
            {
                _effect.gameObject.SetActive(withEffect);
            }
            var rect = Transform.GetComponent<RectTransform>();
            seq.Append(rect.DOScale(new Vector2(1.1f, 0.95f), 0.1f * duration));
            seq.Append(rect.DOScale(new Vector2(0.8f, 1.3f), 0.1f * duration));
            seq.Append(rect.DOScale(new Vector2(0.8f, 1.3f), 0.3f * duration));
            seq.Append(rect.DOScale(new Vector2(0.8f, 1.3f), 0.3f * duration));
            seq.Append(rect.DOScale(new Vector2(1.1f, 0.95f), 0.1f * duration));
            seq.Append(rect.DOScale(new Vector2(1f, 1f), 0.1f * duration));

            seq.Insert(0.1f * duration, Transform.GetComponent<RectTransform>().DOLocalPath(path, 0.8f * duration).SetLink(Transform.gameObject));
            var delay = Random.Range(0, 0.8f);
            seq.InsertCallback((0.1f + delay) * duration, () =>
            {
                var volume = Random.Range(0.1f, 1.2f);
                ImplementHub.Instance.Get<Interface.Sound.IAudioSystem>()?.PlayAudio(Module.Audio.SoundConst.SFX_Temple_Jump, false, volume);
            });
            seq.OnComplete(() =>
            {
                if (_effect != null)
                {
                    _effect.gameObject.SetActive(false);
                }
            });
            return seq;
        }

        public void FallDown(Transform target, Vector2 posOffset, float duration, bool withEffect = false,
            bool applyFromFirstLevelUp = false)
        {
            _seq?.Kill();

            var originPos = Transform.GetComponent<RectTransform>().anchoredPosition;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(Transform.parent.GetComponent<RectTransform>(), ImplementHub.Instance.Get<Interface.Cameras.ICameraModule>().UICamera.WorldToScreenPoint(target.position), ImplementHub.Instance.Get<Interface.Cameras.ICameraModule>().UICamera, out var targetPos);

            if (applyFromFirstLevelUp)
            {
                var yDistance = Mathf.Abs(originPos.y - targetPos.y);
                var upOffset = Mathf.Clamp(yDistance * FromFirstLevelUpFactor, FromFirstLevelUpMin, FromFirstLevelUpMax);
                targetPos += new Vector2(0f, upOffset);
            }

            targetPos += posOffset;

            var yOffset = Mathf.Abs(originPos.x - targetPos.x) / 2;

            var middlePos = new Vector2((originPos.x + targetPos.x) / 2, (originPos.y + targetPos.y) / 2 + yOffset);

            var path = new Vector3[]
            {
                originPos,
                middlePos,
                targetPos,
            };

            var toLeft = targetPos.x > middlePos.x;

            _seq = DOTween.Sequence();
            _seq.SetLink(Transform.gameObject);

            _seq.AppendInterval(0.25f);

            var anim = JumpToAnim(path, toLeft, duration, withEffect);
            _seq.Append(anim);
            _seq.AppendCallback(() =>
            {
                if (_animator != null)
                {
                    _animator.Play(_disappear);
                }
            });
            _seq.Append(Transform.GetComponent<RectTransform>().DOLocalMoveY(targetPos.y - 400, 0.5f).SetLink(Transform.gameObject));
            _seq.Join(Transform.GetComponent<RectTransform>().DOLocalMoveX(targetPos.x - (posOffset.x - (posOffset.x > 0 ? 100 : -100)) / 300 * 100, 0.5f).SetLink(Transform.gameObject));
            _seq.OnComplete(() =>
            {
                anim.Kill();
                Transform.GetComponent<RectTransform>().localPosition = targetPos;
            });
        }

        public void FastJump(Transform target)
        {
            _seq?.Kill();
            Transform.localScale = Vector3.one;

            RectTransformUtility.ScreenPointToLocalPointInRectangle(Transform.parent.GetComponent<RectTransform>(), ImplementHub.Instance.Get<Interface.Cameras.ICameraModule>().UICamera.WorldToScreenPoint(target.position), ImplementHub.Instance.Get<Interface.Cameras.ICameraModule>().UICamera, out var targetPos);
            targetPos += _anchoredPosition;

            Transform.localPosition = targetPos;
        }

        public void FastFall(Transform target, Vector2 posOffset, float duration, bool withEffect = false,
            bool applyFromFirstLevelUp = false)
        {
            _seq?.Kill();
            Transform.localScale = Vector3.zero;

            var originPos = Transform.GetComponent<RectTransform>().anchoredPosition;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(Transform.parent.GetComponent<RectTransform>(), ImplementHub.Instance.Get<Interface.Cameras.ICameraModule>().UICamera.WorldToScreenPoint(target.position), ImplementHub.Instance.Get<Interface.Cameras.ICameraModule>().UICamera, out var targetPos);

            if (applyFromFirstLevelUp)
            {
                var yDistance = Mathf.Abs(originPos.y - targetPos.y);
                var upOffset = Mathf.Clamp(yDistance * FromFirstLevelUpFactor, FromFirstLevelUpMin, FromFirstLevelUpMax);
                targetPos += new Vector2(0f, upOffset);
            }

            targetPos += posOffset;

            Transform.localPosition = targetPos;
        }

        public int[] GetPortraitInfo()
        {
            return new[] { _avatarId, _frameId, _badgeId };
        }
    }
}
