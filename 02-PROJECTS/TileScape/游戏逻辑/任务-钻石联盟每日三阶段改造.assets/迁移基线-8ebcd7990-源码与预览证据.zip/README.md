# 钻石联盟完整迁移基线动画留档

基线：8ebcd79907428332c67362beb21acfcb5512e576（迁移百人七关原项目代码并修复生命周期与流程衔接）。最早的 a137b7829 是骨架导入，未含完整 JumpToNext/FallDown；此处以恢复原项目完整表现逻辑的 8ebcd7990 为动画对照基线，未用后续 RM 改造版冒充迁移初版。

资源来自该提交 DiamondChampion/ResDLC 和 Animation，临时导入时重映射内部 GUID，未覆盖当前 SplashQuest 资源。公共字体/头像组件依赖当前 TS 环境。主界面、石台、Appear/Disappear/PillarBreak 动画及标题、段位文案沿用旧资源；动态地图按原布局规则组装，地图随机偏移取零，淘汰偏移取原随机范围内固定样本。

预览手动驱动原跳跃几何、缩放和回调时间；相机坐标转换用同一平面的 InverseTransformPoint 等价换算。动画资源使用 SampleAnimation 采样，未录制真实账号、音效、粒子推进、全局队列或点击交互。演示数据 100→70 人、成功 1/7→2/7、失败维持 1/7；不是数值配置或实际淘汰结果。当前 UI 按显示状态隐藏 Play/Tap 按钮以聚焦核心动作，未覆盖完整打开/关闭链。

成功：玩家动作序列从 0 开始；其他头像从 0.7 秒开始；1.2 秒启动旧台破碎及 Players 数字；数字历时 0.7 秒，1.9 秒完成并刷新 Levels。动作内部先等待 0.25 秒，随后 0.7 秒形变，路径插入该形变段 0.07 秒，路径耗时 0.56 秒。故玩家实际位移约 0.32～0.88 秒，其他头像约 1.02～1.58 秒。原曲线是三点 DOLocalPath，默认 Linear 路径与项目默认缓动；不是后续版本的 DOLocalJump。

失败：0.5 秒触发幸存头像动作；1.2 秒触发玩家及两个淘汰头像；1.7 秒台子破碎并开始 Players 更新；2.4 秒人数更新完成，Levels 保持失败前进度。淘汰头像完成首段后调用原 Disappear，再横移/下落 0.5 秒。

复现：从固定提交导出上述两个资源目录到隔离临时目录，对每个资源 meta 的 GUID 分配新值并同步所有内部引用，然后将目录导入 Assets/__SplashQuestBaseline_8ebcd7990；用 Unity Pipeline 执行 BaselinePreview.cs 的 SplashBaselinePreview.Run。预览成功后关闭临时场景并删除该临时 Assets 目录，不改变正式资源和存档。

本包保留原始五份 C#、预览驱动、GUID 映射及哈希；旧资源可由固定 Git 提交恢复，44 MB 原始资源包只留在 TS Temp/SplashQuestMotion/baseline/original-assets.tar，不重复放入资料库。
