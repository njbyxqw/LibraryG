using Interface.UI;
using Interface.Activity;
using Module.Activity.Flow;
using TransformUtils = Module.Utils.UtilsTransform;
using System.Collections.Generic;
using Module.Activity;
using Module.Activity.DiamondChampion;
using Module.DiamondChampion.Config;
using Betta.Framework;
using BettaSDK;
using DG.Tweening;

using Spine.Unity;
using UnityEngine;
using UnityEngine.UI;

public partial class UIActDiamondChampionMainPanel : UIWindow
{
    private PanelFlowArgs? _flow;
    private object _openParameter;
    private UnityEngine.Transform Transform => RectTransform;
    public void SetFlow(PanelFlowArgs? flow) => _flow = flow;
    public override void OnOpen(params object[] args)
    {
        base.OnOpen(args);
        if (RectTransform == null) return;
        foreach (var argument in args)
        {
            if (argument is PanelFlowArgs flow) _flow = flow;
            else if (argument != null) _openParameter = argument;
        }
        AssembleUI();
        OnInit();
        RegisterEvents();
        OnShow();
    }
    public override void OnClose()
    {
        OnHide();
        UnRegisterEvents();

        var flow = _flow;
        _flow = null;
        if (flow.HasValue && flow.Value.Token.IsValid)
            flow.Value.Executor?.TokenFinished(flow.Value.Token);
        base.OnClose();
    }

    protected override string AssetPath
    {
        get
        {
            if (_activity.IsInLoopStage())
            {
                return "Assets/Module/Activity/DiamondChampion/ResDLC/Default/Panel/Prefab/UIActDiamondChampionMainPanel_LoopStage.prefab";
            }

            return "Assets/Module/Activity/DiamondChampion/ResDLC/Default/Panel/Prefab/UIActDiamondChampionMainPanel.prefab";
        }
    }

    private ActDiamondChampion _activity => ImplementHub.Instance.Get<IActivitySystem>().GetActivity<ActDiamondChampion>();

    private List<UIDiamondChampionMapSection> _mapSections;

    private UIActDiamondChampionMainPanelParameter _parameter;

    private List<UIActDiamondChampionAnimPortrait> _animPortraits;

    private UIActDiamondChampionAnimPortrait _myAnimPortrait;

    private SkeletonGraphic _skeletonGraphicL;
    private SkeletonGraphic _skeletonGraphicR;
    private SkeletonGraphic _skeletonGraphicD;

    private Animator _normalRootAnimator;

    private Sequence _seq;
    private Tween _midChestLocateTween;

    private float _duration = 0.7f;

    private Tween _timerId1 = null;
    private Tween _timerId2 = null;

    private int _soundId = -1;

    private float _jumpInterval = 0.7f;

    private UIActDiamondChampionRewardDisplayPanel _rewardDisplayPanel;

    private ulong _timeRecord = 0;

    private const ulong HapticDuration = 2;

    private bool _hasMidChestInSettleSuccessFlow;
    private int _midChestLevelInSettleSuccessFlow = -1;
    private MidChest _midChestCfgInSettleSuccessFlow;
    private int[][] _midChestRewardsInSettleSuccessFlow;
    private bool _isPlayingSettleSuccessFlow;
    private int _bubbleTargetLevel = -1;
    private bool _isSettleSuccessDisplayState;
    private bool _isSettleFailDisplayState;
    private bool _isPlayingEnterRunInitAnim;
    private bool _isLocatingToMidChest;
    private bool _pendingShowPlayBtnAfterEnterRunInitAnim;
    private bool _allowSettleSuccessTapFastForward;
    private bool _hasFastForwardedSettleSuccessFlow;
    private bool _enterInitInputUnlocked;
    private bool _settleSuccessInputLockedDuringFlow;
    private bool _isReplacingSettleSuccessSequence;

    private void OnInit()
    {
        _parameter = _openParameter as UIActDiamondChampionMainPanelParameter;
        if (_parameter == null)
        {
            _parameter = new UIActDiamondChampionMainPanelParameter();
        }

        _activity.CheckTimeOut();

        _skeletonGraphicL = TransformUtils.Find<SkeletonGraphic>(trans_Decoration, "Content/QianJing_L");
        _skeletonGraphicR = TransformUtils.Find<SkeletonGraphic>(trans_Decoration, "Content/QianJing_R");
        _skeletonGraphicD = TransformUtils.Find<SkeletonGraphic>(trans_Decoration, "Content/QianJing_Down");
        TryResolveMidChestBubbleNodes();
        TryResolveNormalRootAnimator();
    }

    private void TryResolveNormalRootAnimator()
    {
        if (trans_NormalRoot == null)
        {
            return;
        }

        _normalRootAnimator = trans_NormalRoot.GetComponent<Animator>();
        if (_normalRootAnimator == null)
        {
            _normalRootAnimator = trans_NormalRoot.GetComponentInChildren<Animator>(true);
        }
    }

    private void OnShow()
    {
        RefreshUI();
    }

    private void OnHide()
    {
        if (_seq != null)
        {
            _seq.Kill();
            _seq = null;
        }
        _allowSettleSuccessTapFastForward = false;
        _hasFastForwardedSettleSuccessFlow = false;
        _enterInitInputUnlocked = false;
        _settleSuccessInputLockedDuringFlow = false;
        _isReplacingSettleSuccessSequence = false;
        _isPlayingEnterRunInitAnim = false;
        _pendingShowPlayBtnAfterEnterRunInitAnim = false;

        if (_midChestLocateTween != null)
        {
            _midChestLocateTween.Kill();
            _midChestLocateTween = null;
        }
        _isLocatingToMidChest = false;

        if (_mapSections != null)
        {
            for (int i = 0; i < _mapSections.Count; i++)
            {
                _mapSections[i].OnRelease();
            }
            _mapSections = null;
        }

        if (_animPortraits != null)
        {
            for (int i = 0; i < _animPortraits.Count; i++)
            {
                _animPortraits[i].OnRelease();
            }
            _animPortraits = null;
        }

        _myAnimPortrait?.OnRelease();
        _rewardDisplayPanel?.OnRelease();
        _rewardDisplayPanel = null;

        StopTimeLeftTimers();

        ImplementHub.Instance.Get<Interface.Sound.IAudioSystem>()?.StopAudio(_soundId);
        _parameter.CloseEvent?.Invoke();
    }

    private void RegisterEvents()
    {
        btn_Close.onClick.AddListener(OnClickClose);
        btn_Help.onClick.AddListener(OnClickHelp);
        btn_FullPageClose.onClick.AddListener(OnClickClose);
        btn_Play.onClick.AddListener(OnClickPlay);
        _btnBubble?.onClick.AddListener(OnClickMidChestLocatorBubble);

        scrollRect_Map.onValueChanged.AddListener(OnScroll);
    }

    private void UnRegisterEvents()
    {
        btn_Close.onClick.RemoveListener(OnClickClose);
        btn_Help.onClick.RemoveListener(OnClickHelp);
        btn_FullPageClose.onClick.RemoveListener(OnClickClose);
        btn_Play.onClick.RemoveListener(OnClickPlay);
        _btnBubble?.onClick.RemoveListener(OnClickMidChestLocatorBubble);

        scrollRect_Map.onValueChanged.RemoveListener(OnScroll);
    }

    private void OnClickPlay()
    {
        var game = ImplementHub.Instance.Get<Interface.Game.ILeveledGame>();
        if (game == null) return;
        var result = _flow.HasValue ? game.OpenGotoGamePanel(_flow.Value) : game.OpenGotoGamePanel();
        if (result == Interface.Game.GotoGameOpenResult.LevelEntryOpened ||
            result == Interface.Game.GotoGameOpenResult.LevelEntered)
        {
            _flow = null;
        }
        UIManager.Instance.Close(this, UIOperation.Click);
    }

    private void OnClickClose()
    {
        if (_isPlayingSettleSuccessFlow)
        {
            if (!_allowSettleSuccessTapFastForward)
            {
                return;
            }

            if (_hasFastForwardedSettleSuccessFlow)
            {
                return;
            }

            _hasFastForwardedSettleSuccessFlow = true;
            _seq?.Kill();
            _isPlayingSettleSuccessFlow = false;

            if (_activity != null && _activity.CurrentState == DiamondChampionState.Timeout)
            {
                TryHandleTimeoutFlow();
                return;
            }

            UIManager.Instance.Close<UIActDiamondChampionMainPanel>(UIOperation.Click);
            return;
        }
        if (_activity != null)
        {
            var shouldOpenStagePanel =
                _activity.DiamondChampionStateView == DiamondChampionState.Timeout ||
                (_isSettleFailDisplayState &&
                 !_activity.IsTerminalStageState());

            if (shouldOpenStagePanel)
            {
                _activity.OpenStagePanel(UIOperation.Auto, _flow);
                _flow = null;
            }
        }
        UIManager.Instance.Close<UIActDiamondChampionMainPanel>(UIOperation.Click);
    }

    private void OnClickHelp()
    {
        if (_isPlayingSettleSuccessFlow)
        {
            return;
        }
        if (_activity == null)
        {
            return;
        }
        _activity.OpenHelpPanel(UIOperation.Click);
    }

    private void OnScroll(Vector2 vector2)
    {
        trans_Decoration.GetComponent<ScrollRect>().verticalNormalizedPosition = vector2.y;
        RefreshMidChestLocatorBubbleVisibility();
        if (vector2.y == 0 || Mathf.Approximately(vector2.y, 1))
        {
            if (Mathf.Abs(UtilsTime.TimeSeconds - _timeRecord) > HapticDuration)
            {
                _timeRecord = UtilsTime.TimeSeconds;
                HapticsHub.Instance.DoHaptic(HapticsTypes.Light);
            }
        }
    }

    private void StopTimeLeftTimers()
    {
        if (_timerId1 != null)
        {
            _timerId1?.Kill();
            _timerId1 = null;
        }

        if (_timerId2 != null)
        {
            _timerId2?.Kill();
            _timerId2 = null;
        }
    }

    private void RefreshUI()
    {
        _activity.CheckTimeOut();
        StopTimeLeftTimers();

        var mainViewState = _activity.MainViewStateView;
        var failProgressBeforeSettle = _activity.FailProgressBeforeSettle();

        RefreshHeaderTimeTextsAndTimers();
        InitMap();
        InitAvatars();
        ResetRefreshTransientState(mainViewState);
        LogRefreshState(mainViewState, failProgressBeforeSettle);

        RenderMainPanelByViewState(mainViewState, failProgressBeforeSettle);
        RefreshPlayButtonState(mainViewState);
        FinalizeRefreshUI();
    }

    private void RefreshHeaderTimeTextsAndTimers()
    {
        txt_TimeLeft1.SetText(_activity.GetTimeString());
        _timerId1 = DOVirtual.DelayedCall(1, () => { txt_TimeLeft1.SetText(_activity.GetTimeString()); }, false).SetLoops(-1).SetLink(Transform.gameObject);
        txt_TimeLeft2.SetText(_activity.GetTimeString());
        _timerId2 = DOVirtual.DelayedCall(1, () => { txt_TimeLeft2.SetText(_activity.GetTimeString()); }, false).SetLoops(-1).SetLink(Transform.gameObject);
    }

    private void ResetRefreshTransientState(DiamondChampionMainViewState mainViewState)
    {
        SetMainPanelCloseButtonsVisible(false, false);
        _isPlayingSettleSuccessFlow = false;
        _isSettleSuccessDisplayState = mainViewState == DiamondChampionMainViewState.SettleSuccess;
        _isSettleFailDisplayState = mainViewState == DiamondChampionMainViewState.SettleFail;
        _isPlayingEnterRunInitAnim = false;
        _hasMidChestInSettleSuccessFlow = false;
        _midChestLevelInSettleSuccessFlow = -1;
        _midChestCfgInSettleSuccessFlow = null;
        _bubbleTargetLevel = -1;
        _pendingShowPlayBtnAfterEnterRunInitAnim = false;
        _allowSettleSuccessTapFastForward = false;
        _hasFastForwardedSettleSuccessFlow = false;
        _enterInitInputUnlocked = false;
        _settleSuccessInputLockedDuringFlow = false;
        _isReplacingSettleSuccessSequence = false;
    }

    private void SetMainPanelCloseButtonsVisible(bool closeVisible, bool? fullPageCloseVisible = null)
    {
        if (btn_Close != null)
        {
            btn_Close.gameObject.SetActive(closeVisible);
        }

        if (fullPageCloseVisible.HasValue && btn_FullPageClose != null)
        {
            btn_FullPageClose.gameObject.SetActive(fullPageCloseVisible.Value);
        }
    }

    private void LogRefreshState(DiamondChampionMainViewState mainViewState, int failProgressBeforeSettle)
    {
        UtilsLog.L(
            $"[DiamondChampion][MainPanel][RefreshUI] " +
            $"mainViewState={mainViewState}, " +
            $"stageViewState={_activity.StageViewStateView}, " +
            $"activityState={_activity.DiamondChampionStateView}, " +
            $"currentProgress={_activity.CurrentLevel()}/{_activity.MaxLevel()}, " +
            $"lastProgress={_activity.LastLevel()}/{_activity.MaxLevel()}, " +
            $"failProgressBeforeSettle={failProgressBeforeSettle}/{_activity.MaxLevel()}, " +
            $"leftPeople={_activity.LeftNumOfPeople()}, " +
            $"lastLeftPeople={_activity.LastLeftNumOfPeople()}, " +
            $"hasPendingWin={_activity.HasPendingWinRewardClaim()}, " +
            $"hasPendingLoop={_activity.HasPendingStageLoopAccumClaim()}, " +
            $"hasPendingTimeout={_activity.HasPendingTimeoutPopup()}"
        );
    }

    private void RenderMainPanelByViewState(DiamondChampionMainViewState mainViewState, int failProgressBeforeSettle)
    {
        if (mainViewState == DiamondChampionMainViewState.SettleSuccess)
        {
            RenderSettleSuccessState();
            return;
        }

        if (mainViewState == DiamondChampionMainViewState.SettleFail)
        {
            RenderSettleFailState(failProgressBeforeSettle);
            return;
        }

        if (mainViewState == DiamondChampionMainViewState.EnterRun && _parameter.PlayInitAnim)
        {
            RenderEnterRunInitAnimState();
            return;
        }

        RenderNormalState(mainViewState);
    }

    private void RenderSettleSuccessState()
    {
        PrepareSettleSuccessFlow();
        txt_LeftNum.SetText(_activity.LastLeftNumOfPeople().ToString());
        txt_Progress.SetText($"{_activity.LastLevel()}/{_activity.MaxLevel()}");
        trans_NormalRoot.gameObject.SetActive(true);
        trans_TimeOutRoot.gameObject.SetActive(false);
        txt_NormalDescription.SetLocale("str_id_DiamondChampion_ProgressTips2");
        PlaySuccessAnim();
    }

    private void RenderSettleFailState(int failProgressBeforeSettle)
    {
        txt_LeftNum.SetText(_activity.LastLeftNumOfPeople().ToString());
        txt_Progress.SetText($"{failProgressBeforeSettle}/{_activity.MaxLevel()}");
        trans_NormalRoot.gameObject.SetActive(false);
        trans_TimeOutRoot.gameObject.SetActive(true);
        txt_TimeOutDescription.SetLocale("str_id_DiamondChampion_ProgressTips4");
        PlayFailAnim();
    }

    private void RenderEnterRunInitAnimState()
    {
        _isPlayingEnterRunInitAnim = true;
        SetMidChestLocatorBubbleActive(false);
        if (btn_Play != null)
        {
            btn_Play.gameObject.SetActive(false);
        }
        _pendingShowPlayBtnAfterEnterRunInitAnim = true;

        txt_LeftNum.SetText(_activity.LastLeftNumOfPeople().ToString());
        txt_Progress.SetText($"{_activity.LastLevel()}/{_activity.MaxLevel()}");
        trans_NormalRoot.gameObject.SetActive(false);
        trans_TimeOutRoot.gameObject.SetActive(false);
        PlayInitAnim();
    }

    private void RenderNormalState(DiamondChampionMainViewState mainViewState)
    {
        trans_NormalRoot.gameObject.SetActive(true);
        trans_TimeOutRoot.gameObject.SetActive(false);
        txt_LeftNum.SetText(_activity.LeftNumOfPeople().ToString());
        txt_Progress.SetText($"{_activity.CurrentLevel()}/{_activity.MaxLevel()}");
        txt_NormalDescription.SetText(GetMainProgressTipsForNormalRoot(mainViewState));
        SetScrollVerticalNormalizedPosition();
        SetMainPanelCloseButtonsVisible(true, _parameter.LockScroll);
    }

    private void RefreshPlayButtonState(DiamondChampionMainViewState mainViewState)
    {
        if (btn_Play == null)
        {
            return;
        }

        var shouldShowPlayBtnThisTime = mainViewState == DiamondChampionMainViewState.EnterRun;
        var canShowNow = shouldShowPlayBtnThisTime &&
                         !_isPlayingSettleSuccessFlow &&
                         !_isPlayingEnterRunInitAnim &&
                         mainViewState != DiamondChampionMainViewState.SettleSuccess &&
                         mainViewState != DiamondChampionMainViewState.SettleFail &&
                         mainViewState != DiamondChampionMainViewState.Timeout;
        btn_Play.gameObject.SetActive(canShowNow);
    }

    private void FinalizeRefreshUI()
    {
        RefreshStageTitleTexts();
        _activity.RecordShowData();
        _activity.ConsumeMainViewState();
        RefreshMidChestLocatorBubbleVisibility();

        _soundId = ImplementHub.Instance.Get<Interface.Sound.IAudioSystem>()?.PlayAudio(Module.Audio.SoundConst.SFX_Temple_Stream, true, -1f) ?? -1;
    }

    private string GetMainProgressTipsForNormalRoot(DiamondChampionMainViewState mainViewState)
    {
        if (mainViewState == DiamondChampionMainViewState.Timeout)
        {
            return LocaleManager.GetText("str_id_DiamondChampion_ProgressTips4");
        }
        if (mainViewState == DiamondChampionMainViewState.EnterRun && !_parameter.PlayInitAnim)
        {
            return string.Format(LocaleManager.GetText("str_id_DiamondChampion_ProgressTips1"), _activity.MaxLevel());
        }
        return LocaleManager.GetText("str_id_DiamondChampion_ProgressTips2");
    }

    private void RefreshStageTitleTexts()
    {
        if (txt_Stage1 == null && txt_Stage2 == null)
        {
            return;
        }

        var key = _activity.GetCurrentStageTitleLocaleKey();
        if (string.IsNullOrEmpty(key))
        {
            if (txt_Stage1 != null)
            {
                txt_Stage1.SetText(string.Empty);
            }
            if (txt_Stage2 != null)
            {
                txt_Stage2.SetText(string.Empty);
            }
            return;
        }
        if (txt_Stage1 != null)
        {
            txt_Stage1.SetLocale(key);
        }
        if (txt_Stage2 != null)
        {
            txt_Stage2.SetLocale(key);
        }
    }
}
