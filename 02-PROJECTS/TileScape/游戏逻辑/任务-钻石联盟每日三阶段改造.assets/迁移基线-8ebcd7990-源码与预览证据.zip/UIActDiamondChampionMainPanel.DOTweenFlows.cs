using Interface.UI;
using TransformUtils = Module.Utils.UtilsTransform;
using Module.Activity.DiamondChampion;
using Betta.Framework;
using BettaSDK;
using DG.Tweening;

using System;

using UnityEngine;

public partial class UIActDiamondChampionMainPanel
{
    private const float MidChestPauseDuration = 0f;
    private const float MidChestFlyDuration = 0.5f;
    private const float EnterInitMidChestTipsDisplayDuration = 1.2f;

    private const float EnterInitScrollDuration = 0.83f;

    private int _successAnimCurrentLevelSnapshot = -1;
    private int _successAnimLastLevelSnapshot = -1;

    private void PlayInitAnim()
    {
        if (_seq != null)
        {
            _seq.Kill(true);
        }

        _seq = DOTween.Sequence();
        _seq.SetLink(Transform.gameObject);
        _seq.onKill += () =>
        {
            _isPlayingEnterRunInitAnim = false;
            _pendingShowPlayBtnAfterEnterRunInitAnim = false;
            if (!_enterInitInputUnlocked)
            {
                UtilsInput.Enable(true);
            }

            SetMainPanelCloseButtonsVisible(true, false);
        };

        var curValue = 1f;

        var contentHeight = scrollRect_Map.content.GetComponent<RectTransform>().rect.height;
        var viewportHeight = scrollRect_Map.viewport.GetComponent<RectTransform>().rect.height;
        if (contentHeight > viewportHeight)
        {
            var totalProgressHeight = contentHeight - viewportHeight;
            curValue = 1 - (300f / totalProgressHeight);
        }

        scrollRect_Map.verticalNormalizedPosition = curValue;
        _enterInitInputUnlocked = false;
        UtilsInput.Enable(false);
        SetMainPanelCloseButtonsVisible(false, false);
        var endValue = CalculateVerticalNormalizedPosition(_activity.LastLevel());
        var hasMidChestOnPath = TryGetEnterInitMidChestStopLevel(curValue, endValue, out var midChestStopLevel);

        foreach (var item in _animPortraits)
        {
            item.Transform.gameObject.SetActive(false);
        }

        _myAnimPortrait.Transform.gameObject.SetActive(false);
        scrollRect_Map.GetComponent<RectTransform>().localScale = Vector3.one * 2.15f;
        trans_Decoration.GetComponent<RectTransform>().localScale = Vector3.one * 2.15f;
        scrollRect_Map.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 20);
        trans_Root.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 850);
        trans_Root.gameObject.SetActive(false);

        _seq.AppendInterval(0f);
        _seq.AppendCallback(() =>
        {
            var animator = TransformUtils.Find<Animator>(_mapSections[_activity.MaxLevel()].Transform,
                "Root/ZhuanPan");
            if (animator != null)
            {
                animator.Play("BG_ZhuanPan");
                ImplementHub.Instance.Get<Interface.Sound.IAudioSystem>()?.PlayAudio(Module.Audio.SoundConst.SFX_Temple_StoneSpin, false, -1f);
            }
        });
        _seq.AppendCallback(PlayDecorationAppear);
        _seq.Append(scrollRect_Map.GetComponent<RectTransform>().DOScale(Vector3.one, 0.5f).SetEase(Ease.OutQuart));
        _seq.Join(trans_Decoration.GetComponent<RectTransform>().DOScale(Vector3.one, 0.5f).SetEase(Ease.OutQuart));
        _seq.AppendCallback(PlayLightHaptic);
        _seq.AppendInterval(1.2f);
        _seq.Append(scrollRect_Map.GetComponent<RectTransform>().DOAnchorPosY(0, 0.083f));
        if (hasMidChestOnPath)
        {
            AppendEnterInitScrollPhaseWithRuntimeTarget(_seq, () =>
            {
                var targetWorldY = RectTransform.rect.height / 2;
                var targetNorm = CalculateVerticalNormalizedPositionForMidChestCenter(midChestStopLevel, targetWorldY);
                UtilsLog.L(
                    $"[DiamondChampion][MainPanel][EnterInit] midChest runtime locate: level={midChestStopLevel}, targetWorldY={targetWorldY:F2}, targetNorm={targetNorm:F4}");
                return targetNorm;
            }, false);
            AppendEnterInitMidChestTipsSegment(_seq, midChestStopLevel);
            _seq.AppendInterval(_jumpInterval);
            AppendEnterInitScrollPhase(_seq, endValue, true);
        }
        else
        {
            AppendEnterInitScrollPhase(_seq, endValue, true);
        }

        _seq.AppendCallback(() =>
        {
            _myAnimPortrait.Transform.gameObject.SetActive(true);
            _myAnimPortrait.Appear();
        });
        _seq.AppendInterval(0.1f);
        foreach (var item in _animPortraits)
        {
            var portrait = item;
            _seq.AppendCallback(() =>
            {
                portrait.Transform.gameObject.SetActive(true);
                portrait.Appear();
            });

            _seq.AppendInterval(0.03f);
        }
        _seq.AppendInterval(1f);
        _seq.AppendCallback(() =>
        {
            _isPlayingEnterRunInitAnim = false;
            if (_pendingShowPlayBtnAfterEnterRunInitAnim && btn_Play != null)
            {
                btn_Play.gameObject.SetActive(true);
            }
            _pendingShowPlayBtnAfterEnterRunInitAnim = false;
            SetMainPanelCloseButtonsVisible(true, false);
            RefreshMidChestLocatorBubbleVisibility();
        });
        if (_activity.HelpLastPopTime() == 0)
        {
            _seq.AppendCallback(() =>
            {
                _activity.OpenHelpPanel(UIOperation.Auto);
                _activity.RecordHelpPop();
            });
        }
    }

    private void AppendEnterInitScrollPhase(Sequence seq, float targetNorm, bool joinShowRootAndDescription)
    {
        seq.Append(scrollRect_Map.DOVerticalNormalizedPos(targetNorm, EnterInitScrollDuration).SetEase(Ease.InOutCubic));
        JoinEnterInitScrollPhaseCommon(seq, joinShowRootAndDescription);
    }

    private void AppendEnterInitScrollPhaseWithRuntimeTarget(Sequence seq, Func<float> targetNormResolver,
        bool joinShowRootAndDescription)
    {
        Tween scrollTween = null;
        scrollTween = scrollRect_Map
            .DOVerticalNormalizedPos(Mathf.Clamp01(targetNormResolver.Invoke()), EnterInitScrollDuration)
            .SetEase(Ease.InOutCubic);
        seq.Append(scrollTween);
        JoinEnterInitScrollPhaseCommon(seq, joinShowRootAndDescription);
    }

    private void JoinEnterInitScrollPhaseCommon(Sequence seq, bool joinShowRootAndDescription)
    {
        if (joinShowRootAndDescription)
        {
            seq.JoinCallback(() =>
            {
                trans_Root.gameObject.SetActive(true);
                trans_NormalRoot.gameObject.SetActive(true);
                txt_NormalDescription.SetLocale("str_id_DiamondChampion_ProgressTips2");
                SetMainPanelCloseButtonsVisible(false, false);
            });

            seq.Join(
                DOTween.Sequence()
                    .SetLink(Transform.gameObject)
                    .Append(trans_Root.GetComponent<RectTransform>().DOAnchorPosY(-20, 0.25f).SetDelay(EnterInitScrollDuration * 0.8f))
                    .AppendInterval(0.083f)
                    .Append(trans_Root.GetComponent<RectTransform>().DOAnchorPosY(4, 0.07f))
                    .Append(trans_Root.GetComponent<RectTransform>().DOAnchorPosY(0, 0.1f))
                    .AppendCallback(OnEnterInitPanelDropSettled)
                );
        }

        seq.Join(DOTween.Sequence().SetLink(Transform.gameObject).AppendInterval(0.6f).AppendCallback(() =>
        {
            PlayDecorationAppear();
            PlayLightHaptic();
        }));
    }

    private void OnEnterInitPanelDropSettled()
    {
        if (_enterInitInputUnlocked)
        {
            return;
        }

        _enterInitInputUnlocked = true;
        UtilsInput.Enable(true);
        SetMainPanelCloseButtonsVisible(true, false);
    }

    private void AppendEnterInitMidChestTipsSegment(Sequence seq, int midChestLevel)
    {
        if (_mapSections == null || midChestLevel < 0 || midChestLevel >= _mapSections.Count)
        {
            return;
        }

        seq.AppendCallback(() =>
        {
            _mapSections[midChestLevel].SetChestTipsVisible(true);
        });
        seq.AppendInterval(EnterInitMidChestTipsDisplayDuration);
        seq.AppendCallback(() =>
        {
            _mapSections[midChestLevel].SetChestTipsVisible(false);
        });
    }

    private void PlayDecorationAppear()
    {
        if (_skeletonGraphicL != null && _skeletonGraphicL.AnimationState != null)
        {
            _skeletonGraphicL.AnimationState.SetAnimation(0, "Appear", false);
        }

        if (_skeletonGraphicR != null && _skeletonGraphicR.AnimationState != null)
        {
            _skeletonGraphicR.AnimationState.SetAnimation(0, "Appear", false);
        }

        if (_skeletonGraphicD != null && _skeletonGraphicD.AnimationState != null)
        {
            _skeletonGraphicD.AnimationState.SetAnimation(0, "Appear", false);
        }
    }

    private static void PlayLightHaptic()
    {
        HapticsHub.Instance.DoHaptic(HapticsTypes.Light);
    }

    private void PlaySuccessAnim()
    {
        if (_seq != null)
        {
            _seq.Kill(true);
        }

        _successAnimCurrentLevelSnapshot = _activity.CurrentLevel();
        _successAnimLastLevelSnapshot = _activity.LastLevel();

        var sectionCount = _mapSections?.Count ?? 0;
        if (_successAnimCurrentLevelSnapshot < 0 || _successAnimCurrentLevelSnapshot >= sectionCount ||
            _successAnimLastLevelSnapshot < 0 || _successAnimLastLevelSnapshot >= sectionCount)
        {
            UtilsLog.E(
                $"[DiamondChampion][MainPanel][PlaySuccessAnim] Invalid map progress; skip success animation. " +
                $"configId={_activity.ConfigID}, stageIndex={_activity.GetCurrentStageIndex()}, " +
                $"currentProgress={_successAnimCurrentLevelSnapshot}, lastProgress={_successAnimLastLevelSnapshot}, " +
                $"maxLevel={_activity.MaxLevel()}, sectionCount={sectionCount}, " +
                $"activityState={_activity.CurrentState}, mainViewState={_activity.MainViewStateView}, " +
                $"stageViewState={_activity.StageViewStateView}, " +
                $"hasPendingWin={_activity.HasPendingWinRewardClaim()}, " +
                $"hasPendingLoop={_activity.HasPendingStageLoopAccumClaim()}");
            _isPlayingSettleSuccessFlow = false;
            ReleaseSettleSuccessInputLock();
            SetMainPanelCloseButtonsVisible(true, true);
            return;
        }

        var curSection = _mapSections[_successAnimCurrentLevelSnapshot];
        var lastSection = _mapSections[_successAnimLastLevelSnapshot];

        var applyFromFirstLevelUp = _successAnimLastLevelSnapshot == 0 && _successAnimCurrentLevelSnapshot == 1;
        var applyToLastLevelDown = _successAnimLastLevelSnapshot == _activity.MaxLevel() - 1 && _successAnimCurrentLevelSnapshot == _activity.MaxLevel();

        var failNum = Mathf.Min(Mathf.Min(_activity.LastLeftNumOfPeople() - _activity.LeftNumOfPeople(), 3),
            _animPortraits.Count);
        var target = curSection.GetItemParent();
        SetScrollVerticalNormalizedPosition();

        _allowSettleSuccessTapFastForward = CanUseSettleSuccessTapFastForward();
        _hasFastForwardedSettleSuccessFlow = false;
        _settleSuccessInputLockedDuringFlow = !_allowSettleSuccessTapFastForward;

        _seq = DOTween.Sequence();
        _seq.SetLink(Transform.gameObject);
        AttachSettleSuccessSequenceKillHandler(_seq);
        if (_settleSuccessInputLockedDuringFlow)
        {
            UtilsInput.Enable(false);
            SetMainPanelCloseButtonsVisible(false, false);
        }
        else
        {
            SetMainPanelCloseButtonsVisible(true, true);
        }

        _isPlayingSettleSuccessFlow = true;
        _seq.AppendCallback(() =>
        {
            SetMidChestLocatorBubbleActive(false);
        });
        if (_hasMidChestInSettleSuccessFlow)
        {
            SetScrollVerticalNormalizedPosition();
            AppendSuccessAvatarJumpSegment(_seq, curSection, lastSection, target, failNum, applyFromFirstLevelUp,
                applyToLastLevelDown);
            AppendMidChestSegment(_seq, () =>
            {
                PlaySuccessSettleFlowAfterMidChest();
            });
            return;
        }

        AppendSuccessAvatarAndPostSegment(_seq, curSection, lastSection, target, failNum, applyFromFirstLevelUp,
            applyToLastLevelDown);
    }

    private void AttachSettleSuccessSequenceKillHandler(Sequence seq)
    {
        seq.onKill += () =>
        {
            if (_isReplacingSettleSuccessSequence)
            {
                return;
            }

            _isPlayingSettleSuccessFlow = false;
            ReleaseSettleSuccessInputLock();
        };
    }

    private void ReleaseSettleSuccessInputLock()
    {
        if (!_settleSuccessInputLockedDuringFlow)
        {
            return;
        }

        UtilsInput.Enable(true);
        _settleSuccessInputLockedDuringFlow = false;
    }

    private void AcquireSettleSuccessInputLock()
    {
        if (_settleSuccessInputLockedDuringFlow)
        {
            return;
        }

        UtilsInput.Enable(false);
        _settleSuccessInputLockedDuringFlow = true;
    }

    private void PlayFailAnim()
    {
        if (_seq != null)
        {
            _seq.Kill(true);
        }

        var failProgress = GetMapProgressForDisplay();
        var curSection = _mapSections[failProgress];
        var lastSection = _mapSections[failProgress];

        var maxLevel = _activity.MaxLevel();
        var nextProgress = Mathf.Min(failProgress + 1, maxLevel);
        var hasSurvivorForwardJump = nextProgress > failProgress;
        var applyFromFirstLevelUp = failProgress == 0 && hasSurvivorForwardJump;
        var applyToLastLevelDown = failProgress == maxLevel - 1 && nextProgress == maxLevel;

        var failNum = Mathf.Min(Mathf.Min(_activity.LastLeftNumOfPeople() - _activity.LeftNumOfPeople() - 1, 2),
            _animPortraits.Count);
        var fallTarget = curSection.GetItemParent();
        var survivorJumpTarget =
            hasSurvivorForwardJump ? _mapSections[nextProgress].GetItemParent() : fallTarget;
        SetScrollVerticalNormalizedPosition();
        _seq = DOTween.Sequence();
        _seq.SetLink(Transform.gameObject);

        UtilsInput.Enable(false);
        _seq.AppendInterval(0.5f);
        _seq.AppendCallback(() =>
        {
            if (!hasSurvivorForwardJump)
            {
                return;
            }

            for (int i = 0; i < _animPortraits.Count - failNum; i++)
            {
                _animPortraits[i].JumpToNext(survivorJumpTarget, _duration);
            }
        });
        _seq.AppendInterval(_jumpInterval);
        _seq.AppendCallback(() =>
        {
            _myAnimPortrait.FallDown(fallTarget, curSection.GetRandomFailPosOffset(), _duration,
                applyFromFirstLevelUp: false);
            for (int i = _animPortraits.Count - failNum; i < _animPortraits.Count; i++)
            {
                _animPortraits[i].FallDown(fallTarget, curSection.GetRandomFailPosOffset(), _duration,
                    applyFromFirstLevelUp: false);
            }
        });
        _seq.AppendInterval(0.5f);
        _seq.AppendCallback(lastSection.PillarBreak);
        _seq.Append(
            DOTween.To(
                    () => _activity.LastLeftNumOfPeople(),
                    x => { txt_LeftNum.SetText(x.ToString()); },
                    _activity.LeftNumOfPeople(),
                    _duration)
                .OnComplete(() => { txt_Progress.SetText($"{failProgress}/{_activity.MaxLevel()}"); })
        );
        _seq.OnComplete(() =>
        {
            btn_FullPageClose.gameObject.SetActive(true);
            UtilsInput.Enable(true);
            RefreshMidChestLocatorBubbleVisibility();
            TryHandleTimeoutFlow();
        });
    }

    private void PrepareSettleSuccessFlow()
    {
        _hasMidChestInSettleSuccessFlow = _activity.TryPrepareMidChestOnSettleSuccessEnter(
            out _midChestLevelInSettleSuccessFlow,
            out _midChestRewardsInSettleSuccessFlow);
        _midChestCfgInSettleSuccessFlow = _hasMidChestInSettleSuccessFlow ? TryGetMapChestCfgByLevel(_midChestLevelInSettleSuccessFlow) : null;
        if (_hasMidChestInSettleSuccessFlow && _midChestCfgInSettleSuccessFlow == null)
        {
            _hasMidChestInSettleSuccessFlow = false;
            _midChestLevelInSettleSuccessFlow = -1;
        }
        UtilsLog.L($"[DiamondChampion][MainPanel][SettleSuccessFlow] hasMidChest={_hasMidChestInSettleSuccessFlow}, midChestLevel={_midChestLevelInSettleSuccessFlow}");
    }

    private bool CanUseSettleSuccessTapFastForward()
    {
        if (_hasMidChestInSettleSuccessFlow)
        {
            return false;
        }

        if (_activity.HasPendingWinRewardClaim())
        {
            return false;
        }

        if (_activity.HasPendingStageLoopAccumClaim())
        {
            return false;
        }

        return true;
    }

    private void AppendSuccessCoreSegment(Sequence seq, UIDiamondChampionMapSection curSection, UIDiamondChampionMapSection lastSection, RectTransform target, int failNum,
        bool applyFromFirstLevelUp, bool applyToLastLevelDown)
    {
        if (_successAnimCurrentLevelSnapshot < 0 || _successAnimLastLevelSnapshot < 0)
        {
            _successAnimCurrentLevelSnapshot = _activity.CurrentLevel();
            _successAnimLastLevelSnapshot = _activity.LastLevel();
        }

        if (_successAnimCurrentLevelSnapshot == _successAnimLastLevelSnapshot)
        {
            return;
        }

        seq.AppendCallback(() =>
        {
            _myAnimPortrait.JumpToNext(target, _duration);
        });
        seq.AppendInterval(_jumpInterval);
        seq.AppendCallback(() =>
        {
            for (int i = 0; i < _animPortraits.Count; i++)
            {
                if (i < _animPortraits.Count - failNum)
                {
                    _animPortraits[i].JumpToNext(target, _duration);
                }
                else
                {
                    _animPortraits[i].FallDown(target, curSection.GetRandomFailPosOffset(), _duration,
                        applyFromFirstLevelUp: applyFromFirstLevelUp);
                }
            }
        });
        seq.AppendInterval(0.5f);
        seq.AppendCallback(lastSection.PillarBreak);
        var anim = DOTween.To(
            () => _activity.LastLeftNumOfPeople(),
            x =>
            {
                txt_LeftNum.SetText(x.ToString());
            },
            _activity.LeftNumOfPeople(),
            _duration).OnComplete(() =>
        {
            txt_Progress.SetText($"{_activity.CurrentLevel()}/{_activity.MaxLevel()}");
            trans_Effect_PenShe.gameObject.SetActive(true);
        });
        seq.Append(anim);
        seq.onKill += () =>
        {
            anim?.Kill();
            txt_LeftNum?.SetText(_activity.LeftNumOfPeople().ToString());
            txt_Progress?.SetText($"{_activity.CurrentLevel()}/{_activity.MaxLevel()}");
            trans_Effect_PenShe?.gameObject.SetActive(true);

            _myAnimPortrait?.FastJump(target);

            if (_animPortraits != null && _animPortraits.Count > 0)
            {
                for (int i = 0; i < _animPortraits.Count; i++)
                {
                    if (i < _animPortraits.Count - failNum)
                    {
                        _animPortraits[i].FastJump(target);
                    }
                    else
                    {
                        _animPortraits[i].FastFall(target, curSection.GetRandomFailPosOffset(), _duration,
                            applyFromFirstLevelUp: applyFromFirstLevelUp);
                    }
                }
            }
        };
    }

    private void AppendSuccessAvatarAndPostSegment(Sequence seq, UIDiamondChampionMapSection curSection,
        UIDiamondChampionMapSection lastSection, RectTransform target, int failNum, bool applyFromFirstLevelUp,
        bool applyToLastLevelDown)
    {
        AppendSuccessAvatarJumpSegment(seq, curSection, lastSection, target, failNum, applyFromFirstLevelUp,
            applyToLastLevelDown);
        AppendSuccessSettleSegment(seq);
    }

    private void AppendSuccessAvatarJumpSegment(Sequence seq, UIDiamondChampionMapSection curSection,
        UIDiamondChampionMapSection lastSection, RectTransform target, int failNum, bool applyFromFirstLevelUp,
        bool applyToLastLevelDown)
    {
        AppendSuccessCoreSegment(seq, curSection, lastSection, target, failNum, applyFromFirstLevelUp,
            applyToLastLevelDown);
        seq.AppendInterval(0.1f);
    }

    private void AppendSuccessSettleSegment(Sequence seq)
    {
        if (_activity.HasPendingWinRewardClaim())
        {
            seq.AppendCallback(() =>
            {
                ReleaseSettleSuccessInputLock();

                var param = new UIActDiamondChampionWinPanelParameter();
                var count = Mathf.Min(Mathf.Min(_activity.LeftNumOfPeople() - 1, 5), _animPortraits.Count);
                for (var i = 0; i < count; i++)
                {
                    param.PortraitInfos.Add(_animPortraits[i].GetPortraitInfo());
                }

                _activity.OpenWinPanel(UIOperation.Click, param, _flow);
                _flow = null;
                UIManager.Instance.Close(this, UIOperation.Auto);
            });
        }

        seq.OnComplete(() =>
        {
            _isPlayingSettleSuccessFlow = false;
            ReleaseSettleSuccessInputLock();

            if (!_activity.HasPendingWinRewardClaim())
            {
                SetMainPanelCloseButtonsVisible(true, true);
                TryHandleTimeoutFlow();
            }

            RefreshMidChestLocatorBubbleVisibility();
        });
    }

    private void PlaySuccessSettleFlowAfterMidChest()
    {
        if (_seq != null)
        {
            _isReplacingSettleSuccessSequence = true;
            _seq.Kill(true);
            _isReplacingSettleSuccessSequence = false;
        }

        _seq = DOTween.Sequence();
        _seq.SetLink(Transform.gameObject);
        AttachSettleSuccessSequenceKillHandler(_seq);
        _isPlayingSettleSuccessFlow = true;
        AppendSuccessSettleSegment(_seq);
    }

    private void AppendMidChestSegment(Sequence seq, Action onMidChestRewardPanelClosed)
    {
        if (!_hasMidChestInSettleSuccessFlow || _midChestLevelInSettleSuccessFlow < 0 || _midChestLevelInSettleSuccessFlow >= _mapSections.Count || _midChestCfgInSettleSuccessFlow == null)
        {
            onMidChestRewardPanelClosed?.Invoke();
            return;
        }

        var startWorldPos = _mapSections[_midChestLevelInSettleSuccessFlow].GetMidChestWorldPosition();
        var boxClone = new Module.Reward.UIRewardBoxItem(trans_Root, _midChestCfgInSettleSuccessFlow.assetPath, _midChestRewardsInSettleSuccessFlow, 140f);
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            trans_Root,
            RectTransformUtility.WorldToScreenPoint(ImplementHub.Instance.Get<Interface.Cameras.ICameraModule>().UICamera, startWorldPos),
            ImplementHub.Instance.Get<Interface.Cameras.ICameraModule>().UICamera,
            out Vector2 startLocal);
        boxClone.Transform.localPosition = startLocal;
        boxClone.Transform.localScale = Vector3.one;
        boxClone.Transform.gameObject.SetActive(false);

        seq.AppendCallback(() =>
        {
            if (_mapSections != null)
            {
                _mapSections[_midChestLevelInSettleSuccessFlow].SetMidChestVisible(false);
            }
            SetMidChestLocatorBubbleActive(false);
            _mapSections[_midChestLevelInSettleSuccessFlow].PlayMidChestOpenAnim();
            boxClone.Transform.localScale = Vector3.one;
            boxClone.Transform.gameObject.SetActive(true);
        });
        seq.AppendInterval(MidChestPauseDuration);
        seq.Append(boxClone.Transform.DOLocalPath(
                new[]
                {
                    boxClone.Transform.localPosition,
                    (boxClone.Transform.localPosition + Vector3.zero) * 0.5f + new Vector3(0f, 280f, 0f),
                    Vector3.zero
                },
                MidChestFlyDuration,
                PathType.CatmullRom,
                PathMode.Ignore)
            .SetEase(Ease.OutCubic)
            .SetLink(boxClone.Transform.gameObject));
        seq.Join(boxClone.Transform.DOScale(Vector3.one * 2f, MidChestFlyDuration)
            .SetEase(Ease.OutCubic)
            .SetLink(boxClone.Transform.gameObject));
        seq.AppendCallback(() =>
        {
            ReleaseSettleSuccessInputLock();
            ShowMidChestPreviewRewardPanel(_midChestCfgInSettleSuccessFlow, _midChestRewardsInSettleSuccessFlow, () =>
            {
                AcquireSettleSuccessInputLock();
                UtilsLog.L("[DiamondChampion][MainPanel][MidChest] reward panel closed, resume success jump flow.");
                onMidChestRewardPanelClosed?.Invoke();
            });
            boxClone.Release();
            TransformUtils.Destroy(boxClone.Transform.gameObject);
        });
    }

    private void TryHandleTimeoutFlow()
    {
        if (_activity.CurrentState == DiamondChampionState.Timeout)
        {
            _activity.OpenTipsPanel(UIOperation.Auto, DiamondChampionTipsViewState.Timeout, _flow);
            _flow = null;
            UIManager.Instance.Close<UIActDiamondChampionMainPanel>(UIOperation.Auto);
        }
    }
}
