using System;
using System.IO;
using System.Threading.Tasks;
using System.Reflection;
using System.Collections.Generic;
using Betta.Framework;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;
public static class SplashBaselinePreview
{
 const string Base="Assets/__SplashQuestBaseline_8ebcd7990/ResDLC/Default/Panel/Prefab/";
 public static async Task<string> Run(){
  var field=typeof(DOTween).GetField("initialized",BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic);var old=field.GetValue(null);field.SetValue(null,true);
  try{Directory.CreateDirectory("Temp/SplashQuestMotion/baseline/frames");await Render(false);await Render(true);return "baseline rendered";}finally{field.SetValue(null,old);}
 }
 static GameObject Add(string path,Transform parent){var g=(GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>(Base+path),parent);PrefabUtility.UnpackPrefabInstance(g,PrefabUnpackMode.Completely,InteractionMode.AutomatedAction);return g;}
 static AnimationClip Clip(Transform root,string name){var a=root.GetComponent<Animator>();if(a==null||a.runtimeAnimatorController==null)return null;foreach(var c in a.runtimeAnimatorController.animationClips)if(c.name==name)return c;return null;}
 static Sequence Jump(Transform avatar,Transform target,bool fail,Vector2 fallOffset){
  var rect=(RectTransform)avatar;var start=rect.anchoredPosition;
  var end=(Vector2)avatar.parent.InverseTransformPoint(target.position)+(fail?fallOffset:start);
  float x=fail?0:Mathf.Abs(start.x-end.x)*.2f;
  float y=fail?Mathf.Abs(start.x-end.x)/2:Mathf.Abs(start.y-end.y)/2*1.3f;
  var middle=new Vector2((start.x+end.x)/2+x,(start.y+end.y)/2+y);
  var seq=DOTween.Sequence();seq.AppendInterval(.25f);
  var anim=DOTween.Sequence();float d=.7f;
  anim.Append(rect.DOScale(new Vector2(1.1f,.95f),.1f*d));
  anim.Append(rect.DOScale(new Vector2(.8f,1.3f),.1f*d));
  anim.Append(rect.DOScale(new Vector2(.8f,1.3f),.3f*d));
  anim.Append(rect.DOScale(new Vector2(.8f,1.3f),.3f*d));
  anim.Append(rect.DOScale(new Vector2(1.1f,.95f),.1f*d));
  anim.Append(rect.DOScale(new Vector2(1,1),.1f*d));
  anim.Insert(.1f*d,rect.DOLocalPath(new Vector3[]{start,middle,end},.8f*d));seq.Append(anim);
  if(fail){seq.Append(rect.DOLocalMoveY(end.y-400,.5f));seq.Join(rect.DOLocalMoveX(end.x-(fallOffset.x-(fallOffset.x>0?100:-100))/300*100,.5f));}
  else seq.AppendInterval(.5f);
  return seq;
 }
 static async Task Render(bool failed){
  var previousScene=SceneManager.GetActiveScene();var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);
  GameObject go=null,cameraGo=null;RenderTexture rt=null;Sequence sequence=null;
  try{
   go=(GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>(Base+"UIActDiamondChampionMainPanel.prefab"),scene);PrefabUtility.UnpackPrefabInstance(go,PrefabUnpackMode.Completely,InteractionMode.AutomatedAction);go.SetActive(true);
   cameraGo=new GameObject("BaselineCamera",typeof(Camera));SceneManager.MoveGameObjectToScene(cameraGo,scene);var camera=cameraGo.GetComponent<Camera>();camera.scene=scene;camera.overrideSceneCullingMask=EditorSceneManager.GetSceneCullingMask(scene);camera.orthographic=true;camera.orthographicSize=960;camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(.08f,.12f,.15f);camera.transform.position=new Vector3(0,0,-100);camera.nearClipPlane=.1f;camera.farClipPlane=3000;
   rt=new RenderTexture(540,960,24);camera.targetTexture=rt;
   var canvas=go.GetComponent<Canvas>();if(canvas==null)canvas=go.AddComponent<Canvas>();canvas.renderMode=RenderMode.WorldSpace;canvas.worldCamera=camera;((RectTransform)go.transform).sizeDelta=new Vector2(1080,1920);go.transform.position=Vector3.zero;go.transform.localScale=Vector3.one;var scaler=go.GetComponent<CanvasScaler>();if(scaler!=null)scaler.enabled=false;
   var map=(RectTransform)go.transform.Find("scrollRect_Map/Viewport/Content/trans_MapRoot");
   var background=go.transform.Find("scrollRect_Map/Viewport/Content/trans_BackgroundRoot");
   var sections=new List<Transform>();
   for(int i=0;i<=7;i++){string type=i==0?"Bottom":i==7?"Top":i%2==0?"MiddleLeft":"MiddleRight";var section=Add("MapSections/DiamondChampionMapSection"+type+".prefab",map).transform;section.SetAsFirstSibling();sections.Add(section);}
   LayoutRebuilder.ForceRebuildLayoutImmediate(map);Canvas.ForceUpdateCanvases();float h=map.GetComponent<VerticalLayoutGroup>().preferredHeight;for(int i=0;i<h/824f;i++)Add("MapSections/DiamondChampionMapBackground.prefab",background);
   foreach(var a in go.GetComponentsInChildren<Animator>(true))a.enabled=false;
   foreach(var cg in go.GetComponentsInChildren<CanvasGroup>(true))cg.alpha=1;
   go.transform.Find("trans_Root/trans_TimeOutRoot").gameObject.SetActive(false);go.transform.Find("trans_Root/trans_NormalRoot").gameObject.SetActive(true);go.transform.Find("trans_Root/trans_ViewRect/trans_Bubble").gameObject.SetActive(false);
   EditorApplication.QueuePlayerLoopUpdate();await Task.Delay(150);Canvas.ForceUpdateCanvases();
   var scroll=go.transform.Find("scrollRect_Map").GetComponent<ScrollRect>();var total=scroll.content.rect.height-scroll.viewport.rect.height;scroll.verticalNormalizedPosition=total>0?Mathf.Clamp01(((RectTransform)sections[0]).rect.height/total):1;Canvas.ForceUpdateCanvases();
   var parent=go.transform.Find("scrollRect_Map/Viewport/Content/trans_ItemParent");var target=sections[2].Find("Root/Background/ItemRoot");var current=sections[1].Find("Root/Background/ItemRoot");parent.position=current.position;
   var mine=parent.Find("MyPortrait");var robots=new List<Transform>();for(int i=parent.childCount-1;i>=0;i--){var child=parent.GetChild(i);child.gameObject.SetActive(true);var appear=Clip(child,"Appear");if(appear!=null)appear.SampleAnimation(child.gameObject,appear.length);if(child!=mine)robots.Add(child);}
   foreach(var label in go.GetComponentsInChildren<UIText>(true)){switch(label.localeKey){
    case "str_id_TapToContinue": label.SetText("Tap to continue"); break;
    case "str_id_Temple_Title": label.SetText("TEMPLE QUEST"); break;
    case "str_id_Temple_OpenTips01": label.SetText("Beat {0} levels without failing to win the challenge!"); break;
    case "str_id_Temple_OpenTips02": label.SetText("Beat {0} levels to win the challenge!"); break;
    case "str_id_Temple_Start": label.SetText("Start"); break;
    case "str_id_Temple_GrandPrize": label.SetText("Grand Prize"); break;
    case "str_id_Temple_MatchTips": label.SetText("Finding players on your level"); break;
    case "str_id_Temple_TapToContinue": label.SetText("Tap To Continue"); break;
    case "str_id_Temple_Levels": label.SetText("Levels"); break;
    case "str_id_Temple_Players": label.SetText("Players"); break;
    case "str_id_Temple_GrandPrizeTips": label.SetText("The grand prize will be shared equally between winners!"); break;
    case "str_id_Temple_PillarTips": label.SetText("Beat levels on your first try to advance to the next step!"); break;
    case "str_id_Temple_PlayerTips": label.SetText("There are {0} players in the challenge!"); break;
    case "str_id_Temple_HelpTips01": label.SetText("Start with 100 players!"); break;
    case "str_id_Temple_HelpTips02": label.SetText("Beat levels\\nwithout <color=#FFC107>failing</color>!"); break;
    case "str_id_Temple_HelpTips03": label.SetText("Win your share of \\n10 000 diamonds!"); break;
    case "str_id_Temple_HelpTips04": label.SetText("You will fail the challenge if you fail a level!"); break;
    case "str_id_Temple_WinTips": label.SetText("Congratulations!\\nYou advanced to the next step!"); break;
    case "str_id_Temple_FailTips": label.SetText("You failed the challenge.\\nBetter luck next time!"); break;
    case "str_id_Temple_CompleteTips": label.SetText("Congratulations!\\nYou advanced to the next step!"); break;
    case "str_id_Temple_ClaimTips01": label.SetText("You win"); break;
    case "str_id_Temple_ClaimTips02": label.SetText("You are sharing the reward with {0} other winners!"); break;
    case "str_id_Temple_CooldownTips": label.SetText("You failed the challenge.\\nNext Temple Quest will start in:"); break;
    case "str_id_Temple_OverTips": label.SetText("Temple Quest is over!\\nBetter luck next time!"); break;
    case "str_id_DiamondChampion_Title": label.SetText("DIAMOND LEAGUE"); break;
    case "str_id_DiamondChampion_Sign1": label.SetText("Grand Prize"); break;
    case "str_id_DiamondChampion_Sign2": label.SetText("See you next time!"); break;
    case "str_id_DiamondChampion_Sign3": label.SetText("See you next time!"); break;
    case "str_id_DiamondChampion_OpenTips1": label.SetText("Beat levels without failing to win the challenge!"); break;
    case "str_id_DiamondChampion_OpenTips2": label.SetText("Unstoppable!\\nCongrats, you're the ultimate winner!"); break;
    case "str_id_DiamondChampion_OpenTips3": label.SetText("The event has ended, try again next time!"); break;
    case "str_id_DiamondChampion_StageTitle1": label.SetText("ROOKIE"); break;
    case "str_id_DiamondChampion_StageTitle2": label.SetText("ELITE"); break;
    case "str_id_DiamondChampion_StageTitle3": label.SetText("KING"); break;
    case "str_id_DiamondChampion_RewardTips1": label.SetText("Boosters"); break;
    case "str_id_DiamondChampion_RewardTips2": label.SetText("Up to"); break;
    case "str_id_DiamondChampion_LevelTips": label.SetText("Levels"); break;
    case "str_id_DiamondChampion_RocketTips": label.SetText("Rocket Tiles active, easier clears!"); break;
    case "str_id_DiamondChampion_FailTips": label.SetText("Don't give up, try again after cooldown!"); break;
    case "str_id_DiamondChampion_CooldownTips": label.SetText("On cooldown, please wait..."); break;
    case "str_id_DiamondChampion_FinishTips": label.SetText("Great! You've got all rewards!"); break;
    case "str_id_DiamondChampion_EndTips": label.SetText("So close! The event has ended."); break;
    case "str_id_DiamondChampion_BonusTips": label.SetText("Total wins <color=#FFCC00>{0}</color>, earned <color=#FFCC00>Honor Reward</color>!"); break;
    case "str_id_DiamondChampion_HelpTips1": label.SetText("Start with 100 players!"); break;
    case "str_id_DiamondChampion_HelpTips2": label.SetText("Beat levels\\nwithout <color=#FFC107>failing</color>!"); break;
    case "str_id_DiamondChampion_HelpTips3": label.SetText("Win your share of <color=#FFC107>\\nHUGE</color> rewards!"); break;
    case "str_id_DiamondChampion_HelpTips4": label.SetText("You will fail the challenge if you fail a level!"); break;
    case "str_id_DiamondChampion_MatchTips": label.SetText("Finding players on your level"); break;
    case "str_id_DiamondChampion_ClaimTips1": label.SetText("You win"); break;
    case "str_id_DiamondChampion_ClaimTips2": label.SetText("You are sharing the reward with {0} other winners!"); break;
    case "str_id_DiamondChampion_ClaimTips3": label.SetText("You and {0} other winners have won the reward!"); break;
    case "str_id_DiamondChampion_ProgressTips1": label.SetText("Beat {0} levels to win the challenge!"); break;
    case "str_id_DiamondChampion_ProgressTips2": label.SetText("Congratulations!\\nYou advanced to the next step!"); break;
    case "str_id_DiamondChampion_ProgressTips3": label.SetText("Congratulations!\\nYou advanced to the next step!"); break;
    case "str_id_DiamondChampion_ProgressTips4": label.SetText("You failed the challenge.\\nBetter luck next time!"); break;
    case "str_id_DiamondChampion_Levels": label.SetText("Levels"); break;
    case "str_id_DiamondChampion_Players": label.SetText("Players"); break;
    case "str_id_DiamondChampion_GrandPrize": label.SetText("Grand Prize"); break;
    case "str_id_DiamondChampion_GrandPrizeTips": label.SetText("The grand prize will be shared equally between winners!"); break;
    case "str_id_DiamondChampion_GrandPrizeTips2": label.SetText("Win to get the grand prize!"); break;
    case "str_id_DiamondChampion_PillarTips": label.SetText("Beat levels on your first try to advance to the next step!"); break;
    case "str_id_DiamondChampion_PlayerTips": label.SetText("There are {0} players in the challenge!"); break;
    case "str_id_DiamondChampion_WinnerCup": label.SetText("King Cup"); break;
    case "str_id_TileUI_retain_DiamondChampion1": label.SetText("You will fail the <color=#B61111>Diamond League</color>"); break;
    case "str_id_TileUI_retain_DiamondChampion2": label.SetText("You will lose the <color=#B61111>Lightning Ball</color> and fail the <color=#B61111>Diamond League</color>."); break;
    case "str_id_TileUI_retain_DiamondChampion3": label.SetText("So close! You will lose up to <color=#B61111>{0}</color> diamonds!"); break;
   }}
   go.transform.Find("trans_Root/btn_Play").gameObject.SetActive(false);
   go.transform.Find("trans_Root/btn_FullPageClose").gameObject.SetActive(false);
   go.transform.Find("trans_Root/trans_NormalRoot/Stage/txt_Stage1").GetComponent<UIText>().SetText("ROOKIE");
   go.transform.Find("trans_Root/trans_NormalRoot/txt_NormalDescription").GetComponent<UIText>().SetText(failed?"You failed the challenge.\nBetter luck next time!":"Congratulations!\nYou advanced to the next step!");
   var progress=go.transform.Find("trans_Root/trans_NormalRoot/Progress/txt_Progress").GetComponent<UIText>();var people=go.transform.Find("trans_Root/trans_NormalRoot/LeftNum/txt_LeftNum").GetComponent<UIText>();progress.SetText("1/7");people.SetText("100");
   sequence=DOTween.Sequence().SetUpdate(UpdateType.Manual).SetAutoKill(false);
   var losers=new List<Transform>();int failCount=failed?2:3;
   if(failed){sequence.Insert(1.2f,Jump(mine,current,true,new Vector2(-280,-60)));losers.Add(mine);}else sequence.Insert(0,Jump(mine,target,false,Vector2.zero));
   for(int i=0;i<robots.Count;i++){
    bool fail=i>=robots.Count-failCount;
    // Original middle-right failure ranges [-400,-200] x [-100,10]; target middle-left ranges [200,500] x [-100,10].
    Vector2 offset=failed?new Vector2(-320+(i%3)*50,-80+(i%3)*35):new Vector2(240+(i%3)*70,-80+(i%3)*35);
    sequence.Insert(failed?(fail?1.2f:.5f):.7f,Jump(robots[i],failed&&fail?current:target,fail,offset));if(fail)losers.Add(robots[i]);
   }
   float breakAt=failed?1.7f:1.2f;var pillar=Clip(sections[1].Find("Root"),"PillarBreak");var idle=Clip(sections[1].Find("Root"),"PillarIdle");if(idle!=null)idle.SampleAnimation(sections[1].Find("Root").gameObject,0);
   sequence.Insert(breakAt,DOTween.To(()=>100,x=>people.SetText(x.ToString()),70,.7f).OnComplete(()=>progress.SetText(failed?"1/7":"2/7")));
   for(int frame=0;frame<=84;frame++){
    float t=frame/24f;sequence.ManualUpdate(frame==0?0:1f/24f,frame==0?0:1f/24f);
    if(t>=breakAt&&pillar!=null)pillar.SampleAnimation(sections[1].Find("Root").gameObject,Mathf.Min(t-breakAt,pillar.length));
    float disappearAt=(failed?1.2f:.7f)+.95f;
    if(t>=disappearAt)foreach(var loser in losers){var c=Clip(loser,"Disappear");if(c!=null)c.SampleAnimation(loser.gameObject,Mathf.Min(t-disappearAt,c.length));}
    // Original success sequence auto-kills at 2.0 s and applies FastFall to eliminated portraits.
    if(!failed&&t>=2f)foreach(var loser in losers)loser.localScale=Vector3.zero;
    Canvas.ForceUpdateCanvases();camera.Render();var prev=RenderTexture.active;RenderTexture.active=rt;var image=new Texture2D(540,960,TextureFormat.RGB24,false);image.ReadPixels(new Rect(0,0,540,960),0,0);image.Apply();RenderTexture.active=prev;File.WriteAllBytes("Temp/SplashQuestMotion/baseline/frames/"+(failed?"failure":"success")+"-"+frame.ToString("D3")+".png",image.EncodeToPNG());UnityEngine.Object.DestroyImmediate(image);
   }
  }finally{sequence?.Kill();if(rt!=null){rt.Release();UnityEngine.Object.DestroyImmediate(rt);}if(cameraGo!=null)UnityEngine.Object.DestroyImmediate(cameraGo);EditorSceneManager.CloseScene(scene,true);SceneManager.SetActiveScene(previousScene);}
 }
}
