using System.IO;
using UnityEditor;
using UnityEngine;
using TMPro;
public static class SplashUiUnify
{
 public static string Run()
 {
  foreach(var level in new[]{5,7,10})
  {
   var path=$"Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/UIActSplashQuestMainPanel_{level}.prefab";
   File.Copy(path,$"Temp/SplashQuestUI/before-{level}.prefab",true);
   var go=PrefabUtility.LoadPrefabContents(path);
   try {
    var stage=(RectTransform)go.transform.Find("Content/trans_MapRoot/Top/Root/Stage");stage.anchoredPosition=new Vector2(-334,level==5?-291:-513);
    var reward=stage.Find("Reward/Count").GetComponent<TMP_Text>();reward.fontSize=46;reward.fontSizeMax=46;
    var progress=go.transform.Find("Content/Progress/txt_Progress").GetComponent<TMP_Text>();progress.rectTransform.anchoredPosition=new Vector2(54,-65.9f);progress.rectTransform.sizeDelta=new Vector2(140,62.3f);progress.rectTransform.pivot=new Vector2(.5f,.5f);
    var people=go.transform.Find("Content/LeftNum/txt_LeftNum").GetComponent<TMP_Text>();people.rectTransform.anchoredPosition=new Vector2(people.rectTransform.anchoredPosition.x,-65.9f);people.rectTransform.sizeDelta=new Vector2(people.rectTransform.sizeDelta.x,62.3f);people.fontSize=60;
    PrefabUtility.SaveAsPrefabAsset(go,path);
   } finally {PrefabUtility.UnloadPrefabContents(go);}
  }
  return "Unified shared counters and stage signs on three prefabs";
 }
}
