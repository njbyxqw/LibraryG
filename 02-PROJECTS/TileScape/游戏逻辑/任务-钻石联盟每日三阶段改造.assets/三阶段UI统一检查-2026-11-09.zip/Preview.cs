using System;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;
using TMPro;
public static class SplashUiPreview
{
 public static async Task<string> Run()
 {
  var result=new List<object>();
  foreach(var level in new[]{5,7,10}) await Render(level,result);
  File.WriteAllText("Temp/SplashQuestUI/render-metrics.json",JsonConvert.SerializeObject(result,Formatting.Indented));
  return "Rendered three stages";
 }
 static async Task Render(int level,List<object> result)
 {
  var previous=SceneManager.GetActiveScene();var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);
  var path=$"Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/UIActSplashQuestMainPanel_{level}.prefab";
  var go=(GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>(path),scene);
  var cameraGo=new GameObject("PreviewCamera",typeof(Camera));SceneManager.MoveGameObjectToScene(cameraGo,scene);
  var camera=cameraGo.GetComponent<Camera>();var rt=new RenderTexture(540,960,24);
  try {
   camera.scene=scene;camera.overrideSceneCullingMask=EditorSceneManager.GetSceneCullingMask(scene);camera.orthographic=true;camera.orthographicSize=960;camera.transform.position=new Vector3(0,0,-100);camera.nearClipPlane=.1f;camera.farClipPlane=3000;camera.targetTexture=rt;
   var canvas=go.GetComponent<Canvas>();if(canvas==null)canvas=go.AddComponent<Canvas>();canvas.renderMode=RenderMode.WorldSpace;canvas.worldCamera=camera;((RectTransform)go.transform).sizeDelta=new Vector2(1080,1920);go.transform.position=Vector3.zero;go.transform.localScale=Vector3.one;
   var scaler=go.GetComponent<CanvasScaler>();if(scaler!=null)scaler.enabled=false;
   foreach(var a in go.GetComponentsInChildren<Animator>(true))a.enabled=false;
   foreach(var cg in go.GetComponentsInChildren<CanvasGroup>(true))cg.alpha=1;
   var portraits=go.transform.Find("Content/trans_ItemParent");portraits.position=go.transform.Find("Content/trans_MapRoot/Bottom/Root/Background/ItemRoot").position;
   for(var i=0;i<portraits.childCount;i++)portraits.GetChild(i).localScale*=.8f;
   portraits.Find("MyPortrait").SetAsLastSibling();
   EditorApplication.QueuePlayerLoopUpdate();await Task.Delay(150);Canvas.ForceUpdateCanvases();
   foreach(var text in go.GetComponentsInChildren<TMP_Text>(true)) {text.ForceMeshUpdate();result.Add(new {level,path=AnimationUtility.CalculateTransformPath(text.transform,go.transform),text=text.text,font=text.fontSize,width=text.rectTransform.rect.width,height=text.rectTransform.rect.height,preferredWidth=text.preferredWidth,preferredHeight=text.preferredHeight,overflow=text.isTextOverflowing});}
   camera.Render();var prior=RenderTexture.active;RenderTexture.active=rt;var image=new Texture2D(540,960,TextureFormat.RGB24,false);image.ReadPixels(new Rect(0,0,540,960),0,0);image.Apply();RenderTexture.active=prior;File.WriteAllBytes($"Temp/SplashQuestUI/stage-{level}.png",image.EncodeToPNG());UnityEngine.Object.DestroyImmediate(image);
  } finally {camera.targetTexture=null;rt.Release();UnityEngine.Object.DestroyImmediate(rt);UnityEngine.Object.DestroyImmediate(cameraGo);EditorSceneManager.CloseScene(scene,true);SceneManager.SetActiveScene(previous);}
 }
}
