using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using TMPro;
public static class SplashUiInspect
{
 public static string Run()
 {
  var all=new Dictionary<int,object>();
  foreach(var level in new[]{5,7,10})
  {
   var go=AssetDatabase.LoadAssetAtPath<GameObject>($"Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/UIActSplashQuestMainPanel_{level}.prefab");
   var rows=new Dictionary<string,object>();
   foreach(var t in go.GetComponentsInChildren<RectTransform>(true))
   {
    var text=t.GetComponent<TMP_Text>();var image=t.GetComponent<Image>();
    var props=new Dictionary<string,object>{{"pos",new[]{t.anchoredPosition.x,t.anchoredPosition.y}}, {"size",new[]{t.sizeDelta.x,t.sizeDelta.y}}, {"pivot",new[]{t.pivot.x,t.pivot.y}}, {"anchor",new[]{t.anchorMin.x,t.anchorMin.y,t.anchorMax.x,t.anchorMax.y}}, {"scale",new[]{t.localScale.x,t.localScale.y,t.localScale.z}}, {"rotation",new[]{t.localEulerAngles.x,t.localEulerAngles.y,t.localEulerAngles.z}}, {"active",t.gameObject.activeSelf}};
    if(text!=null) props["text"]=new {value=text.text,font=AssetDatabase.GetAssetPath(text.font),material=AssetDatabase.GetAssetPath(text.fontSharedMaterial),size=text.fontSize,auto=text.enableAutoSizing,min=text.fontSizeMin,max=text.fontSizeMax,style=text.fontStyle.ToString(),align=text.alignment.ToString(),spacing=text.characterSpacing,wordSpacing=text.wordSpacing,lineSpacing=text.lineSpacing,color=ColorUtility.ToHtmlStringRGBA(text.color),margin=new[]{text.margin.x,text.margin.y,text.margin.z,text.margin.w},overflow=text.overflowMode.ToString()};
    if(image!=null)props["image"]=new {sprite=image.sprite!=null?image.sprite.name:null,color=ColorUtility.ToHtmlStringRGBA(image.color),preserve=image.preserveAspect,type=image.type.ToString()};
    rows[AnimationUtility.CalculateTransformPath(t,go.transform)]=props;
   }
   all[level]=rows;
  }
  File.WriteAllText("Temp/SplashQuestUI/before.json",JsonConvert.SerializeObject(all,Formatting.Indented));return "Saved 3 layouts";
 }
}
