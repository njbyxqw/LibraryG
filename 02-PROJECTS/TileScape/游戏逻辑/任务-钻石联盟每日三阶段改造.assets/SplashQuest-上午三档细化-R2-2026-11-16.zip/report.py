from pathlib import Path
import json,ast,csv,io,html,zipfile,hashlib,math
p=Path('/tmp/splashquest-initial-refinement-20261116');out=p/'delivery';out.mkdir(exist_ok=True)
data=json.loads((p/'results.json').read_text());rows=data['rows'];inp=json.loads((p/'inputs.json').read_text());ver=json.loads((p/'verification.json').read_text())
tree=ast.parse(Path('/tmp/splashquest-consumption-20261116/report.py').read_text())
labels=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='labels' for t in n.targets))
labels.update({'paid900_mid':'中段单次复活900','paid2800_late':'末关同关复活两次2800','paid900_three_levels':'首／中／末关各复活900','paid_fail3_mid':'中段付900后失败3次，再完成'})
cn={'more':'多发','normal':'正常','less':'少发'};vn={'existing':'上午人数＋原系数','more35':'多发第三阶段统一0.35','more40':'多发第三阶段统一0.40'}
def get(t,sc,v='existing'):return next(r for r in rows if r['pack']['Name']==t and r['pack']['Variant']==v and r['scenario']['Name']==sc)
def fmt(x):return f'{x:.1f}'
def tab(head,body):return '| '+' | '.join(head)+' |\n|'+ '|'.join('---' for _ in head)+'|\n'+''.join('| '+' | '.join(map(str,r))+' |\n' for r in body)
def detail(sc):return [[cn[t],i+1,fmt(s['stats']['mean']),fmt(-s['stats']['netAssetMean']),str(s['stats']['min'])+'～'+str(s['stats']['max'])] for t in cn for i,s in enumerate(get(t,sc)['stages'])]

# Verify frozen morning parameters, unchanged non-target stages, and old-results reproduction.
previous=json.loads(Path('/tmp/splashquest-consumption-20261116/results.json').read_text())['rows'];repro=0
for r in rows:
 ti=next(t for t in inp['tiers'] if t['name']==r['pack']['Name'])
 for si,s in enumerate(r['stages']):
  c=s['config'];assert [c['UserSegmentationExpect'],c['MinExpectNum'],c['MaxExpectNum'],c['AdjustIntensity']]==[ti['expected'][si],ti['mins'][si],ti['maxs'][si],1]
  if r['pack']['Variant']!='existing' and si<2:assert s['stats']['distribution']==get('more',r['scenario']['Name'])['stages'][si]['stats']['distribution']
 if r['pack']['Variant']=='existing':
  old=next((x for x in previous if x['cohort']=='regular' and x['pack']['Name']==r['pack']['Name'] and x['pack']['Family']==r['pack']['Family'] and x['scenario']['Name']==r['scenario']['Name']),None)
  if old:
   for s,t in zip(r['stages'],old['stages']):assert s['stats']['distribution']==t['stats']['distribution'];repro+=1
ver.update({'morningParametersFrozen':True,'previousDistributionMatches':repro,'coefficientOnlyChanges':'more stage3 constant .35 or .40, sensitivity only','groupRulesChanged':False,'protectionChanged':False})
(p/'verification.json').write_text(json.dumps(ver,ensure_ascii=False,indent=2))
groupaudit=json.loads(Path('/tmp/splashquest-audit-20261116/audit-results.json').read_text())['matrix'];groups=[r for r in groupaudit if r['l']==105]
assert len(groups)==27
(p/'current-group-matrix.json').write_text(json.dumps(groups,ensure_ascii=False,indent=2))
groupHash={}
for name in ['attribute','rule','main','stage']:
 for ext in ['json~','bytes']:
  rel=f'Assets/Module/Activity/SplashQuest/Config/Data/{name}.{ext}';b=(Path('/Users/dean/TileScape')/rel).read_bytes();h=hashlib.sha256(b).hexdigest();ref=json.loads(Path('/tmp/splashquest-audit-20261116/audit-manifest.json').read_text())['sources'][rel];assert h==ref;groupHash[rel]=h
(p/'group-source-hashes.json').write_text(json.dumps(groupHash,indent=2))

section='''#### 三档初版细化 R2（沿用上午候选，2026-11-16）

**当前基线明确为上午已形成的三档候选**：多发 E=15/12/9，正常 E=20/16/12，少发 E=30/24/18，继续验证、细化这三套。保护组和入组规则本轮保留；后续确有依据时再单独提出调整。

**首版建议**：上午三档的人数均值、上下限及步长先保留；三档仍分别使用当前 A/B/C 系数作基础稿。多发第三阶段的 0.35／0.40 已做敏感性试算，列为待决候选，不直接覆盖基础稿。理由是提高系数会改善单次复活完成的补偿，却可能减少付费失败后的重试扶持；需要同时明确两条路径的目标，不能只按一次复活结果定值。C1～C4 代码问题仍保留待原程序确认，本轮按当前算法跑，未改游戏配置。

**105 关后的实际入组与适用人群**：币量取 `DIAMOND_NUM`，阈值仍是 4000／10000，不是付费身份，也不是含道具的总资产。以下连胜表现和复活倾向沿用现有统计口径；C4 的 90% 精度问题仍按当前实现保留。

| 钻石存量 | 当前规则在≥105的选择 | 本轮处理 |
|---|---|---|
| <4000 | 连胜表现<0.5：多发；0.5～<0.9且复活倾向≥0.4：多发，否则正常；连胜表现≥0.9：少发 | 低存量是多发主要来源，但保留原有行为例外，不在本轮改规则 |
| 4000～<10000 | 连胜表现<0.5：复活倾向≥0.4时多发，否则正常；0.5～<0.9：复活倾向<0.1时少发，否则正常；≥0.9：少发 | 主要是正常／少发，保留高复活倾向且低连胜表现的多发例外 |
| ≥10000 | 全部少发，不再受另外两个桶影响 | 对应货币存量较高人群，规则保持 |

这里的 27 个组合是规则空间，不是用户占比。层 1/2/3 暂对应多发／正常／少发；55～104 继续原层 5 的全套配置，不应用以下三档，也不与少发层共用候选阶段行。同一期选组后，重试、消费或跨过 105 不即时换组。先看同组实际结果，再决定行为例外是否仍需要；不能仅凭“钱少多发”的总体方向把现规则悄悄换掉。

**上午人数包与分阶段基线**：各阶段为5/7/10关、奖池5000/10000/20000、100人开局，关型权重不变。所有候选的 AdjustIntensity=1。

'''
base=[]
for t in inp['tiers']:
 for si,s in enumerate(get(t['name'],'no_spend')['stages']):
  a=s['stats'];base.append([cn[t['name']],si+1,t['expected'][si],f"{t['mins'][si]}～{t['maxs'][si]}",fmt(a['mean']),f"{a['min']}～{a['max']}"])
section+=tab(['档位','阶段','期望人数','min～max','无消费完成发放均值','发放区间'],base)
section+='''
**发放与净消耗拆分**：以下每格为“本阶段发放均值 / 本阶段净消耗”。净消耗＝实付钻石＋按 DDAV3 折算的库存道具−活动发放，正数表示资源净流出，负数表示净获得；不含其他游戏收入、体力或时间。每个阶段独立以最终完成为条件，不是参与者均值。失败3次的例子均在本阶段末关失败后立即重试，付费失败为每次在末关花900后仍失败，最后一次不消费完成。

'''
scs=['free_retry3_last','paid900_early','paid900_late','inventory_single12','paid_fail3_last']
body=[]
for t in cn:
 for si in range(3):
  cells=[]
  for sc in scs:
   s=get(t,sc)['stages'][si]['stats'];cells.append(fmt(s['mean'])+' / '+fmt(-s['netAssetMean']))
  body.append([cn[t],si+1]+cells)
section+=tab(['档位','阶段','免费失败3次','首关复活900','末关复活900','用1个库存自动配对（值900）','付费失败3次（共2700）'],body)
section+='''
第一阶段现在按5000钻石奖池完整计算，不采用 MT 旧第一阶段不发货币的前提。当前三档无消费分别发346／257／170；首关花900后为417／313／200，对应净消耗483／587／700。系数不能当返还率：这三条路径已到各自人数下限，再提高第一阶段系数也不能提高同路径奖励；若要改变该阶段基础补给，应该明确调整人数目标或下限的理由。本轮没有据此改变上午人数包。

当前三个阶段的基础发放约有三分之二集中在第三阶段。单次复活或道具支出后，前两阶段可能净消耗、第三阶段净获得；这是完成条件下的结构，不能假定每个参与者最终都能拿到第三阶段奖励。若失败后放弃，当前阶段发放0，净消耗为累计支出；此前已领奖励保留。

**多次重试的档位区分**：每阶段各免费失败10次再完成时，三阶段均值分别为多发415.78／999.44／2855.77，正常310.32／767.90／1998.87，少发197.02／496.55／1330.84。上午配置的不同 min 已使这批高重试结果继续保持档位差异，本轮没有证据要求再扩大上下限调整。min 不是实际剩余人数硬底，表内区间只代表已扫描路径，不作为全系统理论上限。

**系数敏感性：只测试多发第三阶段，其余阶段及两档不变**。

'''
co=[]
for v in ['existing','more35','more40']:
 vals=[]
 for sc in ['no_spend','paid900_early','paid900_late','paid_fail3_first','paid_fail3_last','paid900_each_level']:
  s=get('more',sc,v)['stages'][2]['stats'];vals.append(fmt(s['mean']))
 co.append([vn[v]]+vals)
section+=tab(['第三阶段系数','无消费','首关900后完成','末关900后完成','首关付费失败3次再完成','末关付费失败3次再完成','每关900后完成'],co)
section+='''
- 原多发第三阶段的单次900在初始 E=8/9 两个分支都不足以多淘汰1人。第一个额外淘汰的成本分别约357.14／277.78，系数需严格大于约0.3968／0.3086；统一0.35只能覆盖其中一支，统一0.40能覆盖两支，因此有明确算术依据，未参考 MT 第一阶段系数。
- 但系数提高并不保证失败重试后发得更多。已用原方法复核：首关 E=9、付900后失败，原首系数0.30没有额外淘汰，结余270>200，下一轮 E抽7/8；0.40先额外淘汰1人，结余82≤200，下一轮 E抽8/9。失败轮的额外淘汰没有兑现为奖励，却改变了重试扶持。这个例子即使不讨论旧余额双口径，也说明不能孤立调系数。
- 0.40方案使三阶段每阶段首关各付900后的总发放从3778.5变4096.0，但每阶段首关付900后失败3次、再完成的总发放从4275.0变4145.81。它属于补偿时机的取舍，不是无副作用的优化。
- 统一0.35／0.40也改变了原第三阶段按位置递减的系数设计；原递减理由尚未确认。因此**当前初版基础稿仍保留A/B/C原系数，0.40作为“希望单次900在第三阶段有明确补偿”的备选**。若选它，需要同时接受并评估付费失败重试的影响，再确定是否调整相关联动；本轮未改代码或配置。

道具现阶段不进入活动补偿：一个库存自动配对按DDAV3计900，发放与同路径不使用道具相同，净消耗增加900。撤回／移出／洗牌按500／900／1300分别换算；实际钻石流水与库存折值分列。广告复活和广告获得即用的道具另列有效回收，不当成真实钻石支出。以后是否将道具纳入补偿输入，仍是独立设计项。

**验证边界与产物**：入口按105～200逐关等权扫描，使用本地关卡类型，失败已通过的主线关卡继续推进；没有给完成率、失败率或消费位置编造玩家概率。29个场景×5个参数版本=145组，580个阶段／全通分布；原C#计算方法、实际Unity Mathf离线运行，75项独立二项分布、240项余额与关型独立性、225项与R1既有分布对照通过。55～104和规则表没有改变；现有代码问题继续保留。报告不等于Unity业务、设备到账或线上经济验证。

完整明细：[[02-PROJECTS/TileScape/游戏逻辑/任务-钻石联盟每日三阶段改造.assets/SplashQuest-上午三档细化-R2-2026-11-16.html]]；复现及CSV：[[02-PROJECTS/TileScape/游戏逻辑/任务-钻石联盟每日三阶段改造.assets/SplashQuest-上午三档细化-R2-2026-11-16.zip]]。

'''
assert repro==225
(p/'result-section.md').write_text(section)
flat=[]
for r in rows:
 for stage,s in [(x['stage'],x['stats']) for x in r['stages']]+[(0,r['total'])]:
  flat.append({'tier':r['pack']['Name'],'variant':r['pack']['Variant'],'scenario':r['scenario']['Name'],'stage':stage,**{k:v for k,v in s.items() if k not in ('distribution','inventoryConsumed')},'netConsumptionMean':-s['netAssetMean'],'netConsumptionMin':-s['netAssetMax'],'netConsumptionMax':-s['netAssetMin']})
b=io.StringIO();w=csv.DictWriter(b,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat);(out/'scenarios.csv').write_text('\ufeff'+b.getvalue())

def esc(s):return html.escape(str(s))
def ht(head,body):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+esc(v)+'</th>' for v in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(v)+'</td>' for v in r)+'</tr>' for r in body)+'</tbody></table></div>'
h=['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SplashQuest 上午三档细化 R2</title><style>body{font:15px/1.7 system-ui;margin:0;background:#f1f5f7;color:#193043}main{max-width:1320px;margin:24px auto;padding:32px;background:white;border-radius:14px}h1{font-size:28px}h2{margin-top:32px;font-size:21px}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:9px;border-bottom:1px solid #dce5ea;text-align:right;white-space:nowrap}th{background:#edf4f7}td:first-child,th:first-child{text-align:left}.note{background:#eaf4ee;border-left:4px solid #178064;padding:15px}select{padding:7px;margin:5px}p{max-width:1150px}a{color:#087b75}</style><main><h1>SplashQuest 上午三档细化 R2</h1><p>2026-11-16 · 105关后 · 原算法离线模拟 · 未修改游戏配置</p><div class="note">沿用上午三档：多发15/12/9、正常20/16/12、少发30/24/18，人数范围保持。初版基础稿保留A/B/C系数；多发第三阶段0.35/0.40为敏感性候选。提高系数可增加单次复活完成奖励，也可能减少付费失败后的重试扶持。</div>']
h+=['<h2>1. 当前人群与本轮范围</h2><p>层1→多发，层2→正常，层3→少发；55～104仍是原层5全套配置，当前不套三档。≥105规则按钻石存量、复活倾向、连胜表现共同判断，暂不简化成纯币量分组；分组采用每期快照。</p>',ht(['钻石存量','当前实际选择'],[['<4000','连胜低→多；连胜中且复活倾向高→多，否则正常；连胜高→少'],['4000～<10000','连胜低且复活倾向高→多，否则正常；连胜中且复活倾向低→少，否则正常；连胜高→少'],['≥10000','全部少发']]),'<p>连胜低／中／高界线0.5和0.9；复活倾向低／中／高界线0.1和0.4。统计口径与现有浮点边界问题保留。这不是付费用户分类，也不是活动完成概率；原始钻石阈值没有偷偷替换成总资产阈值。</p>','<h2>2. 上午人数包与各阶段基础发放</h2>',ht(['档位','阶段','期望人数','min～max','无消费发放均值','区间'],base),'<p>共同条件：5/7/10关，奖池5000/10000/20000，100人，步长1。第一阶段明确按5000货币奖池计算，未套用MT旧第一阶段不发货币的前提。</p>','<h2>3. 分阶段发放与净消耗</h2><p>每格为“发放均值 / 净消耗”；正净消耗表示资源净流出，负数表示净获得。净消耗＝实付钻石＋DDAV3折算库存消耗−活动发放，不含其他收入、时间体力。每行以本阶段最终完成为条件。库存自动配对的价值900，不是本次实扣900钻石。</p>',ht(['档位','阶段','免费失败3次','首关复活900','末关复活900','1个库存自动配对','付费失败3次（2700）'],body),'<p>如果最终放弃当前阶段，发放0，净消耗等于累计支出；此前阶段奖励保留。三阶段均值不能直接作为参与者日均；缺少完成率和退出率时不能推断整体回收。</p>','<h2>4. 多发第三阶段的系数取舍</h2>',ht(['方案','无消费','首关900','末关900','首关付费失败3次','末关付费失败3次','每关900'],co),'<p>初始剩余期望人数8/9时，多淘汰1人的奖励成本约357.14/277.78。900×0.35只覆盖后一支，900×0.40能覆盖两支。原序列单次900不会触发；0.40将该场景发放均值由2361.5变为2679，但并未提高人数下限对应的高消费目标发放。</p>','<p>反向路径：E=9，首关付900后仍失败，原0.30产生结余270，超过200，下一轮E抽7/8；0.40先多淘汰1人，结余82，未超过200，下一轮E抽8/9。失败轮没有领奖，补偿却影响下一轮扶持。因此原算法下，较高系数不保证重试后奖励更高。</p>','<p><b>建议：</b>上午三档人数可继续作为初版；其余系数缺少修改收益依据，保留A/B/C。第三阶段0.40是有算术依据的备选，但同时改变位置衰减及失败重试效果，先保留为待决项，避免用单次复活结果替代完整判断。旧余额代码问题仍待程序确认。</p>','<h2>5. 全部场景与分布</h2><p>扫描入口105～200，入口关卡等权、人数随机精确枚举；不是线上人群权重。以下包含基础稿及两个系数敏感性候选。</p>']
for id,label,opts in [('tier','档位',list(cn.items())),('variant','版本',list(vn.items())),('scenario','场景',list(labels.items())),('stage','阶段',[(str(i),'全通' if i==0 else str(i)) for i in [1,2,3,0]])]:
 h.append('<label>'+label+'<select id="'+id+'"><option value="">全部</option>'+''.join('<option value="'+esc(v)+'">'+esc(t)+'</option>' for v,t in opts)+'</select></label>')
tableheads=['档位','版本','场景','阶段','发放均值','发放最小','发放最大','P05','P50','P95','净消耗均值','净最小','净最大','钻石支出','库存价值','有效回收','负余额率%']
h.append('<p id="count"></p><div class="scroll"><table><thead><tr>'+''.join('<th>'+v+'</th>' for v in tableheads)+'</tr></thead><tbody id="grid"></tbody></table></div>')
compact=[[r['tier'],r['variant'],r['scenario'],str(r['stage']),round(r['mean'],3),r['min'],r['max'],r['p05'],r['p50'],r['p95'],round(r['netConsumptionMean'],3),r['netConsumptionMin'],r['netConsumptionMax'],r['diamondPaid'],r['inventoryValue'],r['effectiveRecovery'],round(r['negativeBalanceProbability']*100,3)] for r in flat]
h.append('<script>const data='+json.dumps(compact,ensure_ascii=False)+';const tiers='+json.dumps(cn,ensure_ascii=False)+';const variants='+json.dumps(vn,ensure_ascii=False)+';const labels='+json.dumps(labels,ensure_ascii=False)+''';const ids=['tier','variant','scenario','stage'];function show(){const filters=ids.map(i=>document.getElementById(i).value);const rs=data.filter(r=>filters.every((v,i)=>!v||r[i]===v));const body=document.getElementById('grid');body.replaceChildren();document.getElementById('count').textContent=rs.length+'条结果';for(const r of rs){const tr=document.createElement('tr');r.forEach((v,i)=>{const td=document.createElement('td');td.textContent=i===0?tiers[v]:i===1?variants[v]:i===2?labels[v]:i===3?(v==='0'?'全通':v):v;tr.append(td)});body.append(tr)}}ids.forEach(i=>document.getElementById(i).addEventListener('change',show));document.getElementById('variant').value='existing';document.getElementById('scenario').value='no_spend';show();</script>''')
h+=['<h2>6. 验证与文件</h2><p>29场景、145组、580个分布；75项独立二项核对、240项余额与关型独立性核对、225项与R1分布对照通过。实际Unity Mathf离线运行，游戏原方法未改。未执行Unity业务流程或线上到账验证；C1～C4保留待确认。</p><p>道具价值按DDAV3：撤回500、移出900、自动配对900、洗牌1300。广告取得并立即消耗不扣原有净库存，有效回收另计；无限道具不消耗有限库存时不计库存扣减。表中负余额率只是指定路径概率，不是线上发生率。</p><p><a href="SplashQuest-上午三档细化-R2-2026-11-16.zip">下载明细CSV、输入、完整分布和复现包</a></p></main></html>']
(out/'SplashQuest-上午三档细化-R2-2026-11-16.html').write_text('\n'.join(h))
(p/'README.md').write_text('''# 上午三档细化 R2

基线只采用上午R0人数包及其上下限/步长，不改保护组和现有分组。基础稿系数沿用A/B/C；more35、more40仅把多发第三阶段的10项系数替换成常数0.35/0.40，其余完全不动。候选不等于推荐上线；完整建议见LG主档。

CSV stage=0是三阶段全通，其余为单阶段。净消耗为正表示资源减少、负表示净获得；以最终完成为条件，未建玩家胜率或退出率模型。results.json保留全部随机分布；current-group-matrix.json保存已验证的27个现有规则组合；group-source-hashes.json用于确认导出未漂移。coefficient-trace.json展示首次失败后是否触发200阈值的原方法结果。

复跑需.NET10及Unity6000.0.60f1 CoreModule。调整Sim.csproj中的程序集路径，在目录运行dotnet run --project Sim.csproj -c Release；Trace.csproj是六个首次失败分支的独立轨迹。report.py生成明细与报告，引用前轮本地模拟资料进行分布一致性检查，跨机器复现需将对应前轮文件路径替换或单独运行Sim项目。

未修改游戏配置或代码。实际游戏输入哈希包含于inputs.json。源方法与UnityMathf离线执行不等于Unity业务运行验收；广告、道具和复活的有效回收仍受DDAV3运行门槛限制。
''')
with zipfile.ZipFile(out/'SplashQuest-上午三档细化-R2-2026-11-16.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['README.md','inputs.json','results.json','verification.json','Calculator.cs','Program.cs','Sim.csproj','NuGet.Config','Trace.cs','Trace.csproj','coefficient-trace.json','current-group-matrix.json','group-source-hashes.json','report.py']:z.write(p/name,name)
 z.write(out/'scenarios.csv','scenarios.csv')
 for name in ['attribute','rule','main','stage']:
  z.write(Path('/Users/dean/TileScape/Assets/Module/Activity/SplashQuest/Config/Data')/(name+'.json~'),'snapshots/'+name+'.json~')
with zipfile.ZipFile(out/'SplashQuest-上午三档细化-R2-2026-11-16.zip') as z:assert z.testzip() is None
print('Verified frozen morning packages;',repro,'matching previous distributions;',len(flat),'output rows')
