# 上午三档细化 R2

基线只采用上午R0人数包及其上下限/步长，不改保护组和现有分组。基础稿系数沿用A/B/C；more35、more40仅把多发第三阶段的10项系数替换成常数0.35/0.40，其余完全不动。候选不等于推荐上线；完整建议见LG主档。

CSV stage=0是三阶段全通，其余为单阶段。净消耗为正表示资源减少、负表示净获得；以最终完成为条件，未建玩家胜率或退出率模型。results.json保留全部随机分布；current-group-matrix.json保存已验证的27个现有规则组合；group-source-hashes.json用于确认导出未漂移。coefficient-trace.json展示首次失败后是否触发200阈值的原方法结果。

复跑需.NET10及Unity6000.0.60f1 CoreModule。调整Sim.csproj中的程序集路径，在目录运行dotnet run --project Sim.csproj -c Release；Trace.csproj是六个首次失败分支的独立轨迹。report.py生成明细与报告，引用前轮本地模拟资料进行分布一致性检查，跨机器复现需将对应前轮文件路径替换或单独运行Sim项目。

未修改游戏配置或代码。实际游戏输入哈希包含于inputs.json。源方法与UnityMathf离线执行不等于Unity业务运行验收；广告、道具和复活的有效回收仍受DDAV3运行门槛限制。
