import json
from pathlib import Path
x=json.load(open('Temp/SplashQuestMotion/lava-visual-data.json'))
c=x['clips']['PP0Fail1'];ts={t['prop']:t['v']for t in c['tracks']};origin=x['nodes'][x['root']]['p'];mask=c['mask'];mask_top=mask['rect'][1]+mask['rect'][3];frames=[]
for i in range(81):
 p=ts['p'][i];scale=ts['s'][i];h=.61*scale[0]
 alpha=max(0,min(1,(origin[1]+p[1]+h-mask_top)/h)) if mask['active'][i] else 1
 if not ts['active'][i][0]:alpha=0
 frames.append([p[0]-ts['p'][0][0],p[1]-ts['p'][0][1],ts['e'][i][2],alpha])
c=x['clips']['BuryRock'];ts={t['prop']:t['v']for t in c['tracks']if t['node']==35};sink=[]
for i in range(51):sink.append([ts['p'][i][0]-ts['p'][0][0],ts['p'][i][1]-ts['p'][0][1],ts['alpha'][i][0]])
def num(v):return f'{v:.6f}'.rstrip('0').rstrip('.')+'f'
def array(name,rows):
 n=len(rows[0]);return f'        private static readonly Vector{n}[] {name} =\n        {{\n'+''.join('            new('+', '.join(num(v)for v in r)+'),\n'for r in rows)+'        };\n'
p=Path('Assets/Module/Activity/SplashQuest/Scripts/SplashQuestMotion.cs');s=p.read_text().replace('using Random = UnityEngine.Random;\n','')
s=s.replace('        public const float FAIL_PREPARE_DURATION = 0.16f;\n        public const float FAIL_JUMP_DURATION = 0.8f;\n        public const float FAIL_FADE_DURATION = 0.2f;\n        public const float SINK_DURATION = 0.55f;', '        public const float FAIL_DURATION = 80f / 30f;\n        public const float SINK_DURATION = 50f / 30f;')
s=s.replace('Mathf.Min(Random.Range(2, 4), robotCount + (playerFailed ? 1 : 0))','Mathf.Min(2, robotCount + (playerFailed ? 1 : 0))')
insert='''        // Lava Step1 PP0Fail1 and BuryRock at 30 Hz; omit the already invisible clip tails.
'''+array('FallSamples',frames)+'\n'+array('SinkSamples',sink)+'''
        public static Vector4 SampleFall(float time)
        {
            var frame = Mathf.Clamp(time * 30f, 0f, FallSamples.Length - 1);
            var index = Mathf.FloorToInt(frame);
            return Vector4.LerpUnclamped(FallSamples[index], FallSamples[Mathf.Min(index + 1, FallSamples.Length - 1)],
                frame - index);
        }

        public static Vector3 SampleSink(float time)
        {
            var frame = Mathf.Clamp(time * 30f, 0f, SinkSamples.Length - 1);
            var index = Mathf.FloorToInt(frame);
            return Vector3.LerpUnclamped(SinkSamples[index], SinkSamples[Mathf.Min(index + 1, SinkSamples.Length - 1)],
                frame - index);
        }

'''
s=s.replace('        public static float SurvivorStart',insert+'        public static float SurvivorStart');p.write_text(s)
Path('Temp/SplashQuestMotion/lava-v4-adapted-samples.json').write_text(json.dumps({'fall':frames,'sink':sink},indent=2))
print('Generated',len(frames),'fall and',len(sink),'platform samples')
