using TransformUtils = Module.Utils.UtilsTransform;
using Betta.Framework;
using BettaSDK;
using DG.Tweening;
using Module.PlayerInfo;

using UnityEngine;

namespace Module.Activity.SplashQuest
{
    public class UIActSplashQuestAnimPortrait
    {
        public Transform Transform { get; private set; }
        public RectTransform RectTransform => Transform as RectTransform;

        private readonly Transform _originalParent;
        private readonly int _originalSiblingIndex;
        private readonly Vector3 _originalScale;
        private readonly Vector3 _displayScale;
        private readonly Vector3 _originalPosition;
        private readonly Quaternion _originalRotation;
        private readonly CanvasGroup _canvasGroup;

        private Animator _animator;

        private Transform _portraitTransform;

        private UIPortraitView _portraitView;

        private Vector2 _anchoredPosition;

        private int _avatarId;
        private int _frameId;
        private int _badgeId;

        private readonly int _appear = Animator.StringToHash("Appear");

        private Sequence _seq;

        public UIActSplashQuestAnimPortrait(Transform transform)
        {
            Transform = transform;
            _originalParent = transform.parent;
            _originalSiblingIndex = transform.GetSiblingIndex();
            _originalScale = transform.localScale;
            _displayScale = _originalScale * SplashQuestMotion.PORTRAIT_SCALE;
            transform.localScale = _displayScale;
            _originalPosition = transform.localPosition;
            _originalRotation = transform.localRotation;
            _canvasGroup = transform.GetComponent<CanvasGroup>();
            if (_canvasGroup == null)
            {
                _canvasGroup = transform.gameObject.AddComponent<CanvasGroup>();
            }
            _canvasGroup.alpha = 1f;
            FindComponents();
            InitProperties();
            RegisterEvents();
        }

        private void FindComponents()
        {
            _animator = Transform.GetComponent<Animator>();
            _portraitTransform = TransformUtils.Find(Transform, "AnimRoot/ScaleRoot/UIPortraitView");
        }

        private void InitProperties()
        {
            _portraitView = new UIPortraitView(_portraitTransform);
            _avatarId = PortraitConfig.DefaultAvatarId;
            _frameId = PortraitConfig.DefaultFrameId;
            _badgeId = 0;
        }

        private void RegisterEvents()
        {

        }

        private void UnregisterEvents()
        {

        }

        public void OnRelease()
        {
            UnregisterEvents();
            _portraitView.OnRelease();
            _seq?.Kill();
            Transform.SetParent(_originalParent, false);
            Transform.SetSiblingIndex(_originalSiblingIndex);
            Transform.localPosition = _originalPosition;
            Transform.localScale = _originalScale;
            Transform.localRotation = _originalRotation;
            _canvasGroup.alpha = 1f;
        }

        public void Show(int avatarId, int frameId, int badgeId)
        {
            _portraitView.Show(avatarId, frameId);
        }

        public void ShowRandom()
        {
            _avatarId = ImplementHub.Instance.Get<Interface.PlayerInfo.IPlayerInfo>().GetRandomId(PortraitType.Avatar);
            _frameId = ImplementHub.Instance.Get<Interface.PlayerInfo.IPlayerInfo>().GetRandomId(PortraitType.Frame);
            _badgeId = 0;

            _portraitView.Show(_avatarId, _frameId, false);
        }

        public void SetPosition(Vector2 position)
        {
            _anchoredPosition = position;
        }

        public void Appear()
        {
            if (_animator != null)
            {
                _animator.Play(_appear);
            }

            DOVirtual.DelayedCall(0.2f, () =>
            {
                HapticsHub.Instance.DoHaptic(HapticsTypes.Light);
            }, false).SetLink(Transform.gameObject);
        }

        public void CompleteAppear()
        {
            if (_animator == null)
            {
                return;
            }

            _animator.Play(_appear, 0, 1f);
            _animator.Update(0f);
        }

        public Sequence JumpToNext(Transform target, int profile = 0)
        {
            _seq?.Kill();
            var start = Transform.position;
            var targetPos = target.position + _originalParent.TransformVector(_anchoredPosition);
            var vertical = target.TransformVector(Vector3.up * 100f);
            var rotation = Transform.rotation;
            var mirror = Vector3.Dot(targetPos - start, target.right) > 0f ? -1f : 1f;
            var duration = SplashQuestMotion.JumpDuration(profile);
            _seq = DOTween.Sequence().SetLink(Transform.gameObject);
            _seq.Append(DOVirtual.Float(0f, duration, duration, time =>
            {
                var sample = SplashQuestMotion.SampleJump(time, profile);
                Transform.position = Vector3.LerpUnclamped(start, targetPos, sample.Motion.x)
                    + vertical * sample.Motion.y;
                Transform.rotation = rotation * Quaternion.Euler(0f, 0f, sample.Motion.z * mirror);
                Transform.localScale = Vector3.Scale(_displayScale, new Vector3(sample.Scale.x, sample.Scale.y, 1f));
            }).SetEase(Ease.Linear));
            _seq.InsertCallback(profile == 0 ? 2f / 30f : 5f / 30f, () =>
            {
                ImplementHub.Instance.Get<Interface.Sound.IAudioSystem>()?.PlayAudio(
                    Module.Audio.SoundConst.SFX_Temple_Jump, false, 1f);
            });
            _seq.OnComplete(() =>
            {
                Transform.position = targetPos;
                Transform.localScale = _displayScale;
                Transform.rotation = rotation;
            });
            return _seq;
        }

        private Vector3 GetTargetPosition(Transform target)
        {
            return Transform.parent.InverseTransformPoint(target.position) + (Vector3)_anchoredPosition;
        }

        public Sequence JumpOffPlatform(Transform reference, int direction, Transform platform)
        {
            _seq?.Kill();
            var start = Transform.position;
            var horizontal = reference.TransformVector(Vector3.right * 100f);
            var vertical = reference.TransformVector(Vector3.up * 100f);
            var rotation = Transform.rotation;
            var scale = Transform.localScale;
            var mirror = direction < 0 ? 1f : -1f;
            _seq = DOTween.Sequence().SetLink(Transform.gameObject);
            _seq.AppendCallback(() =>
            {
                Transform.SetParent(platform.parent, true);
                Transform.SetSiblingIndex(platform.GetSiblingIndex());
                scale = Transform.localScale;
            });
            _seq.Append(DOVirtual.Float(0f, SplashQuestMotion.FAIL_DURATION, SplashQuestMotion.FAIL_DURATION, time =>
            {
                var sample = SplashQuestMotion.SampleFall(time);
                Transform.position = start + horizontal * (sample.x * mirror) + vertical * sample.y;
                Transform.rotation = rotation * Quaternion.Euler(0f, 0f, sample.z * mirror);
                Transform.localScale = scale * (1f - Mathf.SmoothStep(0f, 1f,
                    Mathf.InverseLerp(SplashQuestMotion.FAIL_DISAPPEAR_START, SplashQuestMotion.FAIL_DURATION, time)));
                _canvasGroup.alpha = sample.w;
            }).SetEase(Ease.Linear));
            return _seq;
        }

        public void FastJump(Transform target)
        {
            _seq?.Kill();
            if (Transform.parent != _originalParent)
            {
                Transform.SetParent(_originalParent, false);
            }
            Transform.localScale = _displayScale;
            Transform.localRotation = _originalRotation;
            _canvasGroup.alpha = 1f;
            Transform.localPosition = GetTargetPosition(target);
        }

        public void CompleteSink()
        {
            _seq?.Kill();
            _canvasGroup.alpha = 0f;
        }

        public int[] GetPortraitInfo()
        {
            return new[] { _avatarId, _frameId, _badgeId };
        }
    }
}
