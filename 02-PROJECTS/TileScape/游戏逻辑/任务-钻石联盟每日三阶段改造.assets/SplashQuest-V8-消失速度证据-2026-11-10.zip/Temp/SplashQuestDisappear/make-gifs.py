from PIL import Image,ImageDraw
from pathlib import Path
p=Path('Temp/SplashQuestDisappear')
for mode in ['success','failure','start-failure']:
    frames=[]
    for f in range(121):
        frames.append(Image.open(p/'frames-after'/f'{mode}-{f:03d}.png').convert('RGB').resize((360,640)))
    palette=frames[0].quantize(colors=256)
    indexed=[im.quantize(palette=palette,dither=Image.Dither.NONE) for im in frames]
    indexed[0].save(p/f'after-{mode}.gif',save_all=True,append_images=indexed[1:],duration=[40,40,50]*40+[40],loop=0,optimize=False)
frames=[]
for f in range(121):
    im=Image.new('RGB',(720,664),'#203044');d=ImageDraw.Draw(im)
    d.text((10,6),'BEFORE',fill='white');d.text((370,6),'AFTER',fill='white')
    for i,folder in enumerate(['frames-before','frames-after']):
        im.paste(Image.open(p/folder/f'success-{f:03d}.png').convert('RGB').resize((360,640)),(360*i,24))
    frames.append(im)
palette=frames[0].quantize(colors=256)
indexed=[im.quantize(palette=palette,dither=Image.Dither.NONE) for im in frames]
indexed[0].save(p/'before-after-success.gif',save_all=True,append_images=indexed[1:],duration=[40,40,50]*40+[40],loop=0,optimize=False)
canvas=Image.new('RGB',(1080,990),'#203044');d=ImageDraw.Draw(canvas)
for i,mode in enumerate(['success','failure','start-failure']):
    for j,f in enumerate([24,42,50]):
        canvas.paste(Image.open(p/'frames-after'/f'{mode}-{f:03d}.png').resize((360,320)),(i*360,30+j*320))
    d.text((i*360+5,6),mode+' 1.0/1.75/2.08s',fill='white')
canvas.save(p/'after-contact.png')
print('Created three new GIFs and before/after comparison')

