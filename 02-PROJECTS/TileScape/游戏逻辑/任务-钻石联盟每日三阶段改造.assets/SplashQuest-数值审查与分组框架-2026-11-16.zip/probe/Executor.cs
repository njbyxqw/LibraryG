using System;
using UnityEngine;

namespace Betta.Framework
{
    // 变量提供器接口
    public interface IVariableProvider
    {
        bool TryGetNumber(string name, out double value);
        bool TryGetBool(string name, out bool value);
        bool TryGetString(string name, out string value);
        bool TryGetArray(string name, out ArrayValue value);
        bool TryCallFunction(string functionName, object[] parameters, out object result);
    }
    
    public class ExpressionRuntime
    {
        private readonly CompiledExpression _expr;
        private readonly IVariableProvider _vars;

        private ExpressionRuntime(CompiledExpression expr, IVariableProvider vars)
        {
            _expr = expr;
            _vars = vars;
        }

        public static bool Execute(CompiledExpression expr, IVariableProvider vars)
        {
            return new ExpressionRuntime(expr, vars).Execute();
        }

        private bool Execute()
        {
            if (_expr?.N == null || _expr.N.Count == 0) 
                return true;

            // 递归执行根节点（最后一个节点是根节点）
            return EvaluateNode(_expr.N.Count - 1);
        }

        private bool EvaluateNode(int nodeIndex)
        {
            if (nodeIndex < 0 || nodeIndex >= _expr.N.Count)
                return false;

            var node = _expr.N[nodeIndex];
            switch (node.T)
            {
                case NodeType.Constant: return EvaluateConstant(node.V);
                case NodeType.Variable: return EvaluateVariable(node.V);
                case NodeType.Function: return ConvertToBool(EvaluateFunction(node.V));
                case NodeType.LogicalNot: return !EvaluateNode(node.L);
                case NodeType.LogicalAnd: return EvaluateNode(node.L) && EvaluateNode(node.R); // 短路求值
                case NodeType.LogicalOr: return EvaluateNode(node.L) || EvaluateNode(node.R); // 短路求值
                case NodeType.Equal: return ObjectsEqual(GetValue(node.L), GetValue(node.R));
                case NodeType.NotEqual: return !ObjectsEqual(GetValue(node.L), GetValue(node.R));
                case NodeType.GreaterThan: return CompareNumbers(node.L, node.R) > 0;
                case NodeType.LessThan: return CompareNumbers(node.L, node.R) < 0;
                case NodeType.GreaterOrEqual: return CompareNumbers(node.L, node.R) >= 0;
                case NodeType.LessOrEqual: return CompareNumbers(node.L, node.R) <= 0;
                case NodeType.In: return EvaluateInOperation(node.L, node.R, node.V);
                default: return GetNumberValue(nodeIndex) != 0; // 对于算术操作符，返回数值对应的布尔值（非零为true）
            }
        }
        
        public static object ExecuteValue(CompiledExpression expr, IVariableProvider vars)
        {
            return new ExpressionRuntime(expr, vars).ExecuteValue();
        }

        private object ExecuteValue()
        {
            if (_expr?.N == null || _expr.N.Count == 0) 
                return true;

            // 递归执行根节点（最后一个节点是根节点）
            return EvaluateNodeValue(_expr.N.Count - 1);
        }
        
        // 通用求值（返回原始对象）
        private object EvaluateNodeValue(int nodeIndex)
        {
            if (nodeIndex < 0 || nodeIndex >= _expr.N.Count)
                return null;

            var node = _expr.N[nodeIndex];
            switch (node.T)
            {
                case NodeType.Constant: return GetConstantValue(node.V);
                case NodeType.Array: return GetArrayValueByIndex(node.V);
                case NodeType.Variable: return GetVariableValue(node.V);
                case NodeType.LogicalNot: return !ConvertToBool(EvaluateNode(node.L));
                case NodeType.LogicalAnd: return ConvertToBool(EvaluateNode(node.L)) && ConvertToBool(EvaluateNode(node.R));
                case NodeType.LogicalOr: return ConvertToBool(EvaluateNode(node.L)) || ConvertToBool(EvaluateNode(node.R));
                case NodeType.Equal: return ObjectsEqual(EvaluateNode(node.L), EvaluateNode(node.R));
                case NodeType.NotEqual: return !ObjectsEqual(EvaluateNode(node.L), EvaluateNode(node.R));
                case NodeType.GreaterThan: return CompareNumbers(node.L, node.R) > 0;
                case NodeType.LessThan: return CompareNumbers(node.L, node.R) < 0;
                case NodeType.GreaterOrEqual: return CompareNumbers(node.L, node.R) >= 0;
                case NodeType.LessOrEqual: return CompareNumbers(node.L, node.R) <= 0;
                case NodeType.In: return EvaluateInOperation(node.L, node.R, node.V);
                case NodeType.Function: return EvaluateFunction(node.V);
                case NodeType.Add:
                    var leftValAdd = EvaluateNodeValue(node.L);
                    var rightValAdd = EvaluateNodeValue(node.R);
                    if (leftValAdd is string || rightValAdd is string)
                        return (leftValAdd?.ToString() ?? string.Empty) + (rightValAdd?.ToString() ?? string.Empty);
                    return ConvertToNumber(leftValAdd) + ConvertToNumber(rightValAdd);
                case NodeType.Subtract: return ConvertToNumber(EvaluateNodeValue(node.L)) - ConvertToNumber(EvaluateNodeValue(node.R));
                case NodeType.Multiply: return ConvertToNumber(EvaluateNodeValue(node.L)) * ConvertToNumber(EvaluateNodeValue(node.R));
                case NodeType.Divide:
                    var divisor = ConvertToNumber(EvaluateNodeValue(node.R));
                    if (Math.Abs(divisor) < 0.0001) return 0.0;
                    return ConvertToNumber(EvaluateNodeValue(node.L)) / divisor;
                default: return EvaluateNodeValue(nodeIndex); // 防止无限递归，这里应该不会执行到
            }
        }

        private bool EvaluateInOperation(int valueNodeIndex, int arrayNodeIndex, int arrayConstantIndex)
        {
            var value = GetValue(valueNodeIndex);
            ArrayValue array = null;

            // 获取数组
            if (arrayConstantIndex >= 0)
            {
                if (_expr.A != null && arrayConstantIndex < _expr.A.Count)
                    array = _expr.A[arrayConstantIndex];
            }
            else if (arrayNodeIndex >= 0)
            {
                // 变量数组（从变量提供器获取）
                var arrayValue = GetValue(arrayNodeIndex);
                if (arrayValue is ArrayValue arr)
                    array = arr;
            }

            if (array == null || value == null)
                return false;

            var items = array.V;
            if (items == null)
                return false;
            for (var i = 0; i < items.Count; i++)
            {
                var el = items[i];
                if (ObjectsEqual(value, ArrayElementRuntime.ToObject(el)))
                    return true;
            }
            
            return false;
        }

        private object GetValue(int nodeIndex)
        {
            if (nodeIndex < 0 || nodeIndex >= _expr.N.Count)
                return null;

            var node = _expr.N[nodeIndex];
            switch (node.T)
            {
                case NodeType.Constant: return GetConstantValue(node.V);
                case NodeType.Array: return GetArrayValueByIndex(node.V);
                case NodeType.Variable: return GetVariableValue(node.V);
                case NodeType.Function: return EvaluateFunction(node.V);
                case NodeType.Add:
                    var leftVal = GetValue(node.L);
                    var rightVal = GetValue(node.R);
                    if (leftVal is string || rightVal is string)
                        return (leftVal?.ToString() ?? string.Empty) + (rightVal?.ToString() ?? string.Empty);
                    return GetNumberValue(node.L) + GetNumberValue(node.R);
                case NodeType.Subtract: return GetNumberValue(node.L) - GetNumberValue(node.R);
                case NodeType.Multiply: return GetNumberValue(node.L) * GetNumberValue(node.R);
                case NodeType.Divide:
                    var divisor = GetNumberValue(node.R);
                    if (Math.Abs(divisor) < 0.0001) return 0.0;
                    return GetNumberValue(node.L) / divisor;
                default: return EvaluateNode(nodeIndex);
            }
        }

        private ArrayValue GetArrayValueByIndex(int index)
        {
            if (_expr.A == null || index < 0 || index >= _expr.A.Count)
                return null;
            return _expr.A[index];
        }

        private double GetNumberValue(int nodeIndex)
        {
            return ConvertToNumber(GetValue(nodeIndex));
        }

        private bool EvaluateConstant(int constantIndex)
        {
            return ConvertToBool(GetConstantValue(constantIndex));
        }

        private object GetConstantValue(int constantIndex)
        {
            if (constantIndex < 0 || constantIndex >= _expr.C.Count)
                return null;

            var constant = _expr.C[constantIndex];
            switch (constant.T)
            {
                case ValueType.Boolean: return constant.V == "true";
                case ValueType.Number: return double.Parse(constant.V);
                case ValueType.String: return constant.V;
                default: return null;
            }
        }

        private bool EvaluateVariable(int variableIndex)
        {
            return ConvertToBool(GetVariableValue(variableIndex));
        }

        private object GetVariableValue(int variableIndex)
        {
            if (variableIndex < 0 || variableIndex >= _expr.V.Count)
                return null;

            var varName = _expr.V[variableIndex];
            
            // 先尝试获取数组
            if (_vars.TryGetArray(varName, out ArrayValue arrayValue))
                return arrayValue;
                
            // 然后按类型优先级查找变量
            if (_vars.TryGetNumber(varName, out double numberValue)) return numberValue;
            if (_vars.TryGetBool(varName, out bool boolValue)) return boolValue;
            if (_vars.TryGetString(varName, out string stringValue)) return stringValue;
            
            return null;
        }
        
        private object EvaluateFunction(int functionIndex)
        {
            if (functionIndex < 0 || functionIndex >= _expr.F.Count)
                return null;

            var functionInfo = _expr.F[functionIndex];
            // 计算所有参数值
            var parameters = new object[functionInfo.C];
            for (var i = 0; i < functionInfo.C; i++)
                parameters[i] = GetValue(functionInfo.P[i]);

            // 调用变量提供器中的函数
            try {
                if (_vars.TryCallFunction(functionInfo.N, parameters, out var result))
                    return result;
            } catch (Exception e)
            {
                throw new Exception($"call function:{functionInfo.N} exception:{e}");
            }
            return null;
        }

        private double CompareNumbers(int leftNodeIndex, int rightNodeIndex)
        {
            return GetNumberValue(leftNodeIndex) - GetNumberValue(rightNodeIndex);
        }

        private bool ObjectsEqual(object a, object b)
        {
            if (a == null && b == null) return true;
            if (a == null || b == null) return false;

            if (a is string strA && b is string strB) return strA == strB;
            if (a is double numA && b is double numB) return Math.Abs(numA - numB) < 0.0001;
            if (a is bool boolA && b is bool boolB) return boolA == boolB;
            return Math.Abs(ConvertToNumber(a) - ConvertToNumber(b)) < 0.0001f;
        }

        private double ConvertToNumber(object value)
        {
            if (value == null) return 0;
            if (value is double d) return d;
            if (value is int i) return i;
            if (value is float f) return f;
            if (value is bool b) return b ? 1 : 0;
            if (value is string s) return string.IsNullOrEmpty(s) ? 0 : 1;
            return 0;
        }

        private bool ConvertToBool(object value)
        {
            if (value == null) return false;
            if (value is bool b) return b;
            if (value is double d) return d != 0;
            if (value is int i) return i != 0;
            if (value is float f) return f != 0;
            if (value is string s) return !string.IsNullOrEmpty(s);
            return true;
        }
    }
}