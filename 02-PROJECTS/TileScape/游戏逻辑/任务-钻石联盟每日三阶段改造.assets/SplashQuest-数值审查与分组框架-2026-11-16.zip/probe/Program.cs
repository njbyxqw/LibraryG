using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ProtoBuf;
using Betta.Framework;
using MainCfg=Module.SplashQuest.Config.Main;
using StageCfg=Module.SplashQuest.Config.Stage;
using AttrCfg=Module.UserLayer.Config.Attribute;
using RuleCfg=Module.UserLayer.Config.Rule;
class Context:IVariableProvider {
 public Dictionary<string,object> Values=new();
 public bool TryGetNumber(string n,out double v){v=0;if(Values.TryGetValue(n,out var x)&&x is double d){v=d;return true;}return false;}
 public bool TryGetBool(string n,out bool v){v=false;return false;}
 public bool TryGetString(string n,out string v){v=null;if(Values.TryGetValue(n,out var x)&&x is string s){v=s;return true;}return false;}
 public bool TryGetArray(string n,out ArrayValue v){v=null;return false;}
 public bool TryCallFunction(string n,object[] p,out object r){throw new Exception("unexpected function");}
}
class Program {
 static string root="/Users/dean/TileScape/Assets/Module/Activity/SplashQuest/Config/Data/";
 static List<object> checks=new();
 static List<T> Read<T>(string name){using var f=File.OpenRead(root+name+".bytes");var rows=Serializer.Deserialize<List<T>>(f);var js=JsonConvert.DeserializeObject<List<T>>(File.ReadAllText(root+name+".json~"));var x=JToken.FromObject(rows);var y=JToken.FromObject(js);if(!JToken.DeepEquals(x,y))throw new Exception(name+" bytes/json mismatch");checks.Add(new{name,count=rows.Count,bytesJsonMatch=true});return rows;}
 static void Main(){var mains=Read<MainCfg>("main");var stages=Read<StageCfg>("stage");var attrs=Read<AttrCfg>("attribute");var rules=Read<RuleCfg>("rule");
 object Eval(double? w,double? s,double? d,double? l){var c=new Context();if(w.HasValue)c.Values["level_streak_will_4"]=w.Value;if(s.HasValue)c.Values["level_streak_rate"]=s.Value;if(d.HasValue)c.Values["DIAMOND_NUM"]=d.Value;if(l.HasValue)c.Values["MAX_LEVEL"]=l.Value;foreach(var a in attrs){if(c.Values.ContainsKey(a.name))continue;if(ExpressionRuntime.Execute(a.condition,c))c.Values[a.name]=a.value;}int id=0,layer=0;foreach(var rr in rules){if(ExpressionRuntime.Execute(rr.condition,c)){id=rr.id;layer=rr.userLayer;break;}}return new{w,s,d,l,rule=id,layer,context=c.Values};}
 var matrix=new List<object>();foreach(double w in new[]{0,.1,.4})foreach(double s in new[]{0,.5,.95})foreach(double d in new[]{0,4000,10000})foreach(double l in new[]{49,50,55,104,105})matrix.Add(Eval((double)(float)w,(double)(float)s,d,l));
 var boundaries=new List<object>{Eval(null,null,null,null),Eval(-1,0,0,55),Eval(0,-1,0,55),Eval(0,0,-1,55),Eval(0,0,0,-1),Eval(0,0,0,55),Eval(0,0,0,105),Eval((double)(float).4,(double)(float).9,5000,105),Eval((double)(float).4,(double)(float).9001,5000,105)};
 var calc=new Calculator();Stage Make(StageCfg x)=>new(){id=x.id,winNum=x.winNum,DiamondCount=x.DiamondCount,PlayerNum=x.PlayerNum,MinExpectNum=x.MinExpectNum,MaxExpectNum=x.MaxExpectNum,UserSegmentationExpect=x.UserSegmentationExpect,AdjustIntensity=x.AdjustIntensity,LevelCoefList=x.LevelCoefList,ExtraJewelCoef=x.ExtraJewelCoef};
 var cases=new List<object>();
 foreach(var cfg in stages.Take(9))foreach(int retries in new[]{0,1,3,10,20}){
 var st=Make(cfg);var states=new Dictionary<int,double>{{-1,1}};for(int k=0;k<=retries;k++){var nx=new Dictionary<int,double>();foreach(var state in states)foreach(int branch in new[]{0,1}){UnityEngine.Random.Branch=branch;int e=calc.GetExpectPeople(st,0,0,state.Key);nx[e]=nx.GetValueOrDefault(e)+state.Value/2;}states=nx;}var outcomes=states.Select(x=>new{expected=x.Key,prob=x.Value,reward=(int)Math.Ceiling((double)st.DiamondCount/x.Key)}).ToList();cases.Add(new{stage=cfg.id,retries,assumption="zero consumption, base eliminations close exactly to E; conditional eventual completion",mean=outcomes.Sum(x=>x.reward*x.prob),min=outcomes.Min(x=>x.reward),max=outcomes.Max(x=>x.reward),outcomes});}
 var st10=Make(stages[2]);var carryCases=new List<object>();foreach(var c in new[]{100,196}){st10.MinExpectNum=c==196?15:7;int e=c==196?16:9;var result=calc.GetFailPeople(st10,e,0,Enumerable.Repeat(0,10).ToList(),new ProfileList<int>{c},c,0);carryCases.Add(new{carry=c,e,result});}
 var current=Make(stages[1]); var prior=calc.GetFailPeople(current,14,0,Enumerable.Repeat(0,7).ToList(),new ProfileList<int>{900},0,0); UnityEngine.Random.Branch=0; var nextE=calc.GetExpectPeople(current,0,prior.TotalJewelUsed,14); var next=calc.GetFailPeople(current,nextE,0,Enumerable.Repeat(0,7).ToList(),new ProfileList<int>{prior.TotalJewelUsed},prior.TotalJewelUsed,0); checks.Add(new{name="reachable_carry_negative", prior, nextE, next});
 File.WriteAllText("audit-results.json",JsonConvert.SerializeObject(new{checks,matrix,boundaries,noSpendRetries=cases,carryCases},Formatting.Indented));Console.WriteLine($"PASS: 4 bytes/JSON tables; {matrix.Count} grouping cases; {boundaries.Count} boundary cases; {cases.Count} retry cases.");}
}
