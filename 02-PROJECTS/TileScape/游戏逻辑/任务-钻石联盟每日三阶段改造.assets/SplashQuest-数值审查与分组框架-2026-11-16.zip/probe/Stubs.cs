namespace UnityEngine.Scripting { public class PreserveAttribute:System.Attribute {} }
namespace UnityEngine {public enum RuntimeInitializeLoadType{BeforeSceneLoad} public class RuntimeInitializeOnLoadMethodAttribute:System.Attribute{public RuntimeInitializeOnLoadMethodAttribute(RuntimeInitializeLoadType t){}}}
namespace Betta.Framework {public record ProtobufSubTypeSpec(int Tag,System.Type Type); public static class ProtobufRuntimeModelPolymorphism{public static void RegisterPolymorphism(System.Type t,ProtobufSubTypeSpec[] s){}}}
