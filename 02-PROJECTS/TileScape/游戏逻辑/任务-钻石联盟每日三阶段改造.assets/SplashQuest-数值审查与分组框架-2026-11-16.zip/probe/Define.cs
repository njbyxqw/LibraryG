using System;
using System.Collections.Generic;
using System.ComponentModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ProtoBuf;
using UnityEngine;
using UnityEngine.Scripting;

namespace Betta.Framework
{
    [Preserve]
    [ProtoContract]
    [Serializable]
    public class CompiledExpression
    {
        [ProtoMember(1)]
        [JsonProperty]
        public List<ExpressionNode> N { get; set; } = new();

        [ProtoMember(2)]
        [JsonProperty]
        public List<ConstantValue> C { get; set; } = new();

        [ProtoMember(3)]
        [JsonProperty]
        public List<string> V { get; set; } = new();

        [ProtoMember(4)]
        [JsonProperty]
        public List<ArrayValue> A { get; set; } = new();

        [ProtoMember(5)]
        [JsonProperty]
        public List<FunctionInfo> F { get; set; } = new();
    }

    [Preserve]
    [ProtoContract]
    [Serializable]
    public class ExpressionNode
    {
        [ProtoMember(1)]
        [JsonProperty]
        public NodeType T { get; set; }

        [ProtoMember(2)]
        [DefaultValue(0)]
        [JsonProperty]
        public int L { get; set; } = -1;

        [ProtoMember(3)]
        [DefaultValue(0)]
        [JsonProperty]
        public int R { get; set; } = -1;

        [ProtoMember(4)]
        [DefaultValue(0)]
        [JsonProperty]
        public int V { get; set; } = -1;

        [ProtoBeforeDeserialization]
        private void ProtoBeforeDeserialization()
        {
            T = default;
            L = 0;
            R = 0;
            V = 0;
        }
    }

    [Preserve]
    [ProtoContract]
    [Serializable]
    public class ConstantValue
    {
        [ProtoMember(1)]
        [JsonProperty]
        public ValueType T { get; set; }

        [ProtoMember(2)]
        [JsonProperty]
        public string V { get; set; }
    }

    [Preserve]
    [ProtoContract]
    [Serializable]
    public class ArrayValue
    {
        [ProtoMember(1)]
        [JsonProperty]
        [JsonConverter(typeof(ArrayElementItemsJsonConverter))]
        public List<ArrayElementBase> V { get; set; } = new();
    }

    [Preserve]
    [ProtoContract]
    [Serializable]
    [ProtoInclude(10, typeof(ArrayElementBool))]
    [ProtoInclude(11, typeof(ArrayElementDouble))]
    [ProtoInclude(12, typeof(ArrayElementString))]
    public class ArrayElementBase
    {
        private static readonly ProtobufSubTypeSpec[] SubTypesRegisteredAtStartup =
        {
            new (10, typeof(ArrayElementBool)),
            new (11, typeof(ArrayElementDouble)),
            new (12, typeof(ArrayElementString)),
        };

        [Preserve]
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void RegisterRuntimePolymorphism()
        {
            ProtobufRuntimeModelPolymorphism.RegisterPolymorphism(typeof(ArrayElementBase), SubTypesRegisteredAtStartup);
        }
    }

    [Preserve]
    [ProtoContract]
    [Serializable]
    public class ArrayElementBool : ArrayElementBase
    {
        [Preserve]
        public ArrayElementBool() { }

        [ProtoMember(1)]
        [JsonProperty]
        public bool B { get; set; }
    }

    [Preserve]
    [ProtoContract]
    [Serializable]
    public class ArrayElementDouble : ArrayElementBase
    {
        [Preserve]
        public ArrayElementDouble() { }

        [ProtoMember(1)]
        [JsonProperty]
        public double N { get; set; }
    }

    [Preserve]
    [ProtoContract]
    [Serializable]
    public class ArrayElementString : ArrayElementBase
    {
        [Preserve]
        public ArrayElementString() { }

        [ProtoMember(1)]
        [JsonProperty]
        public string S { get; set; }
    }

    [Preserve]
    [ProtoContract]
    [Serializable]
    public class FunctionInfo
    {
        [ProtoMember(1)]
        [JsonProperty]
        public string N { get; set; } = string.Empty;

        [ProtoMember(2)]
        [JsonProperty]
        public int C { get; set; }

        [ProtoMember(3)]
        [JsonProperty]
        public List<int> P { get; set; } = new();
    }

    public enum NodeType
    {
        // 逻辑操作符
        LogicalAnd,     // &&
        LogicalOr,      // ||
        LogicalNot,     // !
        Equal,          // ==
        NotEqual,       // !=
        GreaterThan,    // >
        LessThan,       // <
        GreaterOrEqual, // >=
        LessOrEqual,    // <=
        In,             // in (新增)
        
        // 算术操作符
        Add,            // +
        Subtract,       // -
        Multiply,       // *
        Divide,         // /
        
        // 操作数
        Constant,       // 常量
        Array,          // 数组
        Variable,       // 变量
        Function,       // 函数
    }

    public enum ValueType
    {
        Number,
        Boolean,
        String
    }

    [Preserve]
    internal static class ArrayElementRuntime
    {
        public static object ToObject(ArrayElementBase e)
        {
            if (e == null)
                return null;
            if (e is ArrayElementBool eb)
                return eb.B;
            if (e is ArrayElementDouble en)
                return en.N;
            if (e is ArrayElementString es)
                return es.S;
            return null;
        }
    }

    public sealed class ArrayElementItemsJsonConverter : JsonConverter<List<ArrayElementBase>>
    {
        public override void WriteJson(JsonWriter writer, List<ArrayElementBase> value, JsonSerializer serializer)
        {
            writer.WriteStartArray();
            if (value != null)
            {
                for (var i = 0; i < value.Count; i++)
                {
                    var e = value[i];
                    if (e is ArrayElementBool eb)
                        writer.WriteValue(eb.B);
                    else if (e is ArrayElementDouble ed)
                        writer.WriteValue(ed.N);
                    else if (e is ArrayElementString es)
                        writer.WriteValue(es.S);
                    else
                        writer.WriteNull();
                }
            }

            writer.WriteEndArray();
        }

        public override List<ArrayElementBase> ReadJson(JsonReader reader, Type objectType, List<ArrayElementBase> existingValue,
            bool hasExistingValue, JsonSerializer serializer)
        {
            var list = new List<ArrayElementBase>();
            if (reader.TokenType == JsonToken.Null)
                return list;

            var arr = JArray.Load(reader);
            for (var i = 0; i < arr.Count; i++)
            {
                var t = arr[i];
                if (t.Type == JTokenType.Null)
                    continue;
                switch (t.Type)
                {
                    case JTokenType.Boolean:
                        list.Add(new ArrayElementBool { B = t.Value<bool>() });
                        break;
                    case JTokenType.Integer:
                    case JTokenType.Float:
                        list.Add(new ArrayElementDouble { N = t.Value<double>() });
                        break;
                    case JTokenType.String:
                        list.Add(new ArrayElementString { S = t.Value<string>() });
                        break;
                    default:
                        throw new JsonSerializationException($"Unsupported array element token: {t.Type}");
                }
            }

            return list;
        }
    }
}
