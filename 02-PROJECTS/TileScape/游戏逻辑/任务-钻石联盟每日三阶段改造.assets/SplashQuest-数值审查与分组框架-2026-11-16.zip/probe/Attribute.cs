﻿//////////////////////////////////////////////////////////////////////////////////
// Config sheet : Module.UserLayer.Attribute (行类型 + 主键访问)
// This file cannot be modified!!!
// If there is a problem, please contact zengyunhan@bettagames.com or lianyonggang@bettagames.com
//////////////////////////////////////////////////////////////////////////////////

// ReSharper disable ClassNeverInstantiated.Global
// ReSharper disable UnassignedField.Global
// ReSharper disable InconsistentNaming

using Newtonsoft.Json;
using ProtoBuf;

namespace Module.UserLayer.Config
{
    [ProtoContract]
    public partial class Attribute
    {
        [ProtoMember(1)]
        [JsonProperty]
        public int id { get; private set; } // id
        [ProtoMember(2)]
        [JsonProperty]
        public string name { get; private set; } // 属性名
        [ProtoMember(3)]
        [JsonProperty]
        public int type { get; private set; } // 0-布尔表达式; 1-公式计算
        [ProtoMember(4)]
        [JsonProperty]
        public string value { get; private set; } // 属性值，可指定; 空就等于后面公式的返回值
        [ProtoMember(5)]
        [JsonProperty]
        public Betta.Framework.CompiledExpression condition { get; private set; } // 布尔表达式/公式
    }

    internal static class AttributeConfigKeys
    {
        internal static int GetKey(Attribute row) => row.id;
    }
}
