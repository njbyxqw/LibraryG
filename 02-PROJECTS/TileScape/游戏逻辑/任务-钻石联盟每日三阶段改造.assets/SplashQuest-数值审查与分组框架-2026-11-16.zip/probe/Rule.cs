﻿//////////////////////////////////////////////////////////////////////////////////
// Config sheet : Module.UserLayer.Rule (行类型 + 主键访问)
// This file cannot be modified!!!
// If there is a problem, please contact zengyunhan@bettagames.com or lianyonggang@bettagames.com
//////////////////////////////////////////////////////////////////////////////////

// ReSharper disable ClassNeverInstantiated.Global
// ReSharper disable UnassignedField.Global
// ReSharper disable InconsistentNaming

using Newtonsoft.Json;
using ProtoBuf;

namespace Module.UserLayer.Config
{
    [ProtoContract]
    public partial class Rule
    {
        [ProtoMember(1)]
        [JsonProperty]
        public int id { get; private set; } // id
        [ProtoMember(2)]
        [JsonProperty]
        public int userLayer { get; private set; } // 用户组
        [ProtoMember(3)]
        [JsonProperty]
        public Betta.Framework.CompiledExpression condition { get; private set; } // 
    }

    internal static class RuleConfigKeys
    {
        internal static int GetKey(Rule row) => row.id;
    }
}
