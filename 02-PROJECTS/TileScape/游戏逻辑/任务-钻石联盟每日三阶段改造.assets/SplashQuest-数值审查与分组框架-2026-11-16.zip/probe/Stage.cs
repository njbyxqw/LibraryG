﻿//////////////////////////////////////////////////////////////////////////////////
// Config sheet : Module.SplashQuest.Stage (行类型 + 主键访问)
// This file cannot be modified!!!
// If there is a problem, please contact zengyunhan@bettagames.com or lianyonggang@bettagames.com
//////////////////////////////////////////////////////////////////////////////////

// ReSharper disable ClassNeverInstantiated.Global
// ReSharper disable UnassignedField.Global
// ReSharper disable InconsistentNaming

using System.Linq;
using Newtonsoft.Json;
using ProtoBuf;

namespace Module.SplashQuest.Config
{
    [ProtoContract]
    public partial class Stage
    {
        [ProtoContract]
        private class IntRow
        {
            [ProtoMember(1)]
            public int[] values { get; set; }
        }

        [ProtoMember(1)]
        [JsonProperty]
        public int id { get; private set; } // ID
        [ProtoMember(2)]
        [JsonProperty]
        public int DiamondCount { get; private set; } // 瓜分钻石奖励
        [ProtoMember(3)]
        // ReSharper disable once UnusedMember.Local
        private IntRow[] RewardRows
        {
            get => Reward?.Select(r => new IntRow { values = r }).ToArray();
            set => Reward = value?.Select(r => r?.values).ToArray();
        }
        [JsonProperty]
        public int[][] Reward { get; private set; } = new int[0][]; // 通关奖励
        [ProtoMember(4)]
        [JsonProperty]
        public int winNum { get; private set; } // 所需通关次数
        [ProtoMember(5)]
        [JsonProperty]
        public int PlayerNum { get; private set; } // 参与玩家数
        [ProtoMember(6)]
        [JsonProperty]
        public int MaxExpectNum { get; private set; } // 基础存活人数上限
        [ProtoMember(7)]
        [JsonProperty]
        public int MinExpectNum { get; private set; } // 基础存活人数下限
        [ProtoMember(8)]
        [JsonProperty]
        public int UserSegmentationExpect { get; private set; } // 初始存活人数期望
        [ProtoMember(9)]
        [JsonProperty]
        public int AdjustIntensity { get; private set; } // 调节强度
        [ProtoMember(10)]
        [JsonProperty]
        public float[] LevelCoefList { get; private set; } = System.Array.Empty<float>(); // 关卡难度系数（普通关，困难关，极难关，奖励关， 指引关）
        [ProtoMember(11)]
        [JsonProperty]
        public float[] ExtraJewelCoef { get; private set; } = System.Array.Empty<float>(); // 关卡额外钻石返还系数
    }

    internal static class StageConfigKeys
    {
        internal static int GetKey(Stage row) => row.id;
    }
}
