﻿//////////////////////////////////////////////////////////////////////////////////
// Config sheet : Module.SplashQuest.Main (行类型 + 主键访问)
// This file cannot be modified!!!
// If there is a problem, please contact zengyunhan@bettagames.com or lianyonggang@bettagames.com
//////////////////////////////////////////////////////////////////////////////////

// ReSharper disable ClassNeverInstantiated.Global
// ReSharper disable UnassignedField.Global
// ReSharper disable InconsistentNaming

using Newtonsoft.Json;
using ProtoBuf;

namespace Module.SplashQuest.Config
{
    [ProtoContract]
    public partial class Main
    {
        [ProtoMember(1)]
        [JsonProperty]
        public int id { get; private set; } // 唯一标识
        [ProtoMember(2)]
        [JsonProperty]
        public string userLayerType { get; private set; } // 用户组类型
        [ProtoMember(3)]
        [JsonProperty]
        public int userLayer { get; private set; } // 活动分层
        [ProtoMember(4)]
        [JsonProperty]
        public int[] stages { get; private set; } = System.Array.Empty<int>(); // 阶段
        [ProtoMember(5)]
        [JsonProperty]
        public int CDtime { get; private set; } // CD时间
        [ProtoMember(6)]
        [JsonProperty]
        public int loginForcePopup { get; private set; } // 登陆强弹
        [ProtoMember(7)]
        [JsonProperty]
        public int postSettleForcePopupAfterLevels { get; private set; } // 未参加活动状态过关强弹
        [ProtoMember(8)]
        [JsonProperty]
        public int postSettleForcePopupDailyLimit { get; private set; } // 非登录强弹上限
    }

    internal static class MainConfigKeys
    {
        internal static int GetKey(Main row) => row.id;
    }
}
