using System;
using System.Collections.Generic;
public class Stage { public int id,winNum,DiamondCount,PlayerNum,MinExpectNum,MaxExpectNum,UserSegmentationExpect,AdjustIntensity; public float[] LevelCoefList=Array.Empty<float>(),ExtraJewelCoef=Array.Empty<float>(); }
public class ProfileList<T>:List<T>{}
public static class UtilsLog { public static void E(string s){throw new Exception(s);} }
public static class Mathf { public static int Max(int a,int b)=>Math.Max(a,b); public static int Min(int a,int b)=>Math.Min(a,b); public static int Clamp(int a,int lo,int hi)=>Math.Clamp(a,lo,hi); public static float Pow(float a,float b)=>(float)Math.Pow(a,b); public static int RoundToInt(float a)=>(int)Math.Round(a,MidpointRounding.ToEven); }
namespace UnityEngine {public static class Random {public static int Branch;public static int Range(int lo,int hi){if(hi<lo)throw new Exception("bad random bounds");return hi==lo?lo:lo+Math.Min(Branch,hi-lo-1);}}}
public struct ActSplashQuestProcessData {public int FailPeopleNum,TotalJewelUsed,TotalExtraFailNum;}
public class Calculator {
        public int GetExpectPeople(Stage stageCfg, int lastIfPass, int lastTotalJewelUsed, int lastExpectPeople)
        {
            if (lastExpectPeople == -1)
            {
                lastExpectPeople = stageCfg.UserSegmentationExpect;
            }
            else
            {
                if (lastIfPass == 1)
                {
                    lastExpectPeople = Mathf.Max(
                        Mathf.Min(lastExpectPeople + stageCfg.AdjustIntensity, stageCfg.MaxExpectNum),
                        stageCfg.MinExpectNum);
                }

                if (lastIfPass == 0 && lastTotalJewelUsed > 200)
                {
                    lastExpectPeople = Mathf.Max(
                        Mathf.Min(lastExpectPeople - stageCfg.AdjustIntensity, stageCfg.MaxExpectNum),
                        stageCfg.MinExpectNum);
                }
            }

            return UnityEngine.Random.Range(Mathf.Max(stageCfg.MinExpectNum, lastExpectPeople - 1),
                Mathf.Min(stageCfg.MaxExpectNum, lastExpectPeople + 1));
        }
        public ActSplashQuestProcessData GetFailPeople(Stage stageCfg, int expectPeople, int level, List<int> levelTypeList,
            ProfileList<int> jewelUseList, int totalJewelUsed, int currentTotalExtraFailNum)
        {
            if (stageCfg == null)
            {
                UtilsLog.E("[SplashQuest][PeopleRule][GetFailPeople] stageCfg is null, fallback to zero process data.");
                return new ActSplashQuestProcessData
                {
                    FailPeopleNum = 0,
                    TotalJewelUsed = totalJewelUsed,
                    TotalExtraFailNum = currentTotalExtraFailNum
                };
            }

            if (level < 0)
            {
                level = 0;
            }
            var totalLevelNum = stageCfg.winNum;
            if (totalLevelNum <= 0)
            {
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople] invalid stage winNum={stageCfg.winNum}, stageId={stageCfg.id}, fallback to zero process data.");
                return new ActSplashQuestProcessData
                {
                    FailPeopleNum = 0,
                    TotalJewelUsed = totalJewelUsed,
                    TotalExtraFailNum = currentTotalExtraFailNum
                };
            }
            if (level >= totalLevelNum)
            {
                level = totalLevelNum - 1;
            }
            expectPeople = Mathf.Max(1, expectPeople);
            var jewelNum = stageCfg.DiamondCount;
            var hasGuardFallback = false;

            if (levelTypeList == null)
            {
                hasGuardFallback = true;
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople][Guard] levelTypeList is null. stageId={stageCfg.id}, level={level}, totalLevelNum={totalLevelNum}");
                levelTypeList = new List<int>(totalLevelNum);
            }

            if (jewelUseList == null)
            {
                hasGuardFallback = true;
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople][Guard] jewelUseList is null. stageId={stageCfg.id}, level={level}, totalLevelNum={totalLevelNum}");
                jewelUseList = new ProfileList<int>();
            }

            if (stageCfg.LevelCoefList == null || stageCfg.LevelCoefList.Length == 0)
            {
                hasGuardFallback = true;
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople][Guard] LevelCoefList invalid. stageId={stageCfg.id}, level={level}, levelCoefLen={(stageCfg.LevelCoefList == null ? -1 : stageCfg.LevelCoefList.Length)}");
            }

            if (stageCfg.ExtraJewelCoef == null || stageCfg.ExtraJewelCoef.Length == 0)
            {
                hasGuardFallback = true;
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople][Guard] ExtraJewelCoef invalid. stageId={stageCfg.id}, level={level}, extraCoefLen={(stageCfg.ExtraJewelCoef == null ? -1 : stageCfg.ExtraJewelCoef.Length)}");
            }

            var avgDiff = Mathf.Pow(1 / ((float)expectPeople / stageCfg.PlayerNum), 1f / totalLevelNum);

            var failPropList = new List<float>(totalLevelNum);
            for (var i = 0; i < totalLevelNum; i++)
            {
                var failProp = 1 / Mathf.Pow(avgDiff, i) * (1 - 1 / avgDiff);
                failPropList.Add(failProp);
            }

            var coefList = new List<float>(totalLevelNum);
            for (var i = 0; i < totalLevelNum; i++)
            {
                var safeLevelType = 0;
                if (i < levelTypeList.Count)
                {
                    safeLevelType = levelTypeList[i];
                }
                else
                {
                    hasGuardFallback = true;
                    UtilsLog.E(
                        $"[SplashQuest][PeopleRule][GetFailPeople][Guard] levelTypeList index out of range. stageId={stageCfg.id}, level={level}, needIndex={i}, levelTypeCount={levelTypeList.Count}, totalLevelNum={totalLevelNum}");
                }

                var safeCoef = 1f;
                if (stageCfg.LevelCoefList != null && stageCfg.LevelCoefList.Length > 0)
                {
                    var clampedLevelType = Mathf.Clamp(safeLevelType, 0, stageCfg.LevelCoefList.Length - 1);
                    if (clampedLevelType != safeLevelType)
                    {
                        hasGuardFallback = true;
                        UtilsLog.E(
                            $"[SplashQuest][PeopleRule][GetFailPeople][Guard] levelType exceeds LevelCoefList range. stageId={stageCfg.id}, level={level}, levelType={safeLevelType}, clamped={clampedLevelType}, levelCoefLen={stageCfg.LevelCoefList.Length}");
                    }

                    safeCoef = stageCfg.LevelCoefList[clampedLevelType];
                }

                coefList.Add(safeCoef);
            }

            float sum1 = 0;
            float sum2 = 0;
            for (var i = 0; i < failPropList.Count; i++)
            {
                sum1 += failPropList[i] * coefList[i];
                sum2 += failPropList[i];
            }

            var avgCoef = sum1 / sum2;
            var expectFailNumList = new List<int>(totalLevelNum);
            var sum3 = 0;
            for (var i = 0; i < totalLevelNum; i++)
            {
                if (i == totalLevelNum - 1)
                {
                    var expectFailNum = Mathf.Max(0, stageCfg.PlayerNum - expectPeople - sum3);
                    expectFailNumList.Add(expectFailNum);
                    sum3 += expectFailNum;
                }
                else
                {
                    var safeCoef = i < coefList.Count ? coefList[i] : 1f;
                    if (i >= coefList.Count)
                    {
                        hasGuardFallback = true;
                        UtilsLog.E(
                            $"[SplashQuest][PeopleRule][GetFailPeople][Guard] coefList index out of range. stageId={stageCfg.id}, level={level}, index={i}, coefCount={coefList.Count}, fallbackCoef=1");
                    }

                    var expectFailNum =
                        Mathf.RoundToInt(safeCoef / avgCoef * failPropList[i] * stageCfg.PlayerNum);
                    expectFailNumList.Add(expectFailNum);
                    sum3 += expectFailNum;
                }
            }

            var extraFailNum = 0;
            var safeJewelUseAtLevel = 0;
            if (level < jewelUseList.Count)
            {
                safeJewelUseAtLevel = jewelUseList[level];
            }
            else
            {
                hasGuardFallback = true;
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople][Guard] jewelUseList index out of range. stageId={stageCfg.id}, level={level}, jewelUseCount={jewelUseList.Count}, fallbackValue=0");
            }

            var safeExtraCoefAtLevel = 0f;
            if (stageCfg.ExtraJewelCoef != null && stageCfg.ExtraJewelCoef.Length > 0)
            {
                var safeExtraCoefIndex = Mathf.Clamp(level, 0, stageCfg.ExtraJewelCoef.Length - 1);
                safeExtraCoefAtLevel = stageCfg.ExtraJewelCoef[safeExtraCoefIndex];
                if (safeExtraCoefIndex != level)
                {
                    hasGuardFallback = true;
                    UtilsLog.E(
                        $"[SplashQuest][PeopleRule][GetFailPeople][Guard] ExtraJewelCoef index out of range. stageId={stageCfg.id}, level={level}, clamped={safeExtraCoefIndex}, extraCoefLen={stageCfg.ExtraJewelCoef.Length}");
                }
            }

            if (expectPeople - currentTotalExtraFailNum > stageCfg.MinExpectNum &&
                safeJewelUseAtLevel * safeExtraCoefAtLevel + totalJewelUsed >
                (float)jewelNum / (expectPeople - currentTotalExtraFailNum - 1) -
                (float)jewelNum / (expectPeople - currentTotalExtraFailNum))
            {
                extraFailNum = 1;
            }

            var totalExtraFailNum = currentTotalExtraFailNum + extraFailNum;
            var failPeopleNum = expectFailNumList[level] + extraFailNum;

            float sum4 = 0;
            for (var i = 0; i <= level; i++)
            {
                var safeJewelUse = 0;
                if (i < jewelUseList.Count)
                {
                    safeJewelUse = jewelUseList[i];
                }
                else
                {
                    hasGuardFallback = true;
                    UtilsLog.E(
                        $"[SplashQuest][PeopleRule][GetFailPeople][Guard] jewelUseList sum index out of range. stageId={stageCfg.id}, level={level}, needIndex={i}, jewelUseCount={jewelUseList.Count}, fallbackValue=0");
                }

                var safeExtraCoef = 0f;
                if (stageCfg.ExtraJewelCoef != null && stageCfg.ExtraJewelCoef.Length > 0)
                {
                    var safeExtraCoefIndex = Mathf.Clamp(i, 0, stageCfg.ExtraJewelCoef.Length - 1);
                    safeExtraCoef = stageCfg.ExtraJewelCoef[safeExtraCoefIndex];
                    if (safeExtraCoefIndex != i)
                    {
                        hasGuardFallback = true;
                        UtilsLog.E(
                            $"[SplashQuest][PeopleRule][GetFailPeople][Guard] ExtraJewelCoef sum index out of range. stageId={stageCfg.id}, level={level}, needIndex={i}, clamped={safeExtraCoefIndex}, extraCoefLen={stageCfg.ExtraJewelCoef.Length}");
                    }
                }

                sum4 += safeJewelUse * safeExtraCoef;
            }

            totalJewelUsed = Mathf.RoundToInt(sum4 - (float)jewelNum / (expectPeople - totalExtraFailNum) +
                                              jewelNum / (float)expectPeople);
            if (hasGuardFallback)
            {
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople][GuardSummary] stageId={stageCfg.id}, level={level}, totalLevelNum={totalLevelNum}, levelTypeCount={levelTypeList.Count}, jewelUseCount={jewelUseList.Count}, levelCoefLen={(stageCfg.LevelCoefList == null ? -1 : stageCfg.LevelCoefList.Length)}, extraCoefLen={(stageCfg.ExtraJewelCoef == null ? -1 : stageCfg.ExtraJewelCoef.Length)}, fallbackApplied=true");
            }

            return new ActSplashQuestProcessData
            {
                FailPeopleNum = failPeopleNum,
                TotalJewelUsed = totalJewelUsed,
                TotalExtraFailNum = totalExtraFailNum
            };
        }
}