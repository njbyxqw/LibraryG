# SplashQuest 数值审查与分组框架证据（2026-11-16）

正文以 LG 实施主档的“数值后续任务（2026-11-16）”为准，本附件只提供证据和可复用的分析输入。

- snapshots：当前客户端导出快照，4 表 bytes 与 JSON 已按生成类解码对齐。
- audit-results.json：135 个分组输入、9 个边界输入、45 个零消费重试枚举及当前配置可达负余额例。carryCases 是补充合成例，不当作当前参数证明。
- group-matrix.csv：同一批分组输入及规则命中。105 关以上 27 个组合构成常规矩阵，多个早期关卡点用于边界核对。
- framework-R0.json：未审批的分析框架与旧候选，不是可导入游戏的配置。55～104 保护组目标档位未定。
- probe：本次离线探针与依赖的提取源码，保留原现场。引用本地项目 protobuf-net、Newtonsoft.Json；复跑时需按本机项目路径修改 Program.cs 和 Audit.csproj，再在 probe 目录运行 .NET 10。Calculator 仅公开方法供调用；随机分支穷举和 Unity 数学替身不代表 Unity 运行验证。
- historical-simulation-repro.zip：先前试算原包，只作候选和历史结果来源。其 5 项核心输入哈希本次未变；未重新验证全量关卡资源，不能把历史全量模拟称为本次运行。
- audit-manifest.json：当前源码与配置哈希，用于检查版本漂移。

代码问题尚未修复；重启消费及领奖失败链需要后续运行复现。不存在真实账号分组占比、完成率或线上均值。
