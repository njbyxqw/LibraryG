2026-11-18 historical candidate; user chose to keep previous config. Normal base reward 3024 and half coefficients NOT adopted. Original files copied without recalculation.
