using Interface.Activity;
using Module.Activity.Message;
using Module.Activity.SplashQuest;
using Betta.Framework;
using BettaSDK;

namespace Module.Activity
{
    public partial class ActSplashQuest
    {
        private const string PendingChangedTiming = "SplashQuest.PendingChanged";
        private const int PendingFlagWinReward = 1;
        private const int PendingFlagTimeout = 4;
        private const int PendingFlagWinPresentation = 8;
        private const int PendingFlagNextStageOpening = 16;

        public void ConsumeMainViewState()
        {
            SetMainViewState(SplashQuestMainViewState.None);
        }

        public bool HasPendingWinRewardClaim()
        {
            return _profile != null && (_profile.PendingFlags & PendingFlagWinReward) != 0;
        }

        public bool HasPendingTimeoutPopup()
        {
            return _profile != null && (_profile.PendingFlags & PendingFlagTimeout) != 0;
        }

        public void MarkPendingWinRewardClaim()
        {
            if (_profile == null)
            {
                return;
            }

            _profile.PendingFlags |= PendingFlagWinReward;
            EnsureWinRewardSnapshot();
        }

        public void CompletePendingWinRewardClaim()
        {
            if (_profile == null)
            {
                return;
            }

            _profile.PendingFlags &= ~PendingFlagWinReward;
            TryDispatchRefreshActivityStateAfterPendingChanged();
        }

        public bool ConsumePendingTimeoutPopup()
        {
            if (_profile == null || (_profile.PendingFlags & PendingFlagTimeout) == 0)
            {
                return false;
            }

            _profile.PendingFlags &= ~PendingFlagTimeout;
            TryDispatchRefreshActivityStateAfterPendingChanged();
            return true;
        }

        private void TryDispatchRefreshActivityStateAfterPendingChanged()
        {
            if (IsWaitingForClaim || CurrentState == SplashQuestState.Timeout)
            {
                ImplementHub.Instance.Get<IActivitySystem>()?.NotifyTiming(PendingChangedTiming);
                return;
            }

            if (ActivityData != null && ActivityData.TimeEnd > 0 && UtilsTime.TimeSeconds >= ActivityData.TimeEnd)
            {
                ImplementHub.Instance.Get<IActivitySystem>()?.NotifyTiming(PendingChangedTiming);
            }
        }

        public bool IsTerminalStageState()
        {
            return IsAllRewardsClaimed();
        }

        public void CheckTimeOut()
        {
            if (_profile == null || ActivityData == null)
            {
                return;
            }

            if (ActivityData.TimeEnd == 0 || ActivityData.TimeEnd > UtilsTime.TimeSeconds)
            {
                return;
            }

            var state = CurrentState;
            if (state == SplashQuestState.Timeout || state == SplashQuestState.Finished)
            {
                return;
            }

            if (HasPendingWinPresentation() && IsAllRewardsClaimed())
            {
                return;
            }
            _profile.PendingFlags |= PendingFlagTimeout;

            TrackEvent(5);

            SetState(SplashQuestState.Timeout);
            if (!HasPendingWinRewardClaim() && !HasPendingWinPresentation())
            {
                SetMainViewState(SplashQuestMainViewState.None);
                SetStageViewState(SplashQuestStageViewState.NoChange);
            }
            _markForPopup = true;
            DispatchRefreshActivityUi();
        }
        public bool HasPendingWinPresentation()
        {
            return _profile != null && (_profile.PendingFlags & PendingFlagWinPresentation) != 0;
        }

        private void EnsureWinRewardSnapshot()
        {
            if (_profile.PendingWinStageId > 0)
            {
                return;
            }
            var config = GetCurrentStageCfg();
            if (config == null)
            {
                return;
            }
            _profile.PendingWinStageId = config.id;
            _profile.PendingWinStageIndex = GetCurrentStageIndex();
            _profile.PendingWinPeriodId = PeriodId;
            _profile.PendingWinPool = config.DiamondCount;
            _profile.PendingWinPeople = UnityEngine.Mathf.Max(1, _profile.LeftNumOfPeople);
            _profile.PendingWinReward = (int)(((long)config.DiamondCount + _profile.PendingWinPeople - 1) / _profile.PendingWinPeople);
        }

        private void ClearWinRewardSnapshot()
        {
            _profile.PendingWinStageId = 0;
            _profile.PendingWinStageIndex = 0;
            _profile.PendingWinPeriodId = 0;
            _profile.PendingWinPool = 0;
            _profile.PendingWinPeople = 0;
            _profile.PendingWinReward = 0;
        }

        public bool IsCurrentPeriod(int periodId)
        {
            return _profile != null && PeriodId == periodId;
        }

        public void CompleteTimeoutPresentation(int periodId)
        {
            if (!IsCurrentPeriod(periodId) || CurrentState != SplashQuestState.Timeout ||
                HasPendingWinRewardClaim() || HasPendingWinPresentation())
            {
                return;
            }
            _profile.PendingFlags &= ~PendingFlagTimeout;
            Finish();
        }
        private void PersistActivityState()
        {
            var hub = BettaSDK.Profile.ProfileHub.Instance;
            if (hub.Initialized && ReferenceEquals(hub.GetProfile<BettaSDK.Profile.ProfileActivity>()?.SplashQuest, _profile))
            {
                hub.SaveToLocal(true);
            }
        }
    }
}
