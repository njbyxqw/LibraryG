using Interface.Item;
using Module.Activity.Message;
using Module.SplashQuest.Config;
using Betta.Framework;
using BettaSDK;

namespace Module.Activity
{
    public partial class ActSplashQuest
    {
        private bool TryGetStages(out Main mainCfg, out int[] stages)
        {
            mainCfg = GetMainCfg();
            if (mainCfg == null || mainCfg.stages == null || mainCfg.stages.Length == 0)
            {
                stages = null;
                return false;
            }

            stages = mainCfg.stages;
            return true;
        }

        private void DispatchRefreshActivityUi()
        {
            MessageDispatch.Instance.Dispatch(ActivityMessageType.RefreshActivityUI, Name);
        }

        private void ClearPerRunWinCountAndJewelLists()
        {
            _profile.WinCount = 0;
            _profile.TotalExtraFailNum = 0;
            if (_profile.JewelUseList != null)
            {
                _profile.JewelUseList.Clear();
            }

            if (_profile.LevelTypeList != null)
            {
                _profile.LevelTypeList.Clear();
            }
        }

        internal static Interface.Item.IItemRewardCell CreateRewardCell(UnityEngine.Transform parent, int[] reward, float size)
        {
            var system = ImplementHub.Instance.Get<Interface.Reward.IRewardSystem>();
            if (system == null || !system.TryResolve(reward[0], reward[1], out var resolved)) return null;
            var cell = ImplementHub.Instance.Get<Interface.Item.IItemRewardCellFactory>().Create(parent,
                new Interface.Item.ItemRewardCellOptions(size, size, Interface.Item.ItemRewardCellStyle.Plain));
            cell.Bind(new Interface.Item.ItemRewardCellData(resolved.ItemId, (long)resolved.DisplayValue, false,
                resolved.GraphicVariant, resolved.DisplayValueType, resolved.DurationSeconds));
            return cell;
        }

        internal static System.Collections.Generic.List<Interface.Reward.RewardEntryAmount> RewardEntries(int[][] rewards)
        {
            var result = new System.Collections.Generic.List<Interface.Reward.RewardEntryAmount>();
            if (rewards == null) return result;
            for (var i = 0; i < rewards.Length; i++)
                if (rewards[i] != null && rewards[i].Length >= 2)
                    result.Add(new Interface.Reward.RewardEntryAmount(rewards[i][0], rewards[i][1]));
            return result;
        }

        private bool GrantRewards(int[][] rewards, string method)
        {
            var entries = RewardEntries(rewards);
            if (entries.Count == 0) return true;
            var rewardSystem = ImplementHub.Instance.Get<Interface.Reward.IRewardSystem>();
            return rewardSystem != null && rewardSystem.TryGrant(new Interface.Reward.RewardGrantRequest
            {
                Rewards = entries,
                Method = method,
                SubMethod = $"splashquest_{ConfigId}_{GetTrackingRound()}_1",
            }, out _);
        }
    }
}
