namespace Module.Activity.SplashQuest
{
    public enum SplashQuestMainViewState
    {
        None = 0,
        EnterRun = 1,
        SettleSuccess = 2,
        SettleFail = 3,
        Timeout = 4,
    }

    public enum SplashQuestStageViewState
    {
        NoChange = 0,
        Success = 1,
        Fail = 2,
    }

public enum SplashQuestTipsViewState
{
    Generic = 0,
    Preview = 1,
    Timeout = 2,
    Completed = 3,
}
}
