using UnityEngine.UI;
using Betta.Framework;
using UnityEngine;

public partial class UIActSplashQuestMainPanel
{
    private Button btn_FullPageClose;
    private Button btn_Play;
    private Button btn_Help;
    private Button btn_Close;
    private RectTransform trans_MapRoot;
    private RectTransform trans_ItemParent;
    private UIText txt_Stage;
    private UIText txt_RewardPool;
    private UIText txt_Progress;
    private RectTransform trans_Effect_PenShe;
    private UIText txt_LeftNum;
    private UIText txt_TimeLeft;

    private void AssembleUI()
    {
        btn_FullPageClose = Transform.Find("Root/btn_FullPageClose").GetComponent<Button>();
        btn_Play = Transform.Find("Root/btn_Play").GetComponent<Button>();
        btn_Help = Transform.Find("Root/btn_Help").GetComponent<Button>();
        btn_Close = Transform.Find("Root/btn_Close").GetComponent<Button>();
        trans_MapRoot = Transform.Find("Content/trans_MapRoot").GetComponent<RectTransform>();
        trans_ItemParent = Transform.Find("Content/trans_ItemParent").GetComponent<RectTransform>();
        txt_Stage = Transform.Find("Content/trans_MapRoot/Top/Root/Stage/txt_Stage").GetComponent<UIText>();
        txt_RewardPool = Transform.Find("Content/trans_MapRoot/Top/Root/Stage/Reward/Count").GetComponent<UIText>();
        txt_Progress = Transform.Find("Content/Progress/txt_Progress").GetComponent<UIText>();
        trans_Effect_PenShe = Transform.Find("Content/LeftNum/trans_Effect_PenShe").GetComponent<RectTransform>();
        txt_LeftNum = Transform.Find("Content/LeftNum/txt_LeftNum").GetComponent<UIText>();
        txt_TimeLeft = Transform.Find("Content/Title/TimeClock/Bg/txt_TimeLeft1").GetComponent<UIText>();
    }

}
