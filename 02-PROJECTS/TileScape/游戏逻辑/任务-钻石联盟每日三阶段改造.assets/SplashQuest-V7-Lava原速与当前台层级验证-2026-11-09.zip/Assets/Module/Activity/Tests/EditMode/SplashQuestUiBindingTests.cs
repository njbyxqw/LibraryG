using System.Reflection;
using Betta.Framework;
using Module.Activity.SplashQuest;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace Module.Activity.Tests.EditMode
{
    public sealed class SplashQuestUiBindingTests
    {
        private const string PrefabRoot = "Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/";

        [TestCase(5)]
        [TestCase(7)]
        [TestCase(10)]
        public void MainPanelBindsSharedLayoutAndEveryMapSection(int maxLevel)
        {
            var asset = PrefabUtility.LoadPrefabContents(PrefabRoot +
                $"UIActSplashQuestMainPanel_{maxLevel}.prefab");
            try
            {
                var panel = new UIActSplashQuestMainPanel();
                Bind(panel, asset, "AssembleUI");
                AssertComponentFields(panel);
                var map = (RectTransform)typeof(UIActSplashQuestMainPanel)
                    .GetField("trans_MapRoot", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(panel);
                Assert.That(map.Find("Middle").childCount, Is.EqualTo(maxLevel - 1));
                var activity = new ActSplashQuest(ActSplashQuest.ActivityId);
                for (var level = 0; level <= maxLevel; level++)
                {
                    var path = level == 0 ? "Bottom" : level == maxLevel ? "Top" : $"Middle/Level_{level}";
                    var section = new UISplashQuestMapSection(map.Find(path), activity, level, maxLevel);
                    try
                    {
                        Assert.That(section.ItemRoot, Is.Not.Null, path);
                    }
                    finally
                    {
                        section.OnRelease();
                    }
                }
            }
            finally
            {
                PrefabUtility.UnloadPrefabContents(asset);
            }
        }

        [Test]
        public void OpeningPanelBindsMovedStageClockAndNestedConfirmButton()
        {
            var asset = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabRoot + "UIActSplashQuestTipsPanel.prefab");
            Assert.That(asset, Is.Not.Null);
            var panel = new UIActSplashQuestTipsPanel();
            Bind(panel, asset, "AssembleUI");
            AssertComponentFields(panel);
        }

        [Test]
        public void EntryBindsTheSingleSliderUnderUnlockRoot()
        {
            var asset = AssetDatabase.LoadAssetAtPath<GameObject>(
                "Assets/Module/Activity/SplashQuest/ResDLC/Default/Entry/ActSplashQuestEntry.prefab");
            Assert.That(asset, Is.Not.Null);
            var entry = new UIActSplashQuestEntry();
            Bind(entry, asset, "FindComponents");
            var slider = typeof(UIActSplashQuestEntry)
                .GetField("_slider", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(entry);
            Assert.That(slider, Is.Not.Null);
        }

        private static void Bind(UIBase view, GameObject asset, string methodName)
        {
            typeof(UIBase).GetProperty("RectTransform").SetValue(view, asset.GetComponent<RectTransform>());
            var method = view.GetType().GetMethod(methodName, BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.That(method, Is.Not.Null);
            Assert.DoesNotThrow(() => method.Invoke(view, null));
        }

        private static void AssertComponentFields(UIBase view)
        {
            var fields = view.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic);
            foreach (var field in fields)
            {
                // Runtime snapshots are captured after AssembleUI; only generated UI bindings belong here.
                if (!field.Name.StartsWith("_") && typeof(Component).IsAssignableFrom(field.FieldType))
                {
                    Assert.That(field.GetValue(view), Is.Not.Null, field.Name);
                }
            }
        }
    }
}
