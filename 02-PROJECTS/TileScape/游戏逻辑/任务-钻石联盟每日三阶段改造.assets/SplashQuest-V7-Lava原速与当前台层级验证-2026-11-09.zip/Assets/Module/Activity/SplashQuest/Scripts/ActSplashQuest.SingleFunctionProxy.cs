using Betta.Framework;
using Interface.Activity;
using Module.Activity.SplashQuest;

namespace Module.Activity
{
    public partial class ActSplashQuest
    {
        public IActivityExitNode GetExitNode(string opportunity)
        {
            return opportunity == "Revive" && UISplashQuestExitNode.Check() ? new UISplashQuestExitNode() : null;
        }
        public string GetTileBackgroundPath(int levelId, int levelType)
        {
            return IsActive() && CurrentState == SplashQuestState.InRun ? "Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/SplashQuestTileBackground.prefab" : string.Empty;
        }
        public bool CanShowEntry()
        {
            return CanPresent() && (HasPendingWinRewardClaim() || HasPendingWinPresentation() ||
                HasPendingTimeoutPopup() || (CurrentState != SplashQuestState.Timeout && CurrentState != SplashQuestState.Finished));
        }
        protected override bool ShouldRefreshForReason(string reason)
        {
            return reason == PendingChangedTiming || reason == ActivityTiming.ClosedPoll ||
                base.ShouldRefreshForReason(reason);
        }

        public override bool CanMaintainOpen()
        {
            CheckTimeOut();
            return (base.CanMaintainOpen() && CanActive()) || NeedToWaitForClaim();
        }
    }
}
