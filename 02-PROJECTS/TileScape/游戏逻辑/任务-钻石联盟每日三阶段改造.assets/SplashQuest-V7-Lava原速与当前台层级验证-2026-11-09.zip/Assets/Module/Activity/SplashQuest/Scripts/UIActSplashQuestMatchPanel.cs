using Interface.UI;
using Interface.Activity;
using Module.Activity.Flow;
using TransformUtils = Module.Utils.UtilsTransform;
using System.Collections.Generic;
using Module.Activity;
using Module.Activity.SplashQuest;
using Betta.Framework;
using BettaSDK;
using DG.Tweening;

using UnityEngine;

public partial class UIActSplashQuestMatchPanel : UIWindow {
    private PanelFlowArgs? _flow;
    private object _openParameter;
    private DG.Tweening.Tween _periodTimer;
    private UnityEngine.Transform Transform => RectTransform;
    public void SetFlow(PanelFlowArgs? flow) => _flow = flow;
    public override void OnOpen(params object[] args)
    {
        base.OnOpen(args);
        if (RectTransform == null) return;
        foreach (var argument in args)
        {
            if (argument is PanelFlowArgs flow) _flow = flow;
            else if (argument != null) _openParameter = argument;
        }
        AssembleUI();
        OnInit();
        RegisterEvents();
        OnShow();
    }
    public override void OnClose()
    {
        OnHide();
        UnRegisterEvents();
        OnDestroy();
        var flow = _flow;
        _flow = null;
        if (flow.HasValue && flow.Value.Token.IsValid)
            flow.Value.Executor?.TokenFinished(flow.Value.Token);
        base.OnClose();
    }

    protected override string AssetPath => "Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/UIActSplashQuestMatchPanel.prefab";

    private ActSplashQuest _activity;
    private int _periodId;

    private const float Duration = 1f;

    private const float PlayPortraitAnimDelay = 0.51666665f;

    private List<UIActSplashQuestAnimPortrait> _portraitViews = new List<UIActSplashQuestAnimPortrait>();

    private UIActSplashQuestAnimPortrait _portraitView;

    private Animator _rootAnimator;

    private Sequence _seq;

    private bool _isMatchAnimPlaying;

    private bool _hasSkippedOrFinished;

    private bool _canSkipMatchAnim;

    private void OnInit()
    {
        _activity = ImplementHub.Instance.Get<IActivitySystem>().GetActivity<ActSplashQuest>();

        _periodId = _activity.PeriodId;
        _rootAnimator = TransformUtils.Find<Animator>(Transform, "Root");

        var count = trans_PeopleRoot.childCount;
        for (int i = 0; i < count; i++)
        {
            var view = new UIActSplashQuestAnimPortrait(trans_PeopleRoot.GetChild(i));
            view.Transform.gameObject.SetActive(false);
            view.ShowRandom();
            _portraitViews.Add(view);
        }

        _portraitView = new UIActSplashQuestAnimPortrait(trans_Portrait);
        var playerInfo = ImplementHub.Instance.Get<Interface.PlayerInfo.IPlayerInfo>();
        _portraitView.Show(playerInfo.GetAvatarId(), playerInfo.GetFrameId(), 0);
    }

    private void OnShow()
    {
        RefreshUI();
        _periodTimer = DG.Tweening.DOVirtual.DelayedCall(1f, PollPeriod, false)
            .SetLoops(-1).SetLink(Transform.gameObject);
    }
    private void PollPeriod()
    {
        if (!_activity.IsCurrentPeriod(_periodId))
        {
            UIManager.Instance.Close(this, UIOperation.Auto);
            return;
        }
        _activity.CheckTimeOut();
        if (_activity.GetLeftTime() > 0)
        {
            return;
        }
        var flow = _flow;
        _flow = null;
        UIManager.Instance.Close(this, UIOperation.Auto);
        UIManager.Instance.Close<UIActSplashQuestMainPanel>(UIOperation.Auto);
        _activity.TryOpenRoutedPanel(UIOperation.Auto, flow);
    }

    private void OnHide()
    {
        _periodTimer?.Kill();
        _periodTimer = null;
    }

    private void OnDestroy()
    {
        foreach (var portraitView in _portraitViews)
        {
            portraitView.OnRelease();
        }
        _portraitViews.Clear();
        _portraitView?.OnRelease();
        _portraitView = null;
        _seq?.Kill();

    }

    private void RegisterEvents()
    {
        btn_FullPage.onClick.AddListener(OnClickFullPage);
    }

    private void UnRegisterEvents()
    {
        btn_FullPage.onClick.RemoveListener(OnClickFullPage);
    }

    private void OnClickFullPage()
    {
        if (_isMatchAnimPlaying && !_hasSkippedOrFinished)
        {
            if (_canSkipMatchAnim)
            {
                SkipToEndState();
            }

            return;
        }

        if (!_activity.IsCurrentPeriod(_periodId))
        {
            UIManager.Instance.Close<UIActSplashQuestMatchPanel>(UIOperation.Click);
            return;
        }
        _activity.CheckTimeOut();
        if (_activity.CurrentState != SplashQuestState.InRun)
        {
            _activity.TryOpenRoutedPanel(UIOperation.Auto, _flow);
            _flow = null;
            UIManager.Instance.Close<UIActSplashQuestMatchPanel>(UIOperation.Click);
            return;
        }
        _activity.OpenMainPanel(UIOperation.Click, _flow, fullPageClose: true);
        _flow = null;
        UIManager.Instance.Close<UIActSplashQuestMatchPanel>(UIOperation.Click);
    }

    private void OnPlayPortraitAnim()
    {
        if (_hasSkippedOrFinished)
        {
            return;
        }

        if (_seq != null)
        {
            _seq.Kill();
        }
        _seq = DOTween.Sequence();
        _seq.SetLink(Transform.gameObject);
        _seq.AppendCallback(() =>
        {
            ImplementHub.Instance.Get<Interface.Sound.IAudioSystem>()?.PlayAudio(Module.Audio.SoundConst.SFX_Temple_NumberRise, false, -1f);
        });
        _seq.Append(DOTween.To(() => 0, x => txt_TotalNum.SetText(x.ToString()), _activity.NumOfPeople(), Duration).SetEase(Ease.InQuart).SetLink(Transform.gameObject).OnComplete(() =>
        {
            trans_Effect_PenShe.gameObject.SetActive(true);
        }));
        for (int i = _portraitViews.Count - 1; i >= 0; i--)
        {
            var time = Mathf.Lerp(0f, Duration - 0.5f, (_portraitViews.Count - 1 - i) / (float)_portraitViews.Count);
            var  view = _portraitViews[i];
            _seq.InsertCallback(time, () =>
            {
                if (_hasSkippedOrFinished)
                {
                    return;
                }

                view.Transform.gameObject.SetActive(true);
                view.Appear();
            });
        }
        _seq.AppendInterval(0.5f)
            .AppendCallback(MarkMatchAnimFinished);
    }

    private void SkipToEndState()
    {
        if (_hasSkippedOrFinished)
        {
            return;
        }

        _hasSkippedOrFinished = true;
        _isMatchAnimPlaying = false;
        _seq?.Kill();
        _seq = null;

        CompleteRootAnimator();
        ApplyPortraitAnimEndState();
        ShowTapToContinue();
    }

    private void MarkMatchAnimFinished()
    {
        if (_hasSkippedOrFinished)
        {
            return;
        }

        _isMatchAnimPlaying = false;
        _hasSkippedOrFinished = true;
        _activity.RecordMatchPanelAnimSeen();
        _canSkipMatchAnim = true;
        ShowTapToContinue();
    }

    private void ApplyPortraitAnimEndState()
    {
        txt_TotalNum.SetText(_activity.NumOfPeople().ToString());
        trans_Effect_PenShe.gameObject.SetActive(true);

        for (int i = 0; i < _portraitViews.Count; i++)
        {
            var view = _portraitViews[i];
            view.Transform.gameObject.SetActive(true);
            view.CompleteAppear();
        }
    }

    private void CompleteRootAnimator()
    {
        if (_rootAnimator == null)
        {
            return;
        }

        var stateInfo = _rootAnimator.GetCurrentAnimatorStateInfo(0);
        if (stateInfo.shortNameHash == 0)
        {
            return;
        }

        _rootAnimator.Play(stateInfo.shortNameHash, 0, 1f);
        _rootAnimator.Update(0f);
    }

    private void ShowTapToContinue()
    {
        if (trans_TapToContinue != null)
        {
            trans_TapToContinue.gameObject.SetActive(true);
        }

        btn_FullPage.gameObject.SetActive(true);
        btn_FullPage.interactable = true;
    }

    private void RefreshUI()
    {
        _isMatchAnimPlaying = true;
        _hasSkippedOrFinished = false;
        _canSkipMatchAnim = _activity.CanSkipMatchPanelAnim();

        var title = trans_Title.GetComponentInChildren<UIText>(true);
        if (title != null)
        {
            title.SetText(LocaleManager.GetText("str_id_SplashQuest_Title") + $" {_activity.GetCurrentStageIndex() + 1}/{_activity.GetStageCount()}");
        }
        var description = trans_Description.GetComponentInChildren<UIText>(true);
        if (description != null)
        {
            description.SetText(_activity.GetTotalDiamondCount().ToString());
        }
        txt_TotalNum.SetText("0");
        trans_Effect_PenShe.gameObject.SetActive(false);

        if (trans_TapToContinue != null)
        {
            trans_TapToContinue.gameObject.SetActive(false);
        }

        btn_FullPage.gameObject.SetActive(true);
        btn_FullPage.interactable = _canSkipMatchAnim;

        for (int i = 0; i < _portraitViews.Count; i++)
        {
            _portraitViews[i].Transform.gameObject.SetActive(false);
        }

        SchedulePlayPortraitAnim();
    }

    private void SchedulePlayPortraitAnim()
    {
        _seq?.Kill();
        _seq = DOTween.Sequence();
        _seq.SetLink(Transform.gameObject);
        _seq.AppendInterval(PlayPortraitAnimDelay);
        _seq.AppendCallback(OnPlayPortraitAnim);
    }
}
