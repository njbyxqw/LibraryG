using BettaSDK;
using Interface.Item;
using TransformUtils = Module.Utils.UtilsTransform;
using System.Collections.Generic;
using Module.Activity;
using Betta.Framework;

using UnityEngine;

namespace Module.Activity.SplashQuest
{
    public class UIActSplashQuestRewardDisplayPanel
    {
    public Transform Transform { get; private set; }
    public RectTransform RectTransform => Transform as RectTransform;

        private const string PanelPath = "Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/UIActSplashQuestRewardDisplayPanel.prefab";
        private const string DiamondItemPath = "Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/SplashQuestRewardDisplayItemDiamond.prefab";
        private const string CommonItemPath = "Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/SplashQuestRewardDisplayItem.prefab";
        private const float SingleRewardItemScale = 1.4f;

        private readonly List<UIActSplashQuestRewardDisplayItem> _items = new List<UIActSplashQuestRewardDisplayItem>();
        private RectTransform _transRewards;

        private string AssetPath => PanelPath;

        public UIActSplashQuestRewardDisplayPanel(Transform parent)
        {
            Transform = ResourceHub.LoadGameObject(AssetPath).transform;
        Transform.SetParent(parent, false);
            FindComponents();
        }

        private void FindComponents()
        {
            _transRewards = TransformUtils.Find<RectTransform>(Transform, "Rewards");
        }

        public void Refresh(ActSplashQuest activity)
        {
            if (activity == null || _transRewards == null)
            {
                return;
            }

            ClearItems();

            var diamondCount = activity.GetTotalDiamondCount();
            if (diamondCount > 0)
            {
                var diamondItem = new UIActSplashQuestRewardDisplayItem(_transRewards, DiamondItemPath);
                diamondItem.SetDiamondCount(diamondCount);
                _items.Add(diamondItem);
            }

            var stageRewards = activity.GetCurrentStageRewardList();
            for (int i = 0; i < stageRewards.Length; i++)
            {
                var reward = stageRewards[i];
                if (reward == null || reward.Length < 2)
                {
                    continue;
                }

                var itemId = reward[0];
                if (itemId == (int)ITEM_ID.DIAMOND)
                {
                    continue;
                }

                var rewardItem = new UIActSplashQuestRewardDisplayItem(_transRewards, CommonItemPath);
                rewardItem.SetCommonReward(reward);
                _items.Add(rewardItem);
            }

            foreach (var item in _items)
            {
                item.Transform.localScale = Vector3.one * 1.3f;
            }

            ApplySingleItemScaleIfNeeded();
        }

        private void ApplySingleItemScaleIfNeeded()
        {
            if (_items.Count != 1)
            {
                return;
            }

            var rt = _items[0].RectTransform;
            if (rt != null)
            {
                rt.localScale = Vector3.one * SingleRewardItemScale;
            }
        }

        public void OnRelease()
        {
            ClearItems();
            if (Transform != null)
            {
                Object.Destroy(Transform.gameObject);
            }
        }

        private void ClearItems()
        {
            for (int i = 0; i < _items.Count; i++)
            {
                _items[i].OnRelease();
            }

            _items.Clear();
        }
    }
}
