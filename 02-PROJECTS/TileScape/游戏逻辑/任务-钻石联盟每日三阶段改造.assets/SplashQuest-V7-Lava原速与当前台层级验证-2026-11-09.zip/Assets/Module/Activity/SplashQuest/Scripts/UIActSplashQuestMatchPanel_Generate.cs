using UnityEngine.UI;
using Betta.Framework;
using UnityEngine;
using TMPro;
using TransformUtils = Module.Utils.UtilsTransform;

public partial class UIActSplashQuestMatchPanel
{
    private Button btn_FullPage;
    private RectTransform trans_Title;
    private RectTransform trans_Description;
    private RectTransform trans_TotalNum;
    private RectTransform trans_PeopleRoot;
    private RectTransform trans_TapToContinue;
    private RectTransform trans_Portrait;
    private UIText txt_TotalNum;
    private RectTransform trans_Effect_PenShe;
    private RectTransform trans_UI_A_Stare01;

    private void AssembleUI()
    {
        btn_FullPage = TransformUtils.Find<Button>(Transform ,"btn_FullPage");
        trans_Title = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_Title");
        trans_Description = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_Description");
        trans_TotalNum = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_TotalNum");
        trans_PeopleRoot = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_PeopleRoot");
        trans_TapToContinue = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_TapToContinue");
        trans_Portrait = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_Portrait");
        txt_TotalNum = TransformUtils.Find<UIText>(Transform ,"Root/trans_TotalNum/txt_TotalNum");
        trans_Effect_PenShe = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_TotalNum/trans_Effect_PenShe");
        trans_UI_A_Stare01 = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_Description/Effect_BG/trans_UI_A_Stare01");
    }

}
