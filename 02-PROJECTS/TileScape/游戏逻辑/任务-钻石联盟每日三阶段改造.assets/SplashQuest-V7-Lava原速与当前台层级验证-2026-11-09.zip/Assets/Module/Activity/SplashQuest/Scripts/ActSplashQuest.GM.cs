#if MODULE_GM
using Betta.Framework;
using BettaSDK;
using Interface.UI;
using Module.Activity.SplashQuest;
using Module.SplashQuest.Config;

namespace Module.Activity
{
    public partial class ActSplashQuest
    {
        internal void ResetFirstParticipationForGm()
        {
            if (!TryPrepareStageForGm(1, 0, out _))
            {
                return;
            }

            _profile.HelpLastPopTime = 0;
            _profile.MatchPanelAnimSeen = 0;
            _profile.HasPopCD = 0;
            _markForPopup = true;
            CompletePreparationForGm();
        }

        internal void SetStageProgressForGm(int stage, int wins)
        {
            if (!TryPrepareStageForGm(stage, wins, out var config))
            {
                return;
            }

            PrepareRunForGm(config, wins);
            if (wins == config.winNum)
            {
                ConsumeMainViewState();
                CompletePreparationForGm();
                OpenWinPanel(UIOperation.Click);
            }
            else
            {
                RecordShowData();
                CompletePreparationForGm();
                OpenMainPanel(UIOperation.Click);
            }
        }

        internal void OpenOpeningForGm(int stage)
        {
            if (!TryPrepareStageForGm(stage, 0, out _))
            {
                return;
            }

            CompletePreparationForGm();
            OpenOpeningPanel(UIOperation.Click);
        }

        internal void OpenMatchForGm(int stage)
        {
            if (!TryPrepareStageForGm(stage, 0, out var config))
            {
                return;
            }

            PrepareRunForGm(config, 0);
            _profile.MatchPanelAnimSeen = 0;
            SetMainViewState(SplashQuestMainViewState.EnterRun);
            CompletePreparationForGm();
            OpenMatchPanel(UIOperation.Click);
        }

        internal void OpenWinForGm(int stage)
        {
            if (!TryPrepareStageForGm(stage, 0, out var config))
            {
                return;
            }

            PrepareRunForGm(config, config.winNum);
            ConsumeMainViewState();
            CompletePreparationForGm();
            OpenWinPanel(UIOperation.Click);
        }

        private bool TryPrepareStageForGm(int stage, int wins, out Stage config)
        {
            config = null;
            if (_profile == null || !TryGetStages(out _, out var stages))
            {
                UtilsLog.W("[SplashQuest][GM] 活动配置尚未就绪，请先进入活动开放期。");
                return false;
            }
            if (stage < 1 || stage > stages.Length)
            {
                UtilsLog.W($"[SplashQuest][GM] 阶段范围为1～{stages.Length}，输入={stage}。");
                return false;
            }
            config = GetStageCfgByIndex(stage - 1);
            if (config == null || config.winNum <= 0 || wins < 0 || wins > config.winNum)
            {
                UtilsLog.W($"[SplashQuest][GM] 已通关数范围为0～{config?.winNum ?? 0}，输入={wins}。");
                return false;
            }
            if (GetLeftTime() == 0 || StartTime > UtilsTime.TimeSeconds || !AreDlcAssetsReady())
            {
                UtilsLog.W("[SplashQuest][GM] 当前活动期或资源未就绪，请先等待活动开启及资源加载。");
                return false;
            }

            ClosePanelsForGm();
            var userLayer = _profile.UserLayer;
            var cycleId = ConfigGroup?[ConfigId]?.cycleId ?? 0;
            var hadCycleCount = ActivityData.NumOfCycles.TryGetValue(cycleId, out var cycleCount);
            ResetForNewPeriod();
            ClearStageRunState();
            State = ActivityState.Open;
            Start();
            // GM重开当前期只恢复状态机，不重选本期分层或增加活动轮次。
            _profile.UserLayer = userLayer;
            if (hadCycleCount)
            {
                ActivityData.NumOfCycles[cycleId] = cycleCount;
            }
            else
            {
                ActivityData.NumOfCycles.Remove(cycleId);
            }
            _entryTipsPending = false;
            _entryTipsVersion++;
            _markForPopup = false;
            hasPendingPopup = false;
            _profile.HasPopCD = 1;
            _profile.DailyLoginPopupDayKey = UtilsTime.GetDays(UtilsTime.TimeSeconds);
            _profile.CurrentStageIndex = stage - 1;
            for (var i = 0; i < stage - 1; i++)
            {
                MarkPromotionStageClaimed(stages[i]);
            }
            return true;
        }

        private void PrepareRunForGm(Stage config, int wins)
        {
            SetState(SplashQuestState.InRun);
            SetMainViewState(SplashQuestMainViewState.None);
            InitRunPeopleRule(config, 0);
            _profile.RunSerial = 1;
            for (var i = 0; i < wins; i++)
            {
                ApplyPeopleRuleAndAdvance(false);
            }
            if (wins == config.winNum)
            {
                AfterSettle(true);
            }
        }

        private void CompletePreparationForGm()
        {
            PersistActivityState();
            DispatchRefreshActivityUi();
        }

        private static void ClosePanelsForGm()
        {
            UIManager.Instance.Close<UIActSplashQuestHelpPanel>(UIOperation.Auto);
            UIManager.Instance.Close<UIActSplashQuestMatchPanel>(UIOperation.Auto);
            UIManager.Instance.Close<UIActSplashQuestWinPanel>(UIOperation.Auto);
            UIManager.Instance.Close<UIActSplashQuestMainPanel>(UIOperation.Auto);
            UIManager.Instance.Close<UIActSplashQuestTipsPanel>(UIOperation.Auto);
        }
    }
}
#endif
