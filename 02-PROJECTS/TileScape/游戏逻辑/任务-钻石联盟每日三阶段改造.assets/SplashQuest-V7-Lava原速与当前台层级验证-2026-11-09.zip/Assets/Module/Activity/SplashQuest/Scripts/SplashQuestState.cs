namespace Module.Activity.SplashQuest
{
    /// <summary>
    /// 与 <see cref="BettaSDK.Profile.SplashQuestData.State"/> 持久化整型一致。
    /// 活动未上线前可调整取值；**上线后改枚举或数值须与策划/程序确认并做好迁移**。
    /// </summary>
    public enum SplashQuestState
    {
        Ready = 0,
        InRun = 1,
        Timeout = 2,
        Finished = 3,
        Init = 4,
    }
}
