using Module.SplashQuest.Config;
using BettaSDK;

using System.Collections.Generic;
using Module.Activity.SplashQuest;
using UnityEngine;

namespace Module.Activity
{
    public partial class ActSplashQuest
    {
        public Main GetMainConfig()
        {
            return GetMainCfg();
        }

        private void AdvanceStage()
        {
            if (!TryGetStages(out _, out var stages))
            {
                return;
            }

            var nextIndex = _profile.CurrentStageIndex + 1;
            if (nextIndex >= stages.Length)
            {
                _profile.CurrentStageIndex = stages.Length - 1;
                return;
            }
            _profile.CurrentStageIndex = nextIndex;
        }

        private int GetCurrentStageId()
        {
            if (!TryGetStages(out _, out var stages))
            {
                return 0;
            }

            var idx = Mathf.Clamp(_profile.CurrentStageIndex, 0, stages.Length - 1);
            return stages[idx];
        }

        private Stage GetCurrentStageCfg()
        {
            var stageId = GetCurrentStageId();
            if (stageId == 0)
            {
                return null;
            }
            return ConfigManager.Instance.GetStage(stageId);
        }

        private Stage GetStageCfgByIndex(int stageIndex)
        {
            if (!TryGetStages(out _, out var stages))
            {
                return null;
            }

            if (stageIndex < 0 || stageIndex >= stages.Length)
            {
                return null;
            }

            var stageId = stages[stageIndex];
            if (stageId == 0)
            {
                return null;
            }

            return ConfigManager.Instance.GetStage(stageId);
        }

        private Main GetMainCfg()
        {
            if (ConfigID <= 0)
            {
                return null;
            }

            var profileUserLayer = _profile != null ? _profile.UserLayer : 0;

            // main 表支持按 userLayerType/userLayer 做分层筛选；活动侧使用“本期开始时落盘的分层快照”，
            // 避免 UI/逻辑在同一局内出现分层漂移导致取到不同 main。
            var mains = ConfigManager.Instance.GetMainList();
            if (mains == null || mains.Count == 0)
            {
                return null;
            }

            var layers = ImplementHub.Instance.Get<Interface.UserLayer.IUserLayerSystem>();
            for (var i = 0; i < mains.Count; i++)
            {
                var row = mains[i];
                if (row == null || row.id != RuleId) continue;
                if (string.IsNullOrEmpty(row.userLayerType)) return row;
                var layer = row.userLayerType == "SplashQuest" ? profileUserLayer : layers?.GetLayer(row.userLayerType) ?? 0;
                if (row.userLayer == layer) return row;
            }

            return null;
        }

        private void ValidateConfigs()
        {
            var mainCfg = GetMainCfg();
            if (mainCfg == null)
            {
                return;
            }

            if (mainCfg.stages == null || mainCfg.stages.Length == 0)
            {
                UtilsLog.E($"[ActSplashQuest] Main.stages empty. ruleId={RuleId}");
                return;
            }

            for (int i = 0; i < mainCfg.stages.Length; i++)
            {
                var stageId = mainCfg.stages[i];
                var stageCfg = ConfigManager.Instance.GetStage(stageId);
                if (stageCfg == null)
                {
                    UtilsLog.E($"[ActSplashQuest] Stage not found. stageId={stageId}");
                    continue;
                }

                if (stageCfg.winNum <= 0)
                {
                    UtilsLog.E($"[ActSplashQuest] Stage.winNum invalid. stageId={stageId}, winNum={stageCfg.winNum}");
                }
            }
        }

        private void TryMarkLoginForcePopup()
        {
            if (_waitForPeriodOpeningLevel || !IsActive() || CurrentState == SplashQuestState.Finished ||
                CurrentState == SplashQuestState.Timeout)
                return;
            var mainCfg = GetMainCfg();
            if (mainCfg == null || mainCfg.loginForcePopup == 0)
            {
                return;
            }

            var dayKey = UtilsTime.GetDays(UtilsTime.TimeSeconds);
            var last = _profile.DailyLoginPopupDayKey;
            if (last == dayKey)
            {
                return;
            }

            _profile.DailyLoginPopupDayKey = dayKey;
            _markForPopup = true;
        }

        private void MarkPromotionStageClaimed(int stageId)
        {
            if (IsPromotionStageClaimed(stageId))
            {
                return;
            }
            _profile.PromotionStageClaimedIds.Add(stageId);
        }

        private bool IsPromotionStageClaimed(int stageId)
        {
            if (_profile.PromotionStageClaimedIds == null)
            {
                return false;
            }
            for (int i = 0; i < _profile.PromotionStageClaimedIds.Count; i++)
            {
                if (_profile.PromotionStageClaimedIds[i] == stageId)
                {
                    return true;
                }
            }
            return false;
        }

        private bool IsAllRewardsClaimed()
        {
            if (!TryGetStages(out _, out var stages))
            {
                return false;
            }
            for (var i = 0; i < stages.Length; i++)
            {
                if (!IsPromotionStageClaimed(stages[i]))
                {
                    return false;
                }
            }
            return true;
        }
    }
}
