using Module.Activity.Flow;
using System.Collections.Generic;
using Interface.Activity;
using Module.Activity.Message;
using Module.Activity.SplashQuest;
using Module.SplashQuest.Config;
using Betta.Framework;
using BettaSDK;
using BettaSDK.Profile;
using UnityEngine;

namespace Module.Activity
{
    /// <summary>每日三阶段连续通关活动，阶段奖励按完成快照单次结算。</summary>
    public partial class ActSplashQuest : ActivityBase, IActivityEntry, Interface.Game.IGameStateUpdateReceiver, IActivityExitNodeProvider
    {
        public const string ActivityId = "ActSplashQuest";
        private Interface.UIEntry.IEntryCreateProxy _entryProxy;
        private readonly FlowItemRegistrar<ActSplashQuestPopupFlowItem> _popupFlow;
        private readonly FlowItemRegistrar<ActSplashQuestPopupFlowItem> _nextStagePopupFlow;
        private bool _profileReady;
        public ActSplashQuest(string activityName) : base(activityName)
        {
            _popupFlow = new FlowItemRegistrar<ActSplashQuestPopupFlowItem>(() => new ActSplashQuestPopupFlowItem(this));
            _nextStagePopupFlow = new FlowItemRegistrar<ActSplashQuestPopupFlowItem>(() => new ActSplashQuestPopupFlowItem(this, true));
        }
        public SplashQuestData Profile => _profile;
        public string Name => ActivityName;
        public int ConfigID => ConfigId;
        public int RuleId => ConfigId;
        public int OpenLevel => ConfigGroup?[ConfigId]?.openLevel ?? 0;
        public ActivityState State
        {
            get => ActivityData == null ? ActivityState.None : (ActivityState)ActivityData.State;
            private set => ActivityData.State = (int)value;
        }
        private bool IsWaitingForClaim => State == ActivityState.Open &&
            ((EndTime > 0 && UtilsTime.TimeSeconds >= EndTime) || !CanActive());
        public ulong GetLeftTime() => EndTime > UtilsTime.TimeSeconds ? EndTime - UtilsTime.TimeSeconds : 0;
        public SplashQuestMainViewState MainViewState => MainViewStateView;
        public SplashQuestStageViewState StageViewState => StageViewStateView;

        public void Finish()
        {
            if (_profile == null)
            {
                return;
            }
            if (HasPendingWinRewardClaim() || HasPendingWinPresentation())
            {
                return;
            }
            if (State == ActivityState.Finished)
            {
                return;
            }

            // 超时属于失败口径，留存给下一次期望人数计算。
            var prevState = CurrentState;
            if (prevState == SplashQuestState.Timeout && !IsAllRewardsClaimed())
            {
                SaveCurrentStageCarryLastIfPass(0);
                var stageCfg = GetCurrentStageCfg();
                if (stageCfg != null)
                {
                    UtilsLog.L($"[SplashQuest][Flow][FinishTimeout] stageId={stageCfg.id}, winNum={stageCfg.winNum}, forceLastIfPass=0");
                }
            }
            SetState(SplashQuestState.Finished);

            SetMainViewState(SplashQuestMainViewState.None);
            SetStageViewState(SplashQuestStageViewState.NoChange);
            SetFailProgressBeforeSettleSnapshot(0);
            _markForPopup = false;
            _profile.PendingFlags = 0;
            _profile.LevelsSinceLastSettle = 0;
            Update(0f, PendingChangedTiming);
            PersistActivityState();
            DispatchRefreshActivityUi();
        }

        private SplashQuestData _profile;
        private bool _markForPopup;
        public new SplashQuestState CurrentState
        {
            get => (SplashQuestState)_profile.State;
            private set => _profile.State = (int)value;
        }

        public override ActBaseData ActivityData => _profile.ActivityData;

        private void SetFailProgressBeforeSettleSnapshot(int progress)
        {
            if (_profile == null)
            {
                return;
            }

            _profile.FailProgressBeforeSettleSnapshot = Mathf.Max(0, progress);
        }

        private int GetFailProgressBeforeSettleSnapshot()
        {
            return _profile != null ? Mathf.Max(0, _profile.FailProgressBeforeSettleSnapshot) : 0;
        }

        public void EndStagePresentationSnapshot()
        {
            SetStageViewState(SplashQuestStageViewState.NoChange);
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="status">1.参加活动； 2.过tile关卡；3.成功；4.失败（正常关卡失败）；5：内置CD时间结束失败；</param>
        internal int GetTrackingCycleCount()
        {
            var config = ConfigGroup?[ConfigId];
            return config == null ? 0 : ActivityData.NumOfCycles.GetValueOrDefault(config.cycleId, 0);
        }

        internal int GetTrackingRound()
        {
            var config = ConfigGroup?[ConfigId];
            if (config == null)
            {
                return 0;
            }

            var start = Module.Utils.UtilsTimeString.TimeStringToStamp(config.timeStart);
            var end = Module.Utils.UtilsTimeString.TimeStringToStamp(config.timeEnd);
            if (end <= start)
            {
                return 0;
            }

            var now = UtilsTime.TimeSeconds;
            var cycleLength = end - start + (ulong)Mathf.Max(0, config.coolingTime);
            return now < start ? 1 : (int)System.Math.Min((now - start) / cycleLength + 1, int.MaxValue);
        }

        private void TrackEvent(int status)
        {
            ImplementHub.Instance.Get<Interface.Logger.ILogger>()?.TrackEvent("act_splashquest",new Dictionary<string, object>()
            {
                ["splashquest_id"] = ConfigID,
                ["round_id"] = GetTrackingCycleCount(),
                ["splashquest_round_id"] = GetTrackingRound(),
                ["splashquest_status"] = status,
                ["splashquest_stage"] = CurrentLevel() + 1,
                ["splashquest_tier"] = GetCurrentStageIndex() + 1,
            });
        }

        public string GetStageLevelString()
        {
            if (!IsActive() && !IsWaitingForClaim)
            {
                return "-1";
            }

            var levelOffset = MainViewStateView == SplashQuestMainViewState.SettleSuccess || StageViewStateView == SplashQuestStageViewState.Success ? -1 : 0;
            var level = Mathf.Clamp(CurrentLevel() + 1 + levelOffset, 1, MaxLevel() + 1);

            var result = "" + (GetCurrentStageIndex() + 1) + "_" + level;

            if (IsInFailCooldown() || CurrentState != SplashQuestState.InRun)
            {
                result = "-1";
            }

            return result;
        }
    }
}
