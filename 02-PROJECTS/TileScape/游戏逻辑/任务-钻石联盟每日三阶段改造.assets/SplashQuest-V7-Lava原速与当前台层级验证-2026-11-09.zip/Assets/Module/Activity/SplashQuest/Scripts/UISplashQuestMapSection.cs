using Betta.Framework;
using BettaSDK;
using UnityEngine;
using DG.Tweening;

namespace Module.Activity.SplashQuest
{
    public class UISplashQuestMapSection
    {
        private readonly ActSplashQuest _activity;
        private readonly int _level;
        private readonly int _maxLevel;
        private readonly UIButtonBetta _button;
        private readonly RectTransform _background;
        private readonly CanvasGroup _canvasGroup;
        private readonly Vector3 _originalPosition;
        private readonly Quaternion _originalRotation;
        private Tween _sink;

        public bool CanSink => IsMiddle;
        public Transform SinkParent => _background;
        public float SinkDuration => SplashQuestMotion.SINK_DURATION;

        public RectTransform ItemRoot { get; }

        private bool IsMiddle => _level > 0 && _level < _maxLevel;

        public UISplashQuestMapSection(Transform section, ActSplashQuest activity, int level, int maxLevel)
        {
            _activity = activity;
            _level = level;
            _maxLevel = maxLevel;
            var root = section.Find("Root");
            ItemRoot = root.Find("Background/ItemRoot").GetComponent<RectTransform>();
            _button = root.Find("Background/Button").GetComponent<UIButtonBetta>();
            _button.onClick.AddListener(OnClickButton);
            _background = (RectTransform)root.Find("Background");
            _originalPosition = _background.localPosition;
            _originalRotation = _background.localRotation;
            _canvasGroup = _background.GetComponent<CanvasGroup>();
            if (_canvasGroup == null)
            {
                _canvasGroup = _background.gameObject.AddComponent<CanvasGroup>();
            }
            _canvasGroup.alpha = 1f;
            _canvasGroup.blocksRaycasts = true;
            if (IsMiddle)
            {
                var animator = root.GetComponent<Animator>();
                if (animator != null)
                {
                    animator.enabled = false;
                }
                _background.gameObject.SetActive(true);
            }
        }

        private void OnClickButton()
        {
            if (_level == _maxLevel)
            {
                if (_activity.GetRawTotalDiamondCount() > 0)
                {
                    ImplementHub.Instance.Get<Interface.Reward.IRewardSystem>()?.TryShowTips(new Interface.Reward.RewardTipsRequest
                    {
                        Text = LocaleManager.GetText("str_id_SplashQuest_GrandPrizeTips"),
                        AnchorUIPoint = _button.transform.position,
                        YOffset = 230,
                        PreferAbove = true,
                        SourceKey = "SplashQuest.Map." + _level,
                    }, out _);
                }
                else
                {
                    ImplementHub.Instance.Get<Interface.Reward.IRewardSystem>()?.TryShowTips(new Interface.Reward.RewardTipsRequest
                    {
                        Text = LocaleManager.GetText("str_id_SplashQuest_GrandPrizeTips2"),
                        AnchorUIPoint = _button.transform.position,
                        YOffset = 230,
                        PreferAbove = true,
                        SourceKey = "SplashQuest.Map." + _level,
                    }, out _);
                }
            }
            else if (_level == (_activity.MainViewStateView == SplashQuestMainViewState.SettleFail
                         ? _activity.FailProgressBeforeSettle()
                         : _activity.CurrentLevel()))
            {
                ImplementHub.Instance.Get<Interface.Reward.IRewardSystem>()?.TryShowTips(new Interface.Reward.RewardTipsRequest
                    {
                        Text = string.Format(LocaleManager.GetText("str_id_SplashQuest_PlayerTips"), _activity.LeftNumOfPeople()),
                        AnchorUIPoint = _button.transform.position,
                        YOffset = 100,
                        PreferAbove = true,
                        SourceKey = "SplashQuest.Map." + _level,
                    }, out _);
            }
            else if (_level != 0)
            {
                ImplementHub.Instance.Get<Interface.Reward.IRewardSystem>()?.TryShowTips(new Interface.Reward.RewardTipsRequest
                    {
                        Text = LocaleManager.GetText("str_id_SplashQuest_PillarTips"),
                        AnchorUIPoint = _button.transform.position,
                        YOffset = 0,
                        PreferAbove = true,
                        SourceKey = "SplashQuest.Map." + _level,
                    }, out _);
            }
        }

        public void OnRelease()
        {
            _button.onClick.RemoveListener(OnClickButton);
            _sink?.Kill();
            _background.localPosition = _originalPosition;
            _background.localRotation = _originalRotation;
            _canvasGroup.alpha = 1f;
            _canvasGroup.blocksRaycasts = true;
        }

        public void Hide()
        {
            if (!IsMiddle)
            {
                return;
            }
            _sink?.Kill();
            ApplySink(SinkDuration);
            _canvasGroup.alpha = 0f;
            _canvasGroup.blocksRaycasts = false;
        }

        public Tween PlaySink()
        {
            _sink?.Kill();
            _canvasGroup.blocksRaycasts = false;
            _sink = DOVirtual.Float(0f, SinkDuration, SinkDuration, ApplySink)
                .SetEase(Ease.Linear).SetLink(_background.gameObject)
                .OnComplete(() => _canvasGroup.alpha = 0f);
            return _sink;
        }

        private void ApplySink(float time)
        {
            var sample = SplashQuestMotion.SampleSink(time);
            _background.localPosition = _originalPosition + new Vector3(sample.x, sample.y, 0f) * 100f;
            _background.localRotation = _originalRotation;
            _canvasGroup.alpha = sample.z;
        }
    }
}
