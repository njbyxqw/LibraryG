using Betta.Framework;
using BettaSDK;
using Interface.Item;
using Interface.ItemGraphic;
using Interface.Reward;
using Module.Utils;
using UnityEngine;

public sealed class UIActSplashQuestRewardDisplayItem
{
    private const float LimitedRewardItemSize = 80f;
    private readonly Transform _transform;
    private readonly Transform _iconRoot;
    private readonly UIText _txtCount;
    private IItemRewardCell _limitedRewardItem;

    public Transform Transform => _transform;
    public RectTransform RectTransform => _transform as RectTransform;

    public UIActSplashQuestRewardDisplayItem(Transform parent, string assetPath)
    {
        var instance = ResourceHub.LoadGameObject(assetPath);
        if (instance == null) return;
        _transform = instance.transform;
        _transform.SetParent(parent, false);
        _iconRoot = UtilsTransform.Find<Transform>(_transform, "Icon");
        _txtCount = UtilsTransform.Find<UIText>(_transform, "Count");
    }

    public void SetDiamondCount(int count)
    {
        _txtCount?.SetText("x" + count);
    }

    public void SetCommonReward(int itemId, int count)
    {
        SetCommonReward(itemId, count, ItemGraphicVariant.Normal, ItemRewardDisplayValueType.Count);
    }

    private void SetCommonReward(int itemId, int count, ItemGraphicVariant variant, ItemRewardDisplayValueType valueType)
    {
        ReleaseLimitedRewardItem();
        if (_iconRoot != null)
        {
            DestroyIconChildren();
            var image = _iconRoot.GetComponent<UnityEngine.UI.Image>();
            if (image != null) image.enabled = false;
            ImplementHub.Instance.Get<IItemGraphicSystem>()?.CreateForUI(new ItemGraphicRequestGame(itemId, variant), _iconRoot, 80);
        }

        if (_txtCount == null) return;
        _txtCount.gameObject.SetActive(true);
        if (valueType == ItemRewardDisplayValueType.Duration)
        {
            var sec = Mathf.Max(0, count);
            _txtCount.SetText(sec >= 3600 ? Mathf.CeilToInt(sec / 3600) + "h" : Mathf.CeilToInt(sec / 60) + "min");
            return;
        }
        _txtCount.SetText("x" + count);
    }

    public void SetCommonReward(int[] reward)
    {
        if (reward == null || reward.Length < 2) return;
        var system = ImplementHub.Instance.Get<IRewardSystem>();
        if (system == null || !system.TryResolve(reward[0], reward[1], out var resolved)) return;
        if (resolved.DurationSeconds > 0 && resolved.DisplayValueType == ItemRewardDisplayValueType.Count)
        {
            SetLimitedReward(resolved);
            return;
        }
        SetCommonReward(resolved.ItemId, (int)System.Math.Min(resolved.DisplayValue, int.MaxValue), resolved.GraphicVariant, resolved.DisplayValueType);
    }

    private void SetLimitedReward(ResolvedRewardInfo reward)
    {
        ReleaseLimitedRewardItem();
        if (_iconRoot == null) return;
        DestroyIconChildren();
        _limitedRewardItem = ImplementHub.Instance.Get<IItemRewardCellFactory>()?.Create(
            _iconRoot, new ItemRewardCellOptions(LimitedRewardItemSize, LimitedRewardItemSize, ItemRewardCellStyle.Plain));
        _limitedRewardItem?.Bind(new ItemRewardCellData(reward.ItemId, reward.Count, false,
            reward.GraphicVariant, reward.DisplayValueType, reward.DurationSeconds));
        if (_txtCount != null) _txtCount.gameObject.SetActive(false);
    }

    public void OnRelease()
    {
        ReleaseLimitedRewardItem();
        DestroyIconChildren();
        if (_transform != null) Object.Destroy(_transform.gameObject);
    }

    private void ReleaseLimitedRewardItem()
    {
        _limitedRewardItem?.Release();
        _limitedRewardItem = null;
    }

    private void DestroyIconChildren()
    {
        if (_iconRoot == null) return;
        for (int i = _iconRoot.childCount - 1; i >= 0; i--) Object.Destroy(_iconRoot.GetChild(i).gameObject);
    }
}
