using Interface.UI;
using Interface.Flow;
using Module.Activity.Flow;
using Interface.Activity;
using Module.Activity.SplashQuest;
using Betta.Framework;
using BettaSDK;
using System.Collections;

namespace Module.Activity
{
    public partial class ActSplashQuest
    {
        private IEnumerator _periodOpeningContinuation;
        private UtilsCoroutine _periodOpeningContinuationHost;

        internal bool HasPendingNextStageOpening => _profile != null &&
            (_profile.PendingFlags & PendingFlagNextStageOpening) != 0 &&
            GetCurrentStageIndex() > 0 && CanJoinCurrentStage();

        internal bool HasPendingAutomaticOpening => HasPendingNextStageOpening ||
            (_pendingPeriodOpening && !_waitForPeriodOpeningLevel && CanJoinCurrentStage());

        private void ClearPeriodOpeningInvitation()
        {
            CancelPeriodOpeningContinuation();
            _periodClosingScheduler = null;
            _pendingPeriodOpening = false;
            _waitForPeriodOpeningLevel = false;
            _periodOpeningLevelStarted = false;
        }

        private void AdvanceFinishedPeriod()
        {
            if (State == ActivityState.Finished && GetLeftTime() == 0)
            {
                Update(0f, PendingChangedTiming);
            }
            if (State == ActivityState.Closed)
            {
                Update(0f, PendingChangedTiming);
            }
        }

        internal void HandleAfterTimeoutPresentation(PanelFlowArgs? token, int periodId)
        {
            if (IsCurrentPeriod(periodId))
            {
                ImplementHub.Instance.TryGet(out _periodClosingScheduler);
                CompleteTimeoutPresentation(periodId);
                AdvanceFinishedPeriod();
            }
            ContinueHomePopupFlow(token);
        }

        internal void HandleAfterOpeningExpired(PanelFlowArgs? token, int periodId, IFlowScheduler homeScheduler)
        {
            if (IsCurrentPeriod(periodId) && CanPresent() && homeScheduler != null &&
                ImplementHub.Instance.TryGet(out IFlowScheduler scheduler) &&
                ReferenceEquals(scheduler, homeScheduler))
            {
                CheckTimeOut();
                if (TryOpenRoutedPanel(UIOperation.Auto, token))
                {
                    return;
                }
            }
            if (token.HasValue && token.Value.Token.IsValid)
            {
                token.Value.Executor?.TokenFinished(token.Value.Token);
            }
        }

        private void ContinueHomePopupFlow(PanelFlowArgs? token)
        {
            if (token.HasValue && token.Value.Token.IsValid)
            {
                token.Value.Executor?.TokenFinished(token.Value.Token);
                return;
            }

            if (!HasPendingAutomaticOpening || !ImplementHub.Instance.TryGet(out IFlowScheduler scheduler) ||
                !ImplementHub.Instance.TryGet(out IFlowExecutor executor))
            {
                return;
            }
            if (executor.State == FlowExecutorState.Idle)
            {
                CancelPeriodOpeningContinuation();
                _periodClosingScheduler = null;
                executor.Invoke(new FlowContext("Home"));
            }
            else if (executor.State == FlowExecutorState.Running && _pendingPeriodOpening &&
                ReferenceEquals(scheduler, _periodClosingScheduler) && _periodOpeningContinuation == null)
            {
                _periodOpeningContinuation = WaitForPeriodOpeningFlow(scheduler, executor, PeriodId);
                _periodOpeningContinuationHost = UtilsCoroutine.Instance;
                _periodOpeningContinuationHost.StartCoroutine(_periodOpeningContinuation);
            }
        }

        internal IEnumerator WaitForPeriodOpeningFlow(IFlowScheduler scheduler, IFlowExecutor executor, int periodId)
        {
            while (IsCurrentPeriod(periodId) && _pendingPeriodOpening && HasPendingAutomaticOpening &&
                ReferenceEquals(scheduler, _periodClosingScheduler) &&
                ImplementHub.Instance.TryGet(out IFlowScheduler currentScheduler) &&
                ReferenceEquals(scheduler, currentScheduler) &&
                ImplementHub.Instance.TryGet(out IFlowExecutor currentExecutor) &&
                ReferenceEquals(executor, currentExecutor))
            {
                if (executor.State == FlowExecutorState.Idle)
                {
                    _periodOpeningContinuation = null;
                    _periodOpeningContinuationHost = null;
                    _periodClosingScheduler = null;
                    executor.Invoke(new FlowContext("Home"));
                    yield break;
                }
                if (executor.State != FlowExecutorState.Running)
                {
                    break;
                }
                yield return null;
            }
            _periodOpeningContinuation = null;
            _periodOpeningContinuationHost = null;
            _periodClosingScheduler = null;
        }

        private void CancelPeriodOpeningContinuation()
        {
            if (_periodOpeningContinuationHost != null && _periodOpeningContinuation != null)
            {
                _periodOpeningContinuationHost.StopCoroutine(_periodOpeningContinuation);
            }
            _periodOpeningContinuation = null;
            _periodOpeningContinuationHost = null;
        }

        public bool TryOpenRoutedPanel(UIOperation operation, PanelFlowArgs? token = null)
        {
            if (State == ActivityState.Preview)
            {
                return OpenTipsPanel(operation, SplashQuestTipsViewState.Preview, token) != null;
            }

            if (MainViewStateView == SplashQuestMainViewState.SettleSuccess ||
                MainViewStateView == SplashQuestMainViewState.SettleFail)
            {
                return OpenMainPanel(operation, token) != null;
            }

            if (HasPendingWinRewardClaim() || HasPendingWinPresentation())
            {
                return OpenWinPanel(operation, new UIActSplashQuestWinPanelParameter(), token) != null;
            }

            if (HasPendingTimeoutPopup() && CurrentState == SplashQuestState.Timeout)
            {
                return OpenTipsPanel(operation, SplashQuestTipsViewState.Timeout, token) != null;
            }

            if (IsTerminalStageState())
            {
                Finish();
                return false;
            }

            if (IsActive())
            {
                if (CurrentState == SplashQuestState.InRun)
                {
                    return OpenMainPanel(operation, token) != null;
                }
                return OpenOpeningPanel(operation, token) != null;
            }

            return false;
        }

        public UIActSplashQuestMatchPanel OpenMatchPanel(UIOperation operation, PanelFlowArgs? token = null)
        {
            var panel = UIManager.Instance.Open<UIActSplashQuestMatchPanel>(operation, "SplashQuest", token);
            return panel;
        }

        public UIActSplashQuestMainPanel OpenMainPanel(UIOperation operation, PanelFlowArgs? token = null, bool fullPageClose = false, bool showOpeningPopup = false)
        {
            var param = new UIActSplashQuestMainPanelParameter
            {
                FullPageClose = fullPageClose,
                ShowOpeningPopup = showOpeningPopup,
            };
            var panel = UIManager.Instance.Open<UIActSplashQuestMainPanel>(operation, "SplashQuest", param, token);
            return panel;
        }

        public UIActSplashQuestTipsPanel OpenTipsPanel(UIOperation operation, SplashQuestTipsViewState viewState, PanelFlowArgs? token = null)
        {
            var panel = UIManager.Instance.Open<UIActSplashQuestTipsPanel>(operation, "SplashQuest",
                new UIActSplashQuestTipsPanelParameter
                {
                    ViewState = viewState,
                }, token);
            return panel;
        }

        public UIActSplashQuestWinPanel OpenWinPanel(UIOperation operation, UIActSplashQuestWinPanelParameter parameter = null, PanelFlowArgs? token = null)
        {
            if (HasPendingWinRewardClaim() || HasPendingWinPresentation())
            {
                EnsureWinRewardSnapshot();
            }
            var panel = UIManager.Instance.Open<UIActSplashQuestWinPanel>(operation, "SplashQuest", parameter ?? new UIActSplashQuestWinPanelParameter(), token);
            return panel;
        }

        public UIActSplashQuestHelpPanel OpenHelpPanel(UIOperation operation, PanelFlowArgs? token = null, bool startMatchOnClose = false)
        {
            var panel = UIManager.Instance.Open<UIActSplashQuestHelpPanel>(operation, "SplashQuest",
                new UIActSplashQuestHelpPanelParameter { PeriodId = PeriodId, StartMatchOnClose = startMatchOnClose }, token);
            return panel;
        }

        public void HandleAfterWinClaim(PanelFlowArgs? token = null, int periodId = -1, int stageId = 0)
        {
            if ((periodId >= 0 && !IsCurrentPeriod(periodId)) ||
                (stageId > 0 && stageId != _profile.PendingWinStageId))
            {
                if (token.HasValue && token.Value.Token.IsValid)
                {
                    token.Value.Executor?.TokenFinished(token.Value.Token);
                }
                return;
            }
            if (!HasPendingWinPresentation())
            {
                if (token.HasValue && token.Value.Token.IsValid)
                {
                    token.Value.Executor?.TokenFinished(token.Value.Token);
                }
                return;
            }
            CheckTimeOut();
            ApplyStageProgressAfterWinClaim();
            if (CurrentState == SplashQuestState.Finished)
            {
                ImplementHub.Instance.TryGet(out _periodClosingScheduler);
                AdvanceFinishedPeriod();
                ContinueHomePopupFlow(token);
                return;
            }
            if (CurrentState == SplashQuestState.Timeout)
            {
                OpenTipsPanel(UIOperation.Auto, SplashQuestTipsViewState.Timeout, token);
                return;
            }
            ContinueHomePopupFlow(token);
        }
        public UIActSplashQuestTipsPanel OpenOpeningPanel(UIOperation operation, PanelFlowArgs? token = null)
        {
            CheckTimeOut();
            if (!CanJoinCurrentStage())
            {
                return null;
            }
            var panel = OpenTipsPanel(operation, SplashQuestTipsViewState.Generic, token);
            if (panel != null)
            {
                ClearPeriodOpeningInvitation();
                _markForPopup = false;
                hasPendingPopup = false;
                _profile.HasPopCD = 1;
                _profile.LevelsSinceLastSettle = 0;
                if ((_profile.PendingFlags & PendingFlagNextStageOpening) != 0)
                {
                    _profile.PendingFlags &= ~PendingFlagNextStageOpening;
                    PersistActivityState();
                }
            }
            return panel;
        }

        public bool CanJoinCurrentStage()
        {
            return CanPresent() && GetLeftTime() > 0 && CurrentState == SplashQuestState.Ready &&
                !HasPendingWinRewardClaim() && !HasPendingWinPresentation() && !IsTerminalStageState() &&
                GetCurrentStageCfg() != null;
        }

        public void Participate(PanelFlowArgs? token = null)
        {
            CheckTimeOut();
            if (!CanJoinCurrentStage())
            {
                if (!TryOpenRoutedPanel(UIOperation.Auto, token) && token.HasValue && token.Value.Token.IsValid)
                {
                    token.Value.Executor?.TokenFinished(token.Value.Token);
                }
                return;
            }
            StartMatching(PeriodId, token);
        }

        public void StartMatching(int periodId, PanelFlowArgs? token = null)
        {
            if (!IsCurrentPeriod(periodId))
            {
                if (token.HasValue && token.Value.Token.IsValid)
                {
                    token.Value.Executor?.TokenFinished(token.Value.Token);
                }
                return;
            }
            CheckTimeOut();
            if (!CanJoinCurrentStage())
            {
                if (!TryOpenRoutedPanel(UIOperation.Auto, token) && token.HasValue && token.Value.Token.IsValid)
                {
                    token.Value.Executor?.TokenFinished(token.Value.Token);
                }
                return;
            }
            StartRun();
            if (CurrentState == SplashQuestState.InRun)
            {
                UIManager.Instance.Close<UIActSplashQuestMainPanel>(UIOperation.Auto);
                OpenMatchPanel(UIOperation.Click, token);
            }
            else
            {
                if (!TryOpenRoutedPanel(UIOperation.Auto, token) && token.HasValue && token.Value.Token.IsValid)
                {
                    token.Value.Executor?.TokenFinished(token.Value.Token);
                }
            }
        }
    }
}
