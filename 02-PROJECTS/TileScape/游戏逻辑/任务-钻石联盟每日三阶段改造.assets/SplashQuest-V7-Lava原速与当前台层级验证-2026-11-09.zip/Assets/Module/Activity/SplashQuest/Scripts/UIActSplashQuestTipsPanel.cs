using DG.Tweening;
using BettaSDK;
using Interface.UI;
using Interface.Activity;
using Interface.Flow;
using Module.Activity.Flow;
using Betta.Framework;
using Module.Activity;
using Module.Activity.SplashQuest;

public partial class UIActSplashQuestTipsPanel : UIWindow {
    private PanelFlowArgs? _flow;
    private object _openParameter;
    private DG.Tweening.Tween _periodTimer;
    private UnityEngine.Transform Transform => RectTransform;
    public void SetFlow(PanelFlowArgs? flow) => _flow = flow;
    public override void OnOpen(params object[] args)
    {
        base.OnOpen(args);
        if (RectTransform == null) return;
        foreach (var argument in args)
        {
            if (argument is PanelFlowArgs flow) _flow = flow;
            else if (argument != null) _openParameter = argument;
        }
        AssembleUI();
        OnInit();
        RegisterEvents();
        OnShow();
    }
    public override void OnClose()
    {
        OnHide();
        UnRegisterEvents();

        if (!_closingTimeout && _parameter != null && _parameter.ViewState == SplashQuestTipsViewState.Timeout)
        {
            _activity.CompleteTimeoutPresentation(_periodId);
        }
        var flow = _flow;
        _flow = null;
        if (flow.HasValue && flow.Value.Token.IsValid)
            flow.Value.Executor?.TokenFinished(flow.Value.Token);
        base.OnClose();
    }

    protected override string AssetPath => "Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/UIActSplashQuestTipsPanel.prefab";

    private ActSplashQuest _activity;
    private int _periodId;
    private bool _participating;
    private bool _closingTimeout;
    private bool _closingExpiredOpening;
    private UIActSplashQuestTipsPanelParameter _parameter;

    private void OnInit()
    {
        _activity = ImplementHub.Instance.Get<IActivitySystem>().GetActivity<ActSplashQuest>();
        _periodId = _activity.PeriodId;
        _closingTimeout = false;
        _closingExpiredOpening = false;
        _parameter = _openParameter as UIActSplashQuestTipsPanelParameter;
        if (_parameter == null)
        {
            _parameter = new UIActSplashQuestTipsPanelParameter();
        }
    }

    private void OnShow()
    {
        RefreshUI();
        if (_parameter.ViewState != SplashQuestTipsViewState.Generic) return;
        _periodTimer = DG.Tweening.DOVirtual.DelayedCall(1f, PollPeriod, false)
            .SetLoops(-1).SetLink(Transform.gameObject);
    }
    private void PollPeriod()
    {
        if (_closingExpiredOpening)
        {
            return;
        }
        if (_parameter.ViewState == SplashQuestTipsViewState.Generic)
        {
            txt_TimeLeft.SetText(_activity.GetTimeString());
        }

        if (!_activity.IsCurrentPeriod(_periodId))
        {
            UIManager.Instance.Close(this, UIOperation.Auto);
            return;
        }
        TryCloseExpiredOpening(UIOperation.Auto);
    }

    private bool TryCloseExpiredOpening(UIOperation operation)
    {
        if (_closingExpiredOpening)
        {
            return true;
        }
        if (_parameter.ViewState != SplashQuestTipsViewState.Generic ||
            !_activity.IsCurrentPeriod(_periodId) || _activity.GetLeftTime() > 0)
        {
            return false;
        }
        _activity.CheckTimeOut();
        _closingExpiredOpening = true;
        _periodTimer?.Kill();
        _periodTimer = null;
        var flow = _flow;
        _flow = null;
        var activity = _activity;
        var periodId = _periodId;
        ImplementHub.Instance.TryGet(out IFlowScheduler scheduler);
        UIManager.Instance.Close<UIActSplashQuestMainPanel>(operation,
            () => UIManager.Instance.Close(this, operation,
                () => activity.HandleAfterOpeningExpired(flow, periodId, scheduler)));
        return true;
    }

    private void OnHide()
    {
        _periodTimer?.Kill();
        _periodTimer = null;
    }

    private void RegisterEvents()
    {
        btn_Confirm.onClick.AddListener(OnClickConfirm);
        btn_Close.onClick.AddListener(OnClickClose);
    }

    private void UnRegisterEvents()
    {
        btn_Confirm.onClick.RemoveListener(OnClickConfirm);
        btn_Close.onClick.RemoveListener(OnClickClose);
    }

    private void OnClickConfirm()
    {
        if (TryCloseExpiredOpening(UIOperation.Click))
        {
            return;
        }
        if (_parameter.ViewState == SplashQuestTipsViewState.Generic)
        {
            if (_participating || !_activity.IsCurrentPeriod(_periodId))
            {
                return;
            }
            _participating = true;
            var flow = _flow;
            _flow = null;
            _activity.Participate(flow);
        }
        ClosePanel();
    }

    private void OnClickClose()
    {
        ClosePanel();
    }

    private void ClosePanel()
    {
        if (TryCloseExpiredOpening(UIOperation.Click))
        {
            return;
        }
        if (_parameter.ViewState != SplashQuestTipsViewState.Timeout)
        {
            UIManager.Instance.Close(this, UIOperation.Click);
            return;
        }
        if (_closingTimeout)
        {
            return;
        }
        _closingTimeout = true;
        var flow = _flow;
        _flow = null;
        var activity = _activity;
        var periodId = _periodId;
        UIManager.Instance.Close(this, UIOperation.Click,
            () => activity.HandleAfterTimeoutPresentation(flow, periodId));
    }

    private void RefreshUI()
    {
        var viewState = _parameter.ViewState;
        var isPreviewState = viewState == SplashQuestTipsViewState.Preview;
        btn_Close.gameObject.SetActive(viewState != SplashQuestTipsViewState.Completed);
        trans_Stage.gameObject.SetActive(!isPreviewState);
        trans_TimeClock.gameObject.SetActive(viewState == SplashQuestTipsViewState.Generic);
        txt_Stage.gameObject.SetActive(viewState == SplashQuestTipsViewState.Generic);

        if (isPreviewState)
        {
            txt_Title.SetLocale("str_id_SplashQuest_Title");
            txt_Tips.SetLocale("str_id_SplashQuest_Sign1");
            txt_Description.SetLocale("str_id_UnlockAtLevel", args:ImplementHub.Instance.Get<IActivitySystem>().GetActivity<ActSplashQuest>().OpenLevel);
            txt_Confirm.SetLocale("str_id_Preview");
            return;
        }

        if (viewState == SplashQuestTipsViewState.Timeout)
        {
            txt_Title.SetLocale("str_id_SplashQuest_Title");
            txt_Tips.SetLocale("str_id_SplashQuest_Sign3");
            txt_Description.SetLocale("str_id_SplashQuest_OpenTips3");
            txt_Confirm.SetLocale("str_id_Bye");
            return;
        }

        if (viewState == SplashQuestTipsViewState.Completed)
        {
            txt_Title.SetLocale("str_id_SplashQuest_Title");
            txt_Tips.SetLocale("str_id_SplashQuest_Sign2");
            txt_Description.SetLocale("str_id_SplashQuest_OpenTips2");
            txt_Confirm.SetLocale("str_id_Bye");
            return;
        }

        txt_Title.SetText("Splash Quest");
        txt_Tips.SetText("Stage:");
        txt_Stage.SetText($"{_activity.GetCurrentStageIndex() + 1}/{_activity.GetStageCount()}");
        txt_TimeLeft.SetText(_activity.GetTimeString());
        txt_Description.SetLocale("str_id_SplashQuest_ProgressTips1", args: _activity.MaxLevel());
        txt_Confirm.SetLocale("str_id_Start");
    }

}
