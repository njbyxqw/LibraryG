using UnityEngine.UI;
using Betta.Framework;
using UnityEngine;
using TransformUtils = Module.Utils.UtilsTransform;

public partial class UIActSplashQuestTipsPanel
{
    private Button btn_Confirm;
    private Button btn_Close;
    private UIText txt_Description;
    private UIText txt_Tips;
    private RectTransform trans_Stage;
    private RectTransform trans_TimeClock;
    private UIText txt_Title;
    private UIText txt_Confirm;
    private UIText txt_Stage;
    private UIText txt_TimeLeft;

    private void AssembleUI()
    {
        btn_Confirm = TransformUtils.Find<Button>(Transform ,"Root/btn_Confirm");
        btn_Close = TransformUtils.Find<Button>(Transform ,"Root/Background/btn_Close");
        txt_Description = TransformUtils.Find<UIText>(Transform ,"Root/Background/Description/txt_Description");
        txt_Tips = TransformUtils.Find<UIText>(Transform ,"Root/Stage/Title");
        trans_Stage = TransformUtils.Find<RectTransform>(Transform ,"Root/Stage");
        trans_TimeClock = TransformUtils.Find<RectTransform>(Transform ,"Root/Background/TimeClock");
        txt_Title = TransformUtils.Find<UIText>(Transform ,"Root/Background/TitleBg/txt_Title");
        txt_Confirm = TransformUtils.Find<UIText>(Transform ,"Root/btn_Confirm/Root/Text");
        txt_Stage = TransformUtils.Find<UIText>(Transform ,"Root/Stage/Text");
        txt_TimeLeft = TransformUtils.Find<UIText>(Transform ,"Root/Background/TimeClock/Bg/txt_TimeLeft");
    }

}
