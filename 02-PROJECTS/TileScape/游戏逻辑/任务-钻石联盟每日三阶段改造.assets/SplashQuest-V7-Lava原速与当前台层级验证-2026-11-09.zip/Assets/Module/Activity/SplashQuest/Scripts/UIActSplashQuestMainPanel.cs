using Interface.UI;
using Interface.Activity;
using Module.Activity.Flow;
using System.Collections.Generic;
using Module.Activity;
using Module.Activity.SplashQuest;
using Betta.Framework;
using BettaSDK;
using DG.Tweening;

using UnityEngine;

public partial class UIActSplashQuestMainPanel : UIWindow
{
    private PanelFlowArgs? _flow;
    private object _openParameter;
    private int _periodId;
    private bool _timeoutHandled;
    private UnityEngine.Transform Transform => RectTransform;
    public void SetFlow(PanelFlowArgs? flow) => _flow = flow;
    public override void OnOpen(params object[] args)
    {
        base.OnOpen(args);
        foreach (var argument in args)
        {
            if (argument is PanelFlowArgs flow) _flow = flow;
            else if (argument != null) _openParameter = argument;
        }
        AssembleUI();
        btn_Play.gameObject.SetActive(false);
        OnInit();
        RegisterEvents();
        OnShow();
    }
    public override void OnClose()
    {
        OnHide();
        UnRegisterEvents();

        var flow = _flow;
        _flow = null;
        if (flow.HasValue && flow.Value.Token.IsValid)
            flow.Value.Executor?.TokenFinished(flow.Value.Token);
        base.OnClose();
    }

    protected override string AssetPath =>
        $"Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/UIActSplashQuestMainPanel_{_activity.MaxLevel()}.prefab";

    public override System.Collections.IEnumerator PlayOpenAnimation()
    {
        // OnOpen时窗口尚未入显示队列；等主界面显示后再排入引导，避免引导被主界面盖住。
        if (!_timeoutHandled && _activity.IsCurrentPeriod(_periodId) && _activity.GetLeftTime() > 0 &&
            _activity.CurrentState == SplashQuestState.InRun && _activity.HelpLastPopTime() == 0)
        {
            if (_activity.OpenHelpPanel(UIOperation.Auto) != null)
            {
                _activity.RecordHelpPop();
            }
        }
        yield break;
    }

    private ActSplashQuest _activity => ImplementHub.Instance.Get<IActivitySystem>()?.GetActivity<ActSplashQuest>();

    private List<UISplashQuestMapSection> _mapSections;

    private UIActSplashQuestMainPanelParameter _parameter;

    private List<UIActSplashQuestAnimPortrait> _animPortraits;

    private UIActSplashQuestAnimPortrait _myAnimPortrait;

    private Sequence _seq;

    private Tween _timerId1 = null;

    private int _soundId = -1;

    private bool _isPlayingSettleSuccessFlow;
    private bool _isSettleFailDisplayState;
    private bool _allowSettleSuccessTapFastForward;
    private bool _hasFastForwardedSettleSuccessFlow;
    private bool _settleSuccessInputLockedDuringFlow;

    private void OnInit()
    {
        _parameter = _openParameter as UIActSplashQuestMainPanelParameter;
        if (_parameter == null)
        {
            _parameter = new UIActSplashQuestMainPanelParameter();
        }

        _periodId = _activity.PeriodId;
        _activity.CheckTimeOut();
    }

    private void OnShow()
    {
        RefreshUI();
        if (_parameter.ShowOpeningPopup)
        {
            _parameter.ShowOpeningPopup = false;
            if (_activity.OpenOpeningPanel(UIOperation.Auto, _flow) != null)
            {
                _flow = null;
            }
        }
        TryHandleTimeoutFlow();
    }

    private void OnHide()
    {
        if (_seq != null)
        {
            _seq.Kill();
            _seq = null;
        }
        _allowSettleSuccessTapFastForward = false;
        _hasFastForwardedSettleSuccessFlow = false;
        _settleSuccessInputLockedDuringFlow = false;

        if (_mapSections != null)
        {
            for (int i = 0; i < _mapSections.Count; i++)
            {
                _mapSections[i].OnRelease();
            }
            _mapSections = null;
        }

        if (_animPortraits != null)
        {
            for (int i = 0; i < _animPortraits.Count; i++)
            {
                _animPortraits[i].OnRelease();
            }
            _animPortraits = null;
        }

        _myAnimPortrait?.OnRelease();
        RestorePortraitGroupLayout();
        SetProgressCountersVisible(true);
        StopTimeLeftTimers();

        ImplementHub.Instance.Get<Interface.Sound.IAudioSystem>()?.StopAudio(_soundId);
        _parameter.CloseEvent?.Invoke();
    }

    private void RegisterEvents()
    {
        btn_Close.onClick.AddListener(OnClickClose);
        btn_Help.onClick.AddListener(OnClickHelp);
        btn_FullPageClose.onClick.AddListener(OnClickClose);
    }

    private void UnRegisterEvents()
    {
        btn_Close.onClick.RemoveListener(OnClickClose);
        btn_Help.onClick.RemoveListener(OnClickHelp);
        btn_FullPageClose.onClick.RemoveListener(OnClickClose);
    }

    private void OnClickClose()
    {
        if (_activity == null || !_activity.IsCurrentPeriod(_periodId))
        {
            UIManager.Instance.Close(this, UIOperation.Click);
            return;
        }
        if (_isPlayingSettleSuccessFlow)
        {
            if (!_allowSettleSuccessTapFastForward)
            {
                return;
            }

            if (_hasFastForwardedSettleSuccessFlow)
            {
                return;
            }

            _hasFastForwardedSettleSuccessFlow = true;
            _seq?.Kill();
            _isPlayingSettleSuccessFlow = false;

            if (_activity != null && _activity.CurrentState == SplashQuestState.Timeout)
            {
                TryHandleTimeoutFlow();
                return;
            }

            UIManager.Instance.Close<UIActSplashQuestMainPanel>(UIOperation.Click);
            return;
        }
        if (_activity != null)
        {
            var hasPendingExitState =
                _activity.SplashQuestStateView == SplashQuestState.Timeout ||
                (_isSettleFailDisplayState &&
                 !_activity.IsTerminalStageState());

            if (hasPendingExitState)
            {
                _activity.EndStagePresentationSnapshot();
                if (_activity.SplashQuestStateView == SplashQuestState.Timeout)
                {
                    TryHandleTimeoutFlow();
                    return;
                }
            }
        }
        UIManager.Instance.Close<UIActSplashQuestMainPanel>(UIOperation.Click);
    }

    private void OnClickHelp()
    {
        if (_isPlayingSettleSuccessFlow)
        {
            return;
        }
        if (_activity == null)
        {
            return;
        }
        _activity.OpenHelpPanel(UIOperation.Click);
    }

    private void StopTimeLeftTimers()
    {
        if (_timerId1 != null)
        {
            _timerId1?.Kill();
            _timerId1 = null;
        }
    }

    private void RefreshUI()
    {
        _activity.CheckTimeOut();
        StopTimeLeftTimers();

        var mainViewState = _activity.MainViewStateView;
        var failProgressBeforeSettle = _activity.FailProgressBeforeSettle();

        RefreshHeaderTimeTextsAndTimers();
        InitMap();
        InitAvatars();
        ResetRefreshTransientState(mainViewState);
        LogRefreshState(mainViewState, failProgressBeforeSettle);

        RenderMainPanelByViewState(mainViewState, failProgressBeforeSettle);
        FinalizeRefreshUI();
    }

    private void RefreshHeaderTimeTextsAndTimers()
    {
        txt_TimeLeft.SetText(_activity.GetTimeString());
        _timerId1 = DOVirtual.DelayedCall(1, () =>
        {
            if (!_activity.IsCurrentPeriod(_periodId))
            {
                UIManager.Instance.Close(this, UIOperation.Auto);
                return;
            }
            txt_TimeLeft.SetText(_activity.GetTimeString());
            _activity.CheckTimeOut();
            TryHandleTimeoutFlow();
        }, false).SetLoops(-1).SetLink(Transform.gameObject);
    }

    private void ResetRefreshTransientState(SplashQuestMainViewState mainViewState)
    {
        SetMainPanelCloseButtonsVisible(false, false);
        _isPlayingSettleSuccessFlow = false;
        _isSettleFailDisplayState = mainViewState == SplashQuestMainViewState.SettleFail;
        _allowSettleSuccessTapFastForward = false;
        _hasFastForwardedSettleSuccessFlow = false;
        _settleSuccessInputLockedDuringFlow = false;
    }

    private void SetMainPanelCloseButtonsVisible(bool closeVisible, bool fullPageCloseVisible)
    {
        btn_Close.gameObject.SetActive(closeVisible);
        btn_FullPageClose.gameObject.SetActive(fullPageCloseVisible);
    }

    private void LogRefreshState(SplashQuestMainViewState mainViewState, int failProgressBeforeSettle)
    {
        UtilsLog.L(
            $"[SplashQuest][MainPanel][RefreshUI] " +
            $"mainViewState={mainViewState}, " +
            $"stageViewState={_activity.StageViewStateView}, " +
            $"activityState={_activity.SplashQuestStateView}, " +
            $"currentProgress={_activity.CurrentLevel()}/{_activity.MaxLevel()}, " +
            $"lastProgress={_activity.LastLevel()}/{_activity.MaxLevel()}, " +
            $"failProgressBeforeSettle={failProgressBeforeSettle}/{_activity.MaxLevel()}, " +
            $"leftPeople={_activity.LeftNumOfPeople()}, " +
            $"lastLeftPeople={_activity.LastLeftNumOfPeople()}, " +
            $"hasPendingWin={_activity.HasPendingWinRewardClaim()}, " +
            $"hasPendingTimeout={_activity.HasPendingTimeoutPopup()}"
        );
    }

    private void RenderMainPanelByViewState(SplashQuestMainViewState mainViewState, int failProgressBeforeSettle)
    {
        if (mainViewState == SplashQuestMainViewState.SettleSuccess)
        {
            RenderSettleSuccessState();
            return;
        }

        if (mainViewState == SplashQuestMainViewState.SettleFail)
        {
            RenderSettleFailState(failProgressBeforeSettle);
            return;
        }

        RenderNormalState();
    }

    private void RenderSettleSuccessState()
    {
        SetProgressCountersVisible(true);
        txt_LeftNum.SetText(_activity.LastLeftNumOfPeople().ToString());
        txt_Progress.SetText($"{_activity.LastLevel()}/{_activity.MaxLevel()}");
        PlaySuccessAnim();
    }

    private void RenderSettleFailState(int failProgressBeforeSettle)
    {
        SetProgressCountersVisible(false);
        txt_LeftNum.SetText(_activity.LastLeftNumOfPeople().ToString());
        txt_Progress.SetText($"{failProgressBeforeSettle}/{_activity.MaxLevel()}");
        PlayFailAnim();
    }

    private void RenderNormalState()
    {
        SetProgressCountersVisible(_activity.CurrentState != SplashQuestState.Timeout);
        txt_LeftNum.SetText(_activity.LeftNumOfPeople().ToString());
        txt_Progress.SetText($"{_activity.CurrentLevel()}/{_activity.MaxLevel()}");
        SetMainPanelCloseButtonsVisible(true, false);
    }

    private void FinalizeRefreshUI()
    {
        RefreshStageTitleTexts();
        _activity.RecordShowData();
        _activity.ConsumeMainViewState();

        _soundId = ImplementHub.Instance.Get<Interface.Sound.IAudioSystem>()?.PlayAudio(Module.Audio.SoundConst.SFX_Temple_Stream, true, -1f) ?? -1;
    }

    private void RefreshStageTitleTexts()
    {
        var stage = $"Stage {_activity.GetCurrentStageIndex() + 1}";
        txt_Stage.SetText(stage);
    }
}
