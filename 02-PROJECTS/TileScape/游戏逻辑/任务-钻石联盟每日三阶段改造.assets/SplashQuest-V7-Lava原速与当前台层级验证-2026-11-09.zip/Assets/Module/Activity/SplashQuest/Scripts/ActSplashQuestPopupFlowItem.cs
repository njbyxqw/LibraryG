using Interface.Flow;
using Interface.UI;
using Module.Activity.Flow;

namespace Module.Activity
{
    internal sealed class ActSplashQuestPopupFlowItem : IFlowItem, IFlowUserSkipPolicy
    {
        private readonly ActSplashQuest _activity;
        private readonly bool _opening;

        public ActSplashQuestPopupFlowItem(ActSplashQuest activity, bool opening = false)
        {
            _activity = activity;
            _opening = opening;
        }

        public string Group => "Home";
        public int Priority => HomePopupPriority.GetPopupPriority(
            _opening ? HomePopupStep.Start : HomePopupStep.Settlement, 6);
        public bool DeleteAfterExecute => false;

        public bool CanRun(FlowContext context)
        {
            if (context.Group != Group || !_activity.CanPresent())
            {
                return false;
            }

            return _opening
                ? _activity.HasPendingAutomaticOpening
                : !_activity.HasPendingAutomaticOpening && _activity.CanPopup();
        }

        public bool CanUserSkip(FlowContext context) => false;

        public void Run(FlowContext context, FlowToken token, IFlowExecutor executor)
        {
            if (!CanRun(context))
            {
                executor.TokenFinished(token);
                return;
            }

            var args = new PanelFlowArgs(token, executor);
            if (_opening)
            {
                if (_activity.OpenOpeningPanel(UIOperation.Auto, args) == null)
                {
                    executor.TokenFinished(token);
                }
                return;
            }

            if (!_activity.Check(args))
            {
                executor.TokenFinished(token);
            }
        }
    }
}
