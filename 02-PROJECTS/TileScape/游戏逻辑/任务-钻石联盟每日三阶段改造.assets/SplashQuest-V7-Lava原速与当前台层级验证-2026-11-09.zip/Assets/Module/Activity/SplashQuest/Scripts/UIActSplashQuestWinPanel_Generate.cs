using UnityEngine.UI;
using Betta.Framework;
using UnityEngine;
using TMPro;
using TransformUtils = Module.Utils.UtilsTransform;

public partial class UIActSplashQuestWinPanel
{
    private Button btn_FullPage;
    private RectTransform trans_CurrencyRoot;
    private RectTransform trans_Title;
    private RectTransform trans_Description;
    private RectTransform trans_Reward;
    private RectTransform trans_Portrait;
    private UIText txt_WinDescription;
    private RectTransform trans_PeopleRoot;
    private RectTransform trans_TapToContinue;
    private UIText txt_SubTitle;
    private RectTransform trans_Temple;
    private RectTransform trans_Point;

    private void AssembleUI()
    {
        btn_FullPage = TransformUtils.Find<Button>(Transform ,"btn_FullPage");
        trans_CurrencyRoot = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_CurrencyRoot");
        trans_Title = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_Title");
        trans_Description = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_Description");
        trans_Reward = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_Reward");
        trans_Portrait = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_Portrait");
        txt_WinDescription = TransformUtils.Find<UIText>(Transform ,"Root/txt_WinDescription");
        trans_PeopleRoot = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_PeopleRoot");
        trans_TapToContinue = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_TapToContinue");
        txt_SubTitle = TransformUtils.Find<UIText>(Transform ,"Root/trans_Description/txt_SubTitle");
        trans_Temple = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_Reward/trans_Temple");
        trans_Point = TransformUtils.Find<RectTransform>(Transform ,"Root/trans_Reward/trans_Point");
    }

}
