using Interface.UICurrency;
using Interface.UI;
using Interface.Activity;
using Interface.Item;
using Module.Activity.Flow;
using TransformUtils = Module.Utils.UtilsTransform;
using System;
using System.Collections.Generic;
using Module.Activity;
using Module.Activity.SplashQuest;
using Module.Activity.Robot;
using Betta.Framework;
using BettaSDK;
using DG.Tweening;
using Game;

using Module.PlayerInfo;

using UnityEngine;
using UnityEngine.UI;

using Object = UnityEngine.Object;

using ItemChangeData = Interface.Item.ItemChangeData;

public partial class UIActSplashQuestWinPanel : UIWindow
{
    private PanelFlowArgs? _flow;
    private object _openParameter;
    private UnityEngine.Transform Transform => RectTransform;
    public void SetFlow(PanelFlowArgs? flow) => _flow = flow;
    public override void OnOpen(params object[] args)
    {
        base.OnOpen(args);
        if (RectTransform == null) return;
        foreach (var argument in args)
        {
            if (argument is PanelFlowArgs flow) _flow = flow;
            else if (argument != null) _openParameter = argument;
        }
        AssembleUI();
        OnInit();
        RegisterEvents();
        OnShow();
    }
    public override void OnClose()
    {
        OnHide();
        UnRegisterEvents();
        OnDestroy();
        var flow = _flow;
        _flow = null;
        if (flow.HasValue && flow.Value.Token.IsValid)
            flow.Value.Executor?.TokenFinished(flow.Value.Token);
        base.OnClose();
    }

    private const string CurrencyIdentifier = "Overlay.SplashQuestWin";
    protected override string AssetPath => "Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/UIActSplashQuestWinPanel.prefab";

    private List<UIActSplashQuestAnimPortrait> _portraits = new List<UIActSplashQuestAnimPortrait>();

    private UIActSplashQuestAnimPortrait _myPortrait;

    private ActSplashQuest _activity;
    private int _periodId;
    private int _completedStageId;

    private UIActSplashQuestWinPanelParameter _parameter;

    private Tween _portraitAppearTween;

    private int _rewardCount = 0;

    private Tweener _tweener;

    private bool _isClaimProcessing;

    private bool _isRewardPresentationFinished;
    private bool _isClosingAfterWinClaim;

    private bool _waitingForRewardClick;

    private bool _useItemRewardDisplay;

    private Tween _rewardClickUnlockTimerId = null;

    private const float ItemRewardTempleScale = 0.72f;

    private const float ItemRewardCellSize = 200f * ItemRewardTempleScale;

    /// <summary>与通用发奖 UIRewardItemLayout.PlayFloatUpAndDisappearAnimationAsync 一致。</summary>
    private const float ItemRewardFloatUpOffsetY = 300f;

    private const float ItemRewardFloatUpDuration = 0.9f;

    private const float ItemRewardFadeDuration = 0.25f;

    private const float ItemRewardFadeDelay = 0.65f;

    private const float ShowTapToContinueDelay = 0.3f;

    private const float DiamondHoldAfterCountUp = 1.0f;

    private const float HideTempleBeforeFlyDelay = 0.2f;

    private const int DiamondFlyMaxTimes = 8;

    private const float DiamondFlyTrackDuration = 1.0f;

    private const float DiamondFlyInterval = 0.1f;

    private const float DiamondFlyCurrencyBarBuffer = 0.45f;

    private readonly List<IItemRewardCell> _itemRewardUiItems = new List<IItemRewardCell>();

    private static UIText FindTempleRewardNum(RectTransform transTemple)
    {
        if (transTemple == null)
        {
            return null;
        }

        return TransformUtils.Find<UIText>(transTemple, "Root/CountBg/RewardNum");
    }

    private static RectTransform FindTempleEffectPenShe(RectTransform transTemple)
    {
        if (transTemple == null)
        {
            return null;
        }

        return TransformUtils.Find<RectTransform>(transTemple, "Effect_PenShe");
    }

    private void EnsureRobotPortraitInfosIfNeeded()
    {
        var list = _parameter.PortraitInfos;
        if (list == null)
        {
            list = new List<int[]>();
            _parameter.PortraitInfos = list;
        }

        var allValid = list.Count > 0;
        for (var i = 0; i < list.Count; i++)
        {
            var row = list[i];
            if (row == null || row.Length < 3)
            {
                allValid = false;
                break;
            }
        }

        if (allValid)
        {
            return;
        }

        list.Clear();
        var leftPeople = _activity.LeftNumOfPeople();
        var robotCount = Mathf.Min(Mathf.Min(leftPeople - 1, 5), _portraits.Count);
        var pis = ImplementHub.Instance.Get<Interface.PlayerInfo.IPlayerInfo>();
        for (var i = 0; i < robotCount; i++)
        {
            list.Add(new[]
            {
                pis.GetRandomId(PortraitType.Avatar),
                pis.GetRandomId(PortraitType.Frame),
                0,
            });
        }
    }

    private void OnInit()
    {
        _activity = ImplementHub.Instance.Get<IActivitySystem>().GetActivity<ActSplashQuest>();
        if (_activity == null)
        {
            return;
        }

        _parameter = _openParameter as UIActSplashQuestWinPanelParameter;
        if (_parameter == null)
        {
            _parameter = new UIActSplashQuestWinPanelParameter();
        }
        if (_parameter.PortraitInfos == null)
        {
            _parameter.PortraitInfos = new List<int[]>();
        }

        var count = trans_PeopleRoot.childCount;
        for (int i = 0; i < count; i++)
        {
            var portrait = new UIActSplashQuestAnimPortrait(trans_PeopleRoot.GetChild(i));
            _portraits.Add(portrait);
            portrait.Transform.gameObject.SetActive(false);
        }

        EnsureRobotPortraitInfosIfNeeded();

        _myPortrait = new UIActSplashQuestAnimPortrait(trans_Portrait);

        _periodId = _activity.PeriodId;
        _completedStageId = _activity.Profile.PendingWinStageId;
        _rewardCount = _activity.GetRetainDiamondShareCeil();

        var templeEffectPenShe = FindTempleEffectPenShe(trans_Temple);
        if (templeEffectPenShe != null)
        {
            templeEffectPenShe.gameObject.SetActive(false);
        }

        var config = new CurrencyBarConfig(CurrencyIdentifier, trans_CurrencyRoot)
        {
            LayerOrder = LayerOrder,
            Anchor = TextAnchor.MiddleCenter,
            FileLeft = 100,
            DefaultShow = false,
            EnableBuy = false,
            VisibilityMode = CurrencyBarVisibilityMode.Exclusive,
        };
        config.ItemIds.Add((int)ITEM_ID.DIAMOND);
        ImplementHub.Instance.Get<Interface.UICurrency.ICurrencyBar>().Register(config);
    }

    private void OnShow()
    {
        RefreshUI();
        _activity.ClaimCurrentStageWinReward();
        _portraitAppearTween = DOVirtual.DelayedCall(0.78333336f, OnShowPortrait, false).SetLink(Transform.gameObject);
    }

    private void OnHide()
    {
        StopRewardClickUnlockTimer();
        _waitingForRewardClick = false;
        ReleaseItemRewardUiItems();
        foreach (var portrait in _portraits)
        {
            portrait.OnRelease();
        }
        _myPortrait?.OnRelease();
        _myPortrait = null;
        _portraits.Clear();
    }

    private void OnDestroy()
    {
        ReleaseItemRewardUiItems();
        ImplementHub.Instance.Get<Interface.UICurrency.ICurrencyBar>().Unregister(CurrencyIdentifier);

    }

    private void RegisterEvents()
    {
        btn_FullPage.onClick.AddListener(OnClickFullPage);

    }

    private void UnRegisterEvents()
    {
        btn_FullPage.onClick.RemoveListener(OnClickFullPage);

        _portraitAppearTween?.Kill();
    }

    private void OnClickFullPage()
    {
        if (_isClaimProcessing || _activity == null)
        {
            return;
        }
        if (!_activity.IsCurrentPeriod(_periodId) || _activity.Profile.PendingWinStageId != _completedStageId)
        {
            UIManager.Instance.Close(this, UIOperation.Auto);
            return;
        }

        if (_waitingForRewardClick)
        {
            _waitingForRewardClick = false;
            btn_FullPage.interactable = false;
            HideTapToContinue();
            if (_useItemRewardDisplay)
            {
                PlayItemRewardPresentationFlow(BeginCloseAfterWinClaim);
                return;
            }

            PlayDiamondFlyPresentation(BeginCloseAfterWinClaim);
            return;
        }

        if (!_isRewardPresentationFinished)
        {
            return;
        }

        BeginCloseAfterWinClaim();
    }

    private void BeginCloseAfterWinClaim()
    {
        if (_isClaimProcessing || _activity == null)
        {
            return;
        }

        if (!_activity.IsCurrentPeriod(_periodId) || _activity.Profile.PendingWinStageId != _completedStageId)
        {
            return;
        }
        _activity.ClaimCurrentStageWinReward();
        if (!_activity.HasPendingWinPresentation())
        {
            return;
        }
        _isClaimProcessing = true;
        btn_FullPage.interactable = false;
        HideTapToContinue();
        ClosePanelAfterWinClaim();
    }

    private void OnEnterPresentationComplete()
    {
        if (!_useItemRewardDisplay)
        {
            return;
        }

        if (_itemRewardUiItems.Count > 0)
        {
            ScheduleRewardClickUnlock();
        }
        else
        {
            OnRewardPresentationComplete();
        }
    }

    private void OnRewardPresentationComplete()
    {
        _isRewardPresentationFinished = true;
        ScheduleShowTapToContinue();
    }

    private void ScheduleRewardClickUnlock()
    {
        StopRewardClickUnlockTimer();
        _waitingForRewardClick = false;
        btn_FullPage.interactable = false;
        _rewardClickUnlockTimerId = DOVirtual.DelayedCall(DiamondHoldAfterCountUp, EnableRewardClick, false).SetLink(Transform.gameObject);
    }

    private void StopRewardClickUnlockTimer()
    {
        if (_rewardClickUnlockTimerId == null)
        {
            return;
        }

        _rewardClickUnlockTimerId?.Kill();
        _rewardClickUnlockTimerId = null;
    }

    private void EnableRewardClick()
    {
        _rewardClickUnlockTimerId = null;
        if (_activity == null || _isClaimProcessing)
        {
            return;
        }

        _waitingForRewardClick = true;
        ShowTapToContinue();
    }

    private void PlayDiamondFlyPresentation(Action onComplete)
    {
        DOVirtual.DelayedCall(HideTempleBeforeFlyDelay, () =>
        {
            if (trans_Temple != null)
            {
                trans_Temple.gameObject.SetActive(false);
            }

            var templeEffectPenShe = FindTempleEffectPenShe(trans_Temple);
            if (templeEffectPenShe != null)
            {
                templeEffectPenShe.gameObject.SetActive(false);
            }

            if (_rewardCount > 0)
            {
                DispatchDiamondFlyPresentation();
            }

            var waitDuration = _rewardCount > 0 ? EstimateDiamondFlyPresentationDuration() : 0f;
            if (waitDuration <= 0f)
            {
                onComplete?.Invoke();
                return;
            }

            DOVirtual.DelayedCall(waitDuration, () => { onComplete?.Invoke(); }, false).SetLink(Transform.gameObject);
        }, false).SetLink(Transform.gameObject);
    }

    private void DispatchDiamondFlyPresentation()
    {
        ImplementHub.Instance.Get<Interface.Reward.IRewardSystem>()?.TryFly(new Interface.Reward.RewardDisplayRefreshRequest
        {
            Rewards = new[] { new Interface.Reward.RewardEntryAmount((int)ITEM_ID.DIAMOND, _rewardCount) },
            SessionKey = $"SplashQuest.Win.{_activity.ConfigId}.{_activity.PeriodId}.{_activity.RunSerial}",
            StartScreenPositions = new[] { new Vector2(Screen.width * 0.5f, Screen.height * 0.5f) },
        }, out _);
    }

    private float EstimateDiamondFlyPresentationDuration()
    {
        var flyTimes = Mathf.Min(Mathf.Max(_rewardCount, 1), DiamondFlyMaxTimes);
        var flyDuration = DiamondFlyTrackDuration - 0.05f;
        return flyDuration + (flyTimes - 1) * DiamondFlyInterval + DiamondFlyCurrencyBarBuffer;
    }

    private void ClosePanelAfterWinClaim()
    {
        if (_isClosingAfterWinClaim)
        {
            return;
        }
        _isClosingAfterWinClaim = true;
        var token = _flow;
        _flow = null;
        var activity = _activity;
        var periodId = _periodId;
        var stageId = _completedStageId;
        UIManager.Instance.Close(this, UIOperation.Click,
            () => activity.HandleAfterWinClaim(token, periodId, stageId));
    }

    private void HideTapToContinue()
    {
        if (trans_TapToContinue != null)
        {
            trans_TapToContinue.gameObject.SetActive(false);
        }
    }

    private void ShowTapToContinue()
    {
        if (trans_TapToContinue != null)
        {
            trans_TapToContinue.gameObject.SetActive(true);
        }

        btn_FullPage.gameObject.SetActive(true);
        btn_FullPage.interactable = true;
    }

    private void ScheduleShowTapToContinue()
    {
        if (ShowTapToContinueDelay <= 0f)
        {
            ShowTapToContinue();
            return;
        }

        DOVirtual.DelayedCall(ShowTapToContinueDelay, ShowTapToContinue, false).SetLink(Transform.gameObject);
    }

    /// <summary>
    /// 在隐藏本体、触发布局重算之前先快照 Rect 布局；克隆挂在与本体同一父节点下并复制布局，避免跨父节点时的相机/屏幕坐标转换误差（易表现为整体贴屏幕底边）。
    /// </summary>
    private void PlayFloatUpAndDisappearAnimation(
        RectTransform sourceRect,
        Vector2 anchoredPosition,
        Vector2 anchorMin,
        Vector2 anchorMax,
        Vector2 pivot,
        Vector2 sizeDelta,
        Quaternion localRotation,
        Vector3 localScale,
        Action onComplete)
    {
        if (sourceRect == null)
        {
            onComplete?.Invoke();
            return;
        }

        var parentRt = sourceRect.parent as RectTransform;
        if (parentRt == null)
        {
            onComplete?.Invoke();
            return;
        }

        var originalGameObject = sourceRect.gameObject;
        originalGameObject.SetActive(false);

        var copiedGameObject = Object.Instantiate(originalGameObject, parentRt, false);
        copiedGameObject.SetActive(true);

        var rectTransform = copiedGameObject.GetComponent<RectTransform>();
        if (rectTransform == null)
        {
            Object.Destroy(copiedGameObject);
            onComplete?.Invoke();
            return;
        }

        rectTransform.anchorMin = anchorMin;
        rectTransform.anchorMax = anchorMax;
        rectTransform.pivot = pivot;
        rectTransform.sizeDelta = sizeDelta;
        rectTransform.anchoredPosition = anchoredPosition;
        rectTransform.localRotation = localRotation;
        rectTransform.localScale = localScale;

        var layoutElement = copiedGameObject.GetComponent<LayoutElement>();
        if (layoutElement == null)
        {
            layoutElement = copiedGameObject.AddComponent<LayoutElement>();
        }

        layoutElement.ignoreLayout = true;
        rectTransform.SetAsLastSibling();

        var canvasGroup = copiedGameObject.GetComponent<CanvasGroup>();
        if (canvasGroup == null)
        {
            canvasGroup = copiedGameObject.AddComponent<CanvasGroup>();
        }

        canvasGroup.blocksRaycasts = false;

        var sequence = DOTween.Sequence();
        var startY = rectTransform.localPosition.y;
        sequence.Append(rectTransform.DOLocalMoveY(startY + ItemRewardFloatUpOffsetY, ItemRewardFloatUpDuration).SetEase(Ease.InQuart));
        sequence.Join(canvasGroup.DOFade(0f, ItemRewardFadeDuration).SetDelay(ItemRewardFadeDelay));
        sequence.SetLink(copiedGameObject);
        sequence.OnComplete(() =>
        {
            if (copiedGameObject != null)
            {
                Object.Destroy(copiedGameObject);
            }

            onComplete?.Invoke();
        });
    }

    private void PlayItemRewardPresentationFlow(Action onComplete)
    {
        var snapshots = new List<(
            RectTransform rt,
            Vector2 anchoredPosition,
            Vector2 anchorMin,
            Vector2 anchorMax,
            Vector2 pivot,
            Vector2 sizeDelta,
            Quaternion localRotation,
            Vector3 localScale)>();
        for (var i = 0; i < _itemRewardUiItems.Count; i++)
        {
            var uiItem = _itemRewardUiItems[i];
            if (uiItem?.Root == null)
            {
                continue;
            }

            var rt = uiItem.Root as RectTransform;
            if (rt == null)
            {
                continue;
            }

            snapshots.Add((
                rt,
                rt.anchoredPosition,
                rt.anchorMin,
                rt.anchorMax,
                rt.pivot,
                rt.sizeDelta,
                rt.localRotation,
                rt.localScale));
        }

        if (snapshots.Count == 0)
        {
            onComplete?.Invoke();
            return;
        }

        var total = snapshots.Count;
        var completed = 0;
        void OnOneAnimationDone()
        {
            completed++;
            if (completed >= total)
            {
                onComplete?.Invoke();
            }
        }

        for (var i = 0; i < snapshots.Count; i++)
        {
            var s = snapshots[i];
            PlayFloatUpAndDisappearAnimation(
                s.rt,
                s.anchoredPosition,
                s.anchorMin,
                s.anchorMax,
                s.pivot,
                s.sizeDelta,
                s.localRotation,
                s.localScale,
                OnOneAnimationDone);
        }
    }

    private void OnShowPortrait()
    {
        var portraitInfos = _parameter.PortraitInfos;
        for (int i = 0; i < _portraits.Count; i++)
        {
            if (i < portraitInfos.Count && portraitInfos[i] != null && portraitInfos[i].Length >= 3)
            {
                _portraits[i].Transform.gameObject.SetActive(true);
            }
        }
    }

    private bool UseItemRewardDisplay()
    {
        if (_activity == null)
        {
            return false;
        }

        return _activity.GetRawTotalDiamondCount() == 0 && _activity.GetCurrentStageRewardList().Length > 0;
    }

    private void ReleaseItemRewardUiItems()
    {
        for (int i = 0; i < _itemRewardUiItems.Count; i++)
        {
            var uiItem = _itemRewardUiItems[i];
            if (uiItem == null)
            {
                continue;
            }

            uiItem.Release();
            if (uiItem.Root != null)
            {
                UnityEngine.Object.Destroy(uiItem.Root.gameObject);
            }
        }

        _itemRewardUiItems.Clear();
    }

    private void RefreshItemRewardUiItems()
    {
        ReleaseItemRewardUiItems();
        if (trans_Temple == null || trans_Reward == null || _activity == null)
        {
            return;
        }

        var rewards = _activity.GetCurrentStageRewardList();
        if (rewards == null || rewards.Length == 0)
        {
            return;
        }

        trans_Temple.gameObject.SetActive(false);

        for (int i = 0; i < rewards.Length; i++)
        {
            var reward = rewards[i];
            if (reward == null || reward.Length < 2)
            {
                continue;
            }

            var item = ActSplashQuest.CreateRewardCell(trans_Reward, reward, ItemRewardCellSize);
            _itemRewardUiItems.Add(item);
        }
    }

    private void RefreshUI()
    {
        if (_activity == null)
        {
            return;
        }

        var txtRewardNum = FindTempleRewardNum(trans_Temple);
        var templeEffectPenShe = FindTempleEffectPenShe(trans_Temple);

        var itemReward = UseItemRewardDisplay();
        _useItemRewardDisplay = itemReward;
        trans_CurrencyRoot.gameObject.SetActive(!itemReward);

        if (itemReward)
        {
            if (trans_Temple != null)
            {
                trans_Temple.gameObject.SetActive(false);
            }

            RefreshItemRewardUiItems();

            if (templeEffectPenShe != null)
            {
                templeEffectPenShe.gameObject.SetActive(false);
            }
        }
        else
        {
            ReleaseItemRewardUiItems();

            if (trans_Temple != null)
            {
                trans_Temple.gameObject.SetActive(true);
            }
        }

        if (trans_Point != null)
        {
            trans_Point.gameObject.SetActive(false);
        }

        var rewardCountBg = txtRewardNum != null ? txtRewardNum.transform.parent : null;
        if (rewardCountBg != null)
        {
            rewardCountBg.gameObject.SetActive(!itemReward);
        }

        if (txtRewardNum != null)
        {
            txtRewardNum.text = "x" + 0;
        }

        HideTapToContinue();
        btn_FullPage.gameObject.SetActive(true);
        btn_FullPage.interactable = false;
        _isClaimProcessing = false;
        _isRewardPresentationFinished = false;
        _isClosingAfterWinClaim = false;
        _waitingForRewardClick = false;
        StopRewardClickUnlockTimer();
        _tweener?.Kill();
        if (templeEffectPenShe != null)
        {
            templeEffectPenShe.gameObject.SetActive(false);
        }

        if (itemReward)
        {
            _tweener = DOTween.To(()=>0, value =>
            {
            }, 1, 0.5f).SetDelay(0.3f).SetLink(btn_FullPage.gameObject).OnComplete(OnEnterPresentationComplete);
        }
        else if (txtRewardNum != null)
        {
            ImplementHub.Instance.Get<Interface.Sound.IAudioSystem>()?.PlayAudio(Module.Audio.SoundConst.SFX_Temple_NumberRise, false, -1f);
            _tweener = DOTween.To(() => 0, (count) =>
            {
                txtRewardNum.text = "x" + count;
            }, _rewardCount, 1f).SetDelay(0.3f).SetLink(txtRewardNum.gameObject).OnComplete(() =>
            {
                txtRewardNum.text = "x" + _rewardCount;
                var fx = FindTempleEffectPenShe(trans_Temple);
                if (fx != null)
                {
                    fx.gameObject.SetActive(true);
                }

                ScheduleRewardClickUnlock();
            });
        }
        else
        {
            ScheduleRewardClickUnlock();
        }

        txt_SubTitle.SetText($"{_activity.Profile.PendingWinStageIndex + 1}/{_activity.GetStageCount()} · " +
            LocaleManager.GetText("str_id_SplashQuest_GrandPrize") + $" {_activity.GetRawTotalDiamondCount()}");

        var portraitInfos = _parameter.PortraitInfos;
        for (int i = 0; i < _portraits.Count; i++)
        {
            if (i < portraitInfos.Count && portraitInfos[i] != null && portraitInfos[i].Length >= 3)
            {
                _portraits[i].Show(portraitInfos[i][0], portraitInfos[i][1], portraitInfos[i][2]);
            }
        }

        var playerInfo = ImplementHub.Instance.Get<Interface.PlayerInfo.IPlayerInfo>();
        _myPortrait.Show(playerInfo.GetAvatarId(), playerInfo.GetFrameId(), 0);

        if (itemReward)
        {
            txt_WinDescription.SetLocale("str_id_SplashQuest_ClaimTips3", args:Mathf.Max(0, _activity.LeftNumOfPeople() - 1));
        }
        else
        {
            txt_WinDescription.SetLocale("str_id_SplashQuest_ClaimTips2", args:Mathf.Max(0, _activity.LeftNumOfPeople() - 1));
        }
    }
}
