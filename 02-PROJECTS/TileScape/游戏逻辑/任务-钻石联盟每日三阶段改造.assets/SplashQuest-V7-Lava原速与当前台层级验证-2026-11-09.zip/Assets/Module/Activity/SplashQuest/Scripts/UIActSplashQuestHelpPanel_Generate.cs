using UnityEngine.UI;
using Betta.Framework;
using UnityEngine;
using TMPro;
using TransformUtils = Module.Utils.UtilsTransform;

public partial class UIActSplashQuestHelpPanel
{
    private Button btn_Close;

    private void AssembleUI()
    {
        btn_Close = TransformUtils.Find<Button>(Transform ,"Root/btn_Close");
    }

}
