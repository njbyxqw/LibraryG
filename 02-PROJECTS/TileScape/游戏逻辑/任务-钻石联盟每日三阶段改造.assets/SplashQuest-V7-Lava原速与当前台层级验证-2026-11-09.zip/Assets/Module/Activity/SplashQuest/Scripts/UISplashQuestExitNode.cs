using BettaSDK;
using Interface.Activity;
using TransformUtils = Module.Utils.UtilsTransform;
using Module.Activity;
using Betta.Framework;
using DG.Tweening;

using UnityEngine;

namespace Module.Activity.SplashQuest
{
    public class UISplashQuestExitNode : UIBase, IActivityExitNode
    {
        private Transform Transform => RectTransform;
        public int InstanceId => GetHashCode();
        public string RetainName { get; private set; }
        public System.Func<Transform> CreateFunc => () => RectTransform;
        public void SetOpenSource() { }
        private const int RetainStrongProgressThreshold = 50;
        private const string RetainStrongAnim = "shiluo";
        private const float DisplayLoopHalfDuration = 0.38f;
        private const float DisplayLoopSettleDuration = 0.08f;
        private const float DisplayLoopPauseAfterCycle = 0.5f;
        private const float DisplayLoopSwingXOffset = 10f;
        private const float DisplayLoopWobbleZDeg = 5f;
        private const float DisplayLoopMinScale = 0.9f;
        private const float DisplayLoopMinAlpha = 0.7f;
        private const float DisplayLoopMinSwingFrequency = 3.2f;
        private const float DisplayLoopMaxSwingFrequency = 6.8f;
        private static readonly AnimationCurve DisplayLoopShrinkExpandEase = new AnimationCurve(
            new Keyframe(0f, 0f, 0f, 1.8f),
            new Keyframe(0.25f, 0.12f, 0.9f, 0.9f),
            new Keyframe(0.75f, 0.88f, 0.9f, 0.9f),
            new Keyframe(1f, 1f, 1.8f, 0f));

        protected override string AssetPath => "Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/ActSplashQuestExitNode.prefab";
        public int Priority => 210;
        public int Group => 3;
        public int GroupMutex => 10;

        private UIText _descriptionText;
        private UIText _countText;
        private bool _hasReturnedStrongAnim;
        private Sequence _displayLoopSeq;
        private RectTransform _displayAnimRect;
        private CanvasGroup _displayAnimCanvasGroup;
        private Vector3 _displayAnimBaseLocalPos;
        private Vector3 _displayAnimBaseLocalEuler;
        private Vector3 _displayAnimBaseLocalScale;
        private float _displayAnimBaseAlpha;

        public UISplashQuestExitNode() : base()
        {
            RetainName = "SplashQuest";
        }

        public void Init(Transform parent)
        {
            OnOpen();
            RectTransform.SetParent(parent, false);
            InitComponent();
            RefreshUI();
            StartDisplayLoopAnim();
        }

        public void Dispose()
        {
            StopDisplayLoopAnim();
            base.OnClose();
        }

        public string GetPortraitAnimName()
        {
            if (_hasReturnedStrongAnim)
                return string.Empty;

            _hasReturnedStrongAnim = true;
            return RetainStrongAnim;
        }

        private void InitComponent()
        {
            _descriptionText = TransformUtils.Find<UIText>(Transform, "Detail/Describe");
            _countText = TransformUtils.Find<UIText>(Transform, "Detail/Icon/Count");
        }

        private void StartDisplayLoopAnim()
        {
            StopDisplayLoopAnim();
            var target = TransformUtils.Find<RectTransform>(Transform, "Detail/Icon");
            if (target == null)
            {
                target = RectTransform;
            }

            if (target == null)
            {
                return;
            }

            _displayAnimRect = target;
            _displayAnimCanvasGroup = target.GetComponent<CanvasGroup>();
            if (_displayAnimCanvasGroup == null)
            {
                _displayAnimCanvasGroup = target.gameObject.AddComponent<CanvasGroup>();
            }

            _displayAnimBaseLocalPos = _displayAnimRect.localPosition;
            _displayAnimBaseLocalEuler = _displayAnimRect.localEulerAngles;
            _displayAnimBaseLocalScale = _displayAnimRect.localScale;
            _displayAnimBaseAlpha = _displayAnimCanvasGroup.alpha;

            var fullDuration = DisplayLoopHalfDuration * 2f;
            var continuousSwingDuration = Mathf.Max(0f, fullDuration - DisplayLoopSettleDuration);
            var minScale = _displayAnimBaseLocalScale * DisplayLoopMinScale;
            var swingPhase = 0f;
            var lastElapsed = 0f;

            _displayLoopSeq = DOTween.Sequence();
            _displayLoopSeq.SetLink(target.gameObject);
            _displayLoopSeq.SetUpdate(true);
            _displayLoopSeq.SetLoops(-1, LoopType.Restart);
            _displayLoopSeq.Append(DOTween.To(() => 0f, elapsed =>
            {
                var deltaTime = elapsed - lastElapsed;
                lastElapsed = elapsed;

                var normalized = fullDuration > 0f ? elapsed / fullDuration : 0f;
                var shrinkPhase = 1f - Mathf.Abs(normalized * 2f - 1f);
                var shrinkT = DisplayLoopShrinkExpandEase.Evaluate(shrinkPhase);
                var swingFrequency = Mathf.Lerp(DisplayLoopMinSwingFrequency, DisplayLoopMaxSwingFrequency, shrinkT);
                swingPhase += deltaTime * swingFrequency * Mathf.PI * 2f;

                var swingSin = Mathf.Sin(swingPhase);
                var pos = _displayAnimBaseLocalPos;
                pos.x += swingSin * DisplayLoopSwingXOffset;
                _displayAnimRect.localPosition = pos;

                var euler = _displayAnimBaseLocalEuler;
                euler.z += swingSin * DisplayLoopWobbleZDeg;
                _displayAnimRect.localEulerAngles = euler;

                _displayAnimRect.localScale = Vector3.LerpUnclamped(_displayAnimBaseLocalScale, minScale, shrinkT);
                _displayAnimCanvasGroup.alpha = Mathf.Lerp(_displayAnimBaseAlpha, DisplayLoopMinAlpha, shrinkT);
            }, continuousSwingDuration, continuousSwingDuration).SetEase(Ease.Linear).OnStart(() =>
            {
                swingPhase = 0f;
                lastElapsed = 0f;
            }));
            _displayLoopSeq.Append(_displayAnimRect.DOLocalMove(_displayAnimBaseLocalPos, DisplayLoopSettleDuration).SetEase(Ease.OutSine));
            _displayLoopSeq.Join(_displayAnimRect.DOLocalRotate(_displayAnimBaseLocalEuler, DisplayLoopSettleDuration, RotateMode.Fast).SetEase(Ease.OutSine));
            _displayLoopSeq.Join(_displayAnimRect.DOScale(_displayAnimBaseLocalScale, DisplayLoopSettleDuration).SetEase(Ease.OutSine));
            _displayLoopSeq.Join(_displayAnimCanvasGroup.DOFade(_displayAnimBaseAlpha, DisplayLoopSettleDuration).SetEase(Ease.OutSine));
            _displayLoopSeq.AppendInterval(DisplayLoopPauseAfterCycle);
        }

        private void StopDisplayLoopAnim()
        {
            if (_displayLoopSeq != null)
            {
                _displayLoopSeq.Kill();
                _displayLoopSeq = null;
            }

            if (_displayAnimRect != null)
            {
                _displayAnimRect.localPosition = _displayAnimBaseLocalPos;
                _displayAnimRect.localEulerAngles = _displayAnimBaseLocalEuler;
                _displayAnimRect.localScale = _displayAnimBaseLocalScale;
                _displayAnimRect = null;
            }

            if (_displayAnimCanvasGroup != null)
            {
                _displayAnimCanvasGroup.alpha = _displayAnimBaseAlpha;
                _displayAnimCanvasGroup = null;
            }
        }

        private void RefreshUI()
        {
            var activity = ImplementHub.Instance.Get<IActivitySystem>().GetActivity<ActSplashQuest>();
            if (activity == null)
            {
                return;
            }

            if (activity.IsRetainDiamondPoolStage())
            {
                var shareCeil = Mathf.Max(0, activity.GetTotalDiamondCount());
                _descriptionText.SetLocale("str_id_TileUI_retain_SplashQuest3", args: shareCeil);
                _countText.SetText($"{activity.CurrentLevel() + 1}/{activity.MaxLevel()}");
            }
            else
            {
                _descriptionText.SetLocale("str_id_TileUI_retain_SplashQuest1");
                _countText.SetText($"{activity.CurrentLevel() + 1}/{activity.MaxLevel()}");
            }
        }

        public static bool Check()
        {
            var activity = ImplementHub.Instance.Get<IActivitySystem>().GetActivity<ActSplashQuest>();
            if (activity == null)
            {
                return false;
            }

            if (!activity.IsInRetainRunState())
            {
                return false;
            }

            return activity.GetRetainProgressPercent() >= RetainStrongProgressThreshold;
        }
    }
}
