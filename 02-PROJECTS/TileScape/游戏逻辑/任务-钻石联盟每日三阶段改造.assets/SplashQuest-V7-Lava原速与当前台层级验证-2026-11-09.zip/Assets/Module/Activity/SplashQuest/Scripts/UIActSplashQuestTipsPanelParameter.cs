namespace Module.Activity.SplashQuest
{
    public class UIActSplashQuestTipsPanelParameter
    {
        public SplashQuestTipsViewState ViewState = SplashQuestTipsViewState.Generic;
    }
    public class UIActSplashQuestHelpPanelParameter
    {
        public int PeriodId;
        public bool StartMatchOnClose;
    }
}
