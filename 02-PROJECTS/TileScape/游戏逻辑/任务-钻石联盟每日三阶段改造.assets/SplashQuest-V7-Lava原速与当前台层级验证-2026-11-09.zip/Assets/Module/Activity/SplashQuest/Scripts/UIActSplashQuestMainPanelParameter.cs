using UnityEngine.Events;

namespace Module.Activity.SplashQuest
{
    public class UIActSplashQuestMainPanelParameter
    {
        public bool FullPageClose = false;
        public bool ShowOpeningPopup = false;
        public UnityEvent CloseEvent = new UnityEvent();
    }
}
