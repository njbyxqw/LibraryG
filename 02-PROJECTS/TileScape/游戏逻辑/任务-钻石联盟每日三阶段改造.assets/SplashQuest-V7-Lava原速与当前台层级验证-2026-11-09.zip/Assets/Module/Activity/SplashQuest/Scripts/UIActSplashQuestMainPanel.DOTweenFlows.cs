using Interface.UI;
using Module.Activity.SplashQuest;
using Betta.Framework;
using BettaSDK;
using DG.Tweening;

using UnityEngine;

public partial class UIActSplashQuestMainPanel
{
    private int _successAnimCurrentLevelSnapshot = -1;
    private int _successAnimLastLevelSnapshot = -1;

    private void PlaySuccessAnim()
    {
        if (_seq != null)
        {
            _seq.Kill(true);
        }

        _successAnimCurrentLevelSnapshot = _activity.CurrentLevel();
        _successAnimLastLevelSnapshot = _activity.LastLevel();

        var curSection = _mapSections[_successAnimCurrentLevelSnapshot];
        var lastSection = _mapSections[_successAnimLastLevelSnapshot];

        var failNum = SplashQuestMotion.FailurePortraitCount(_animPortraits.Count, false);
        var target = curSection.ItemRoot;

        _allowSettleSuccessTapFastForward = !_activity.HasPendingWinRewardClaim();
        _hasFastForwardedSettleSuccessFlow = false;
        _settleSuccessInputLockedDuringFlow = !_allowSettleSuccessTapFastForward;

        _seq = DOTween.Sequence();
        _seq.SetLink(Transform.gameObject);
        AttachSettleSuccessSequenceKillHandler(_seq);
        if (_settleSuccessInputLockedDuringFlow)
        {
            UtilsInput.Enable(false);
            SetMainPanelCloseButtonsVisible(false, false);
        }
        else
        {
            SetMainPanelCloseButtonsVisible(true, true);
        }

        _isPlayingSettleSuccessFlow = true;
        AppendSuccessCoreSegment(_seq, lastSection, target, failNum);
        _seq.AppendInterval(0.1f);
        AppendSuccessSettleSegment(_seq);
    }

    private void AttachSettleSuccessSequenceKillHandler(Sequence seq)
    {
        seq.onKill += () =>
        {
            _isPlayingSettleSuccessFlow = false;
            ReleaseSettleSuccessInputLock();
        };
    }

    private void ReleaseSettleSuccessInputLock()
    {
        if (!_settleSuccessInputLockedDuringFlow)
        {
            return;
        }

        UtilsInput.Enable(true);
        _settleSuccessInputLockedDuringFlow = false;
    }

    private void PlayFailAnim()
    {
        _seq?.Kill(true);
        var failProgress = GetMapProgressForDisplay();
        var section = _mapSections[failProgress];
        var nextProgress = Mathf.Min(failProgress + 1, _activity.MaxLevel());
        var failNum = SplashQuestMotion.FailurePortraitCount(_animPortraits.Count, true) - 1;
        var survivorCount = _animPortraits.Count - failNum;
        _seq = DOTween.Sequence().SetLink(Transform.gameObject);
        UtilsInput.Enable(false);
        _settleSuccessInputLockedDuringFlow = true;
        _seq.onKill += ReleaseSettleSuccessInputLock;
        SetMainPanelCloseButtonsVisible(false, false);
        if (failProgress > 0 && nextProgress > failProgress)
        {
            for (var i = 0; i < survivorCount; i++)
            {
                _seq.Insert(0f, _animPortraits[i].JumpToNext(_mapSections[nextProgress].ItemRoot, 1 + i % 2));
            }
        }
        if (failProgress > 0 && nextProgress > failProgress && survivorCount > 0)
        {
            _seq.InsertCallback(SplashQuestMotion.JumpDuration(1),
                () => AttachPortraitGroup(_mapSections[nextProgress].ItemRoot));
        }
        var eliminationStart = SplashQuestMotion.EliminationStart(failProgress, true);
        AppendEliminationSegment(_seq, section, survivorCount, true, eliminationStart);
        if (section.CanSink)
        {
            _seq.Insert(SplashQuestMotion.SINK_START, section.PlaySink());
        }
        _seq.InsertCallback(eliminationStart + 0.5f, () =>
        {
            SetMainPanelCloseButtonsVisible(true, false);
            ReleaseSettleSuccessInputLock();
        });
        _seq.OnComplete(() =>
        {
            SetMainPanelCloseButtonsVisible(true, false);
            ReleaseSettleSuccessInputLock();
            TryHandleTimeoutFlow();
        });
    }

    private void AppendSuccessCoreSegment(Sequence seq, UISplashQuestMapSection lastSection,
        RectTransform target, int failNum)
    {
        if (_successAnimCurrentLevelSnapshot == _successAnimLastLevelSnapshot)
        {
            return;
        }
        var survivorCount = _animPortraits.Count - failNum;
        var jumpStart = seq.Duration();
        seq.Insert(jumpStart, _myAnimPortrait.JumpToNext(target));
        for (var i = 0; i < survivorCount; i++)
        {
            seq.Insert(jumpStart + SplashQuestMotion.SurvivorStart(_successAnimLastLevelSnapshot),
                _animPortraits[i].JumpToNext(target, 1 + i % 2));
        }
        seq.InsertCallback(jumpStart + SplashQuestMotion.JUMP_DURATION, () => AttachPortraitGroup(target));
        AppendEliminationSegment(seq, lastSection, survivorCount, false,
            jumpStart + SplashQuestMotion.EliminationStart(_successAnimLastLevelSnapshot, false));
        if (lastSection.CanSink)
        {
            seq.Insert(jumpStart + SplashQuestMotion.SINK_START, lastSection.PlaySink());
        }
        AppendProgressCounters(seq, jumpStart + SplashQuestMotion.COUNTER_START);
        seq.onKill += () =>
        {
            txt_LeftNum?.SetText(_activity.LeftNumOfPeople().ToString());
            txt_Progress?.SetText($"{_activity.CurrentLevel()}/{_activity.MaxLevel()}");
            trans_Effect_PenShe?.gameObject.SetActive(true);
            AttachPortraitGroup(target);
            _myAnimPortrait?.FastJump(target);
            for (var i = 0; i < _animPortraits.Count; i++)
            {
                if (i < survivorCount)
                {
                    _animPortraits[i].FastJump(target);
                }
                else
                {
                    _animPortraits[i].CompleteSink();
                }
            }
            _myAnimPortrait?.Transform.SetAsLastSibling();
            lastSection.Hide();
        };
    }

    private void AppendEliminationSegment(Sequence seq, UISplashQuestMapSection section, int survivorCount,
        bool includePlayer, float jumpStart)
    {
        var index = 0;
        var firstDirection = Random.Range(0, 2) == 0 ? -1 : 1;
        var platform = section.SinkParent;
        if (includePlayer)
        {
            seq.Insert(jumpStart, _myAnimPortrait.JumpOffPlatform(section.ItemRoot, firstDirection, platform));
            index++;
        }
        for (var i = survivorCount; i < _animPortraits.Count; i++)
        {
            var direction = index % 2 == 0 ? firstDirection : -firstDirection;
            seq.Insert(jumpStart, _animPortraits[i].JumpOffPlatform(section.ItemRoot, direction, platform));
            index++;
        }
    }

    private void AppendProgressCounters(Sequence seq, float start)
    {
        var maxLevel = _activity.MaxLevel();
        var counters = DOTween.Sequence();
        counters.Append(SplashQuestMotion.AnimateCounter(txt_Progress.transform,
            value => txt_Progress.SetText($"{value}/{maxLevel}"),
            _successAnimLastLevelSnapshot, _successAnimCurrentLevelSnapshot, false));
        counters.Append(SplashQuestMotion.AnimateCounter(txt_LeftNum.transform,
            value => txt_LeftNum.SetText(value.ToString()),
            _activity.LastLeftNumOfPeople(), _activity.LeftNumOfPeople(), true,
            () => trans_Effect_PenShe.gameObject.SetActive(true)));
        seq.Insert(start, counters);
    }

    private void SetProgressCountersVisible(bool visible)
    {
        txt_Progress.transform.parent.gameObject.SetActive(visible);
        txt_LeftNum.transform.parent.gameObject.SetActive(visible);
    }

    private void AppendSuccessSettleSegment(Sequence seq)
    {
        if (_activity.HasPendingWinRewardClaim())
        {
            seq.AppendCallback(() =>
            {
                ReleaseSettleSuccessInputLock();

                var param = new UIActSplashQuestWinPanelParameter();
                var count = Mathf.Min(Mathf.Min(_activity.LeftNumOfPeople() - 1, 5), _animPortraits.Count);
                for (var i = 0; i < count; i++)
                {
                    param.PortraitInfos.Add(_animPortraits[i].GetPortraitInfo());
                }

                _activity.OpenWinPanel(UIOperation.Click, param, _flow);
                _flow = null;
                UIManager.Instance.Close(this, UIOperation.Auto);
            });
        }

        seq.OnComplete(() =>
        {
            _isPlayingSettleSuccessFlow = false;
            ReleaseSettleSuccessInputLock();

            if (!_activity.HasPendingWinRewardClaim())
            {
                SetMainPanelCloseButtonsVisible(true, true);
                TryHandleTimeoutFlow();
            }
        });
    }

    private void TryHandleTimeoutFlow()
    {
        if (_timeoutHandled || !_activity.IsCurrentPeriod(_periodId) ||
            _activity.CurrentState != SplashQuestState.Timeout)
        {
            return;
        }
        _timeoutHandled = true;
        if (_activity.HasPendingWinRewardClaim() || _activity.HasPendingWinPresentation())
        {
            _activity.OpenWinPanel(UIOperation.Auto, token: _flow);
        }
        else
        {
            _activity.OpenTipsPanel(UIOperation.Auto, SplashQuestTipsViewState.Timeout, _flow);
        }
        _flow = null;
        UIManager.Instance.Close<UIActSplashQuestMainPanel>(UIOperation.Auto);
    }
}
