using Interface.Activity;
using Module.Activity.SplashQuest;
using System;
using Module.SplashQuest.Config;
using Betta.Framework;
using BettaSDK.Profile;

using BettaSDK;

using UnityEngine;

namespace Module.Activity
{
    public partial class ActSplashQuest
    {
        public SplashQuestState SplashQuestStateView
        {
            get
            {
                if (!IsActive() && State != ActivityState.Preview)
                {
                    return SplashQuestState.Finished;
                }

                if (State == ActivityState.Finished)
                {
                    return SplashQuestState.Finished;
                }

                var raw = _profile.State;
                if (!Enum.IsDefined(typeof(SplashQuestState), raw))
                {
                    return SplashQuestState.Ready;
                }

                return (SplashQuestState)raw;
            }
        }

        public SplashQuestMainViewState MainViewStateView
        {
            get
            {
                var v = (SplashQuestMainViewState)_profile.MainViewState;
                if (v < SplashQuestMainViewState.None || v > SplashQuestMainViewState.Timeout)
                {
                    return SplashQuestMainViewState.None;
                }

                return v;
            }
        }

        public SplashQuestStageViewState StageViewStateView
        {
            get
            {
                var v = (SplashQuestStageViewState)_profile.StageViewState;
                if (v < SplashQuestStageViewState.NoChange || v > SplashQuestStageViewState.Fail)
                {
                    return SplashQuestStageViewState.NoChange;
                }

                return v;
            }
        }

        public int RunSerial => _profile != null ? _profile.RunSerial : 0;

        public bool TryGetUserLayerSnapshot(out int userLayer)
        {
            userLayer = 0;

            if (_profile == null)
            {
                return false;
            }

            userLayer = _profile.UserLayer;
            return true;
        }

        public string GetTimeString()
        {
            if (State == ActivityState.Preview)
            {
                return LocaleManager.GetText("str_id_Start");
            }

            if (ActivityData == null || SplashQuestStateView == SplashQuestState.Timeout)
            {
                return LocaleManager.GetText("str_id_End");
            }

            if (ActivityData.TimeEnd > UtilsTime.TimeSeconds)
            {
                return Module.Utils.UtilsTimeString.FormatCountdownTime(ActivityData.TimeEnd - UtilsTime.TimeSeconds);
            }

            return LocaleManager.GetText("str_id_End");
        }

        public int NumOfPeople()
        {
            var stageCfg = GetCurrentStageCfg();
            return stageCfg != null ? stageCfg.PlayerNum : 0;
        }

        public int LeftNumOfPeople()
        {
            if (_profile != null && _profile.PendingWinStageId > 0)
            {
                return _profile.PendingWinPeople;
            }
            var stageCfg = GetCurrentStageCfg();
            if (stageCfg == null)
            {
                return 0;
            }
            if (_profile == null)
            {
                return stageCfg.PlayerNum;
            }

            var left = _profile.LeftNumOfPeople;
            if (left <= 0)
            {
                return stageCfg.PlayerNum;
            }

            return Mathf.Max(1, left);
        }

        public int LastLeftNumOfPeople()
        {
            if (_profile == null)
            {
                return LeftNumOfPeople();
            }

            if (!IsSettleLikeMainViewState())
            {
                return LeftNumOfPeople();
            }

            var lastLeft = _profile.LastLeftNumOfPeople;
            if (lastLeft > 0)
            {
                return lastLeft;
            }

            return LeftNumOfPeople();
        }

        public int MaxLevel()
        {
            var stageCfg = GetCurrentStageCfg();
            return stageCfg != null ? stageCfg.winNum : 0;
        }

        public int CurrentLevel()
        {
            return _profile != null ? Mathf.Max(0, _profile.WinCount) : 0;
        }

        public int FailProgressBeforeSettle()
        {
            return GetFailProgressBeforeSettleSnapshot();
        }

        public int LastLevel()
        {
            var current = CurrentLevel();
            if (!IsSettleLikeMainViewState())
            {
                return current;
            }

            return Mathf.Max(0, current - 1);
        }

        private bool IsSettleLikeMainViewState()
        {
            var viewState = MainViewStateView;
            return viewState == SplashQuestMainViewState.SettleSuccess ||
                   viewState == SplashQuestMainViewState.SettleFail ||
                   viewState == SplashQuestMainViewState.EnterRun;
        }

        public int GetTotalDiamondCount()
        {
            return ResolveDiamondReward(GetRawTotalDiamondCount());
        }

        public int GetRawTotalDiamondCount()
        {
            if (_profile != null && _profile.PendingWinStageId > 0)
            {
                return _profile.PendingWinPool;
            }
            var stageCfg = GetCurrentStageCfg();
            return stageCfg != null ? stageCfg.DiamondCount : 0;
        }

        public int GetDiamondRewardCountByStageIndex(int stageIndex)
        {
            var stageCfg = GetStageCfgByIndex(stageIndex);
            return ResolveDiamondReward(stageCfg != null ? stageCfg.DiamondCount : 0);
        }

        public int[][] GetCurrentStageRewardList()
        {
            return ResolveStageReward(GetCurrentStageCfg());
        }

        private static int[][] ResolveStageReward(Stage stageCfg)
        {
            return stageCfg?.Reward ?? System.Array.Empty<int[]>();
        }

        public int GetRetainLoseDiamondUpperBound()
        {
            if (!TryGetStages(out _, out _))
            {
                return 0;
            }

            if (_profile == null)
            {
                return 0;
            }

            var stageCfg = GetStageCfgByIndex(_profile.CurrentStageIndex);
            if (stageCfg == null)
            {
                return 0;
            }

            return stageCfg.DiamondCount;
        }

        public bool IsRetainDiamondPoolStage()
        {
            return GetRetainLoseDiamondUpperBound() > 0;
        }

        public int GetRetainDiamondShareCeil()
        {
            if (_profile != null && _profile.PendingWinStageId > 0)
            {
                return _profile.PendingWinReward;
            }
            var total = GetRetainLoseDiamondUpperBound();
            if (total <= 0)
            {
                return 0;
            }

            var left = LeftNumOfPeople();
            if (left <= 0)
            {
                return ResolveDiamondReward(Mathf.CeilToInt((float)total));
            }

            return ResolveDiamondReward(Mathf.CeilToInt((float)total / left));
        }

        private static int ResolveDiamondReward(int count)
        {
            return count;
        }

        public int GetRetainProgressPercent()
        {
            var maxLevel = MaxLevel();
            if (maxLevel <= 0)
            {
                return 0;
            }

            var currentLevel = Mathf.Clamp(GetRetainProgressLevel() + 1, 0, maxLevel);
            return Mathf.Clamp((int)(currentLevel * 100f / maxLevel), 0, 100);
        }

        public bool IsInRetainRunState()
        {
            if (!IsActive())
            {
                return false;
            }

            if (SplashQuestStateView == SplashQuestState.InRun)
            {
                return true;
            }

            return MainViewStateView == SplashQuestMainViewState.SettleFail &&
                   FailProgressBeforeSettle() > 0;
        }

        public bool IsInFailCooldown()
        {
            if (GetMainCfg()?.CDtime == 0)
            {
                _profile.FailCdEndTime = 0;
                return false;
            }
            if (!IsActive())
            {
                return false;
            }

            if (_profile == null)
            {
                return false;
            }

            var end = _profile.FailCdEndTime;
            if (end == 0)
            {
                return false;
            }

            var now = UtilsTime.TimeSeconds;
            if (now >= end)
            {
                _profile.FailCdEndTime = 0;
                return false;
            }

            return true;
        }

        public ulong GetFailCooldownRemainSeconds()
        {
            if (!IsInFailCooldown())
            {
                return 0;
            }

            var end = _profile != null ? _profile.FailCdEndTime : 0;
            var now = UtilsTime.TimeSeconds;
            return end > now ? (end - now) : 0;
        }

        private int GetRetainProgressLevel()
        {
            var failProgress = FailProgressBeforeSettle();
            if (MainViewStateView == SplashQuestMainViewState.SettleFail && failProgress > 0)
            {
                return failProgress;
            }

            return CurrentLevel();
        }

        public int GetCurrentStageIndex()
        {
            return _profile != null ? _profile.CurrentStageIndex : 0;
        }

        public int GetStageCount()
        {
            var mainCfg = GetMainCfg();
            if (mainCfg == null || mainCfg.stages == null)
            {
                return 0;
            }

            return mainCfg.stages.Length;
        }

        public string GetCurrentStageTitleLocaleKey()
        {
            return $"str_id_SplashQuest_StageTitle{GetCurrentStageIndex() + 1}";
        }

        /// <summary>
        /// 当前档位配置 winNum 在存档 Carry 中的上次是否通关（1 胜利，0 失败/默认）。
        /// </summary>
        public int GetLastIfPassForCurrentStage()
        {
            var stageCfg = GetCurrentStageCfg();
            if (stageCfg == null)
            {
                return 0;
            }

            return GetLastIfPassByWinNum(stageCfg.winNum);
        }

        /// <summary>
        /// 本期是否尚未开过局（未执行过 StartRun，RunSerial 仍为 0）。
        /// </summary>
        public bool IsFirstParticipationThisPeriod()
        {
            return RunSerial == 0;
        }

        /// <summary>
        /// 档位界面底部提示：非本期首次参加且存档中当前档位上次未通关（LastIfPass==0）时展示。
        /// </summary>
        public bool ShouldShowStageTips()
        {
            if (_profile == null)
            {
                return false;
            }

            if (IsTerminalStageState())
            {
                return false;
            }

            if (SplashQuestStateView == SplashQuestState.Finished ||
                SplashQuestStateView == SplashQuestState.Timeout)
            {
                return false;
            }

            if (SplashQuestStateView == SplashQuestState.InRun)
            {
                return false;
            }

            if (IsFirstParticipationThisPeriod())
            {
                return false;
            }

            return GetLastIfPassForCurrentStage() == 0;
        }
    }
}
