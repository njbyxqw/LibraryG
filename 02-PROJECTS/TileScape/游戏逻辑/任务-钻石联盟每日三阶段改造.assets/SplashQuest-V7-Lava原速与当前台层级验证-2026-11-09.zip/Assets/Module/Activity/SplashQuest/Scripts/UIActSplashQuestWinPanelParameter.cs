using System.Collections.Generic;

namespace Module.Activity.SplashQuest
{
    public class UIActSplashQuestWinPanelParameter
    {
        public List<int[]> PortraitInfos = new List<int[]>();
    }
}
