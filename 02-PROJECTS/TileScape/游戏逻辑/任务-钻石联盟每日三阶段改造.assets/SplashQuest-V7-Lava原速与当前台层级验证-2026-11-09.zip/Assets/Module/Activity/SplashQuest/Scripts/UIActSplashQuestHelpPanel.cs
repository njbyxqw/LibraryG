using DG.Tweening;
using BettaSDK;
using Interface.UI;
using Module.Activity.Flow;
using Module.Activity.SplashQuest;
using Betta.Framework;

public partial class UIActSplashQuestHelpPanel : UIWindow {
    private PanelFlowArgs? _flow;
    private object _openParameter;
    private DG.Tweening.Tween _periodTimer;
    private UIActSplashQuestHelpPanelParameter _parameter;
    private int _periodId;
    private Module.Activity.ActSplashQuest _activity;
    private UnityEngine.Transform Transform => RectTransform;
    public void SetFlow(PanelFlowArgs? flow) => _flow = flow;
    public override void OnOpen(params object[] args)
    {
        base.OnOpen(args);
        if (RectTransform == null) return;
        foreach (var argument in args)
        {
            if (argument is PanelFlowArgs flow) _flow = flow;
            else if (argument != null) _openParameter = argument;
        }
        AssembleUI();
        OnInit();
        RegisterEvents();
        OnShow();
    }
    public override void OnClose()
    {
        OnHide();
        UnRegisterEvents();

        var flow = _flow;
        _flow = null;
        if (flow.HasValue && flow.Value.Token.IsValid)
            flow.Value.Executor?.TokenFinished(flow.Value.Token);
        base.OnClose();
    }

    protected override string AssetPath => "Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/UIActSplashQuestHelpPanel.prefab";

    private void OnInit()
    {
        _parameter = _openParameter as UIActSplashQuestHelpPanelParameter;
        _activity = ImplementHub.Instance.Get<Interface.Activity.IActivitySystem>().GetActivity<Module.Activity.ActSplashQuest>();
        _periodId = _activity.PeriodId;
        if (_parameter != null && _parameter.StartMatchOnClose && _activity.IsCurrentPeriod(_parameter.PeriodId))
        {
            _activity.RecordHelpPop();
        }
    }

    private void OnShow()
    {
        RefreshUI();
        _periodTimer = DG.Tweening.DOVirtual.DelayedCall(1f, PollPeriod, false)
            .SetLoops(-1).SetLink(Transform.gameObject);
    }
    private void PollPeriod()
    {
        if (!_activity.IsCurrentPeriod(_periodId))
        {
            UIManager.Instance.Close(this, UIOperation.Auto);
            return;
        }
        _activity.CheckTimeOut();
        if (_activity.GetLeftTime() > 0)
        {
            return;
        }
        if (_parameter != null)
        {
            var continueMatch = _parameter.StartMatchOnClose;
            _parameter.StartMatchOnClose = false;
            if (!continueMatch)
            {
                UIManager.Instance.Close(this, UIOperation.Auto);
                return;
            }
        }
        var flow = _flow;
        _flow = null;
        UIManager.Instance.Close(this, UIOperation.Auto);
        UIManager.Instance.Close<UIActSplashQuestMainPanel>(UIOperation.Auto);
        _activity.TryOpenRoutedPanel(UIOperation.Auto, flow);
    }

    private void OnHide()
    {
        _periodTimer?.Kill();
        _periodTimer = null;
    }

    private void RegisterEvents()
    {
        btn_Close.onClick.AddListener(OnClickClose);
    }

    private void UnRegisterEvents()
    {
        btn_Close.onClick.RemoveListener(OnClickClose);
    }

    private void OnClickClose()
    {
        if (_parameter != null && _parameter.StartMatchOnClose)
        {
            _parameter.StartMatchOnClose = false;
            var flow = _flow;
            _flow = null;
            _activity.StartMatching(_parameter.PeriodId, flow);
        }
        UIManager.Instance.Close<UIActSplashQuestHelpPanel>(UIOperation.Click);
    }

    private void RefreshUI()
    {
    }

}
