using Interface.UI;
using Interface.Flow;
using Interface.Item;
using Module.Activity.Flow;
using Interface.Activity;
using Module.Activity.SplashQuest;
using Module.SplashQuest.Config;
using Betta.Framework;
using BettaSDK;
using BettaSDK.Profile;

using System.Collections.Generic;

using UnityEngine;

namespace Module.Activity
{
    public partial class ActSplashQuest
    {
        private bool hasPendingPopup = false;
        private bool _claimInProgress;
        private bool _entryTipsPending;
        private IFlowScheduler _periodClosingScheduler;
        private int _observedPeriodId;
        private bool _loginExpiredPeriod;
        private bool _pendingPeriodOpening;
        private bool _waitForPeriodOpeningLevel;
        private bool _periodOpeningLevelStarted;
        private int _entryTipsVersion;
        internal int EntryTipsVersion => _entryTipsVersion;
        internal bool HasPendingEntryTips => _entryTipsPending && State == ActivityState.Open &&
            CurrentState != SplashQuestState.Timeout && CurrentState != SplashQuestState.Finished &&
            MainViewStateView == SplashQuestMainViewState.SettleSuccess;

        internal void CompleteEntryTips(int version)
        {
            if (version == _entryTipsVersion)
            {
                _entryTipsPending = false;
            }
        }

        protected override void OnProcessProfileData()
        {
            _profile = ProfileHub.Instance.GetProfile<ProfileActivity>().SplashQuest;
            if (State != ActivityState.None)
            {
                return;
            }

            State = ActivityState.Closed;
            _profile.ActivityData.Name = ActSplashQuest.ActivityId;
            _profile.ActivityData.ConfigId = 0;
            _profile.ActivityData.Version = 1;

            _profile.CurrentStageIndex = 0;
            CurrentState = SplashQuestState.Ready;
            _profile.MainViewState = (int)SplashQuestMainViewState.None;
            _profile.StageViewState = (int)SplashQuestStageViewState.NoChange;
            _profile.LevelTypeList.Clear();
            _profile.JewelUseList.Clear();
            _profile.PromotionStageClaimedIds.Clear();
            _profile.DailyLoginPopupDayKey = -1;
            _profile.PostSettlePopupCountToday = 0;
            _profile.PostSettlePopupCountDayKey = -1;
            _profile.LevelsSinceLastSettle = 0;
            _profile.WinCount = 0;
            _profile.RunSerial = 0;
            _profile.HasPopCD = 0;
            _profile.PendingFlags = 0;
            _profile.TotalExtraFailNum = 0;
            _profile.CarryDataByWinNum.Clear();
            _profile.LeftNumOfPeople = 0;
            _profile.LastLeftNumOfPeople = 0;
            _profile.FailCdEndTime = 0;
            SetFailProgressBeforeSettleSnapshot(0);
            ResetPeopleRuleState();
        }

        protected override void OnInitialize()
        {
            CancelPeriodOpeningContinuation();
            _periodClosingScheduler = null;
            _observedPeriodId = PeriodId;
            _loginExpiredPeriod = EndTime > 0 && GetLeftTime() == 0;
            _pendingPeriodOpening = false;
            _waitForPeriodOpeningLevel = false;
            _periodOpeningLevelStarted = false;
            _popupFlow.Register();
            _nextStagePopupFlow.Register();
            MessageDispatch.Instance.AddEventListener<int>(Interface.Game.SplashQuestGameMessages.ReviveDiamondSpent, OnDiamondConsume);
        }

        protected override void OnRelease()
        {
            CancelPeriodOpeningContinuation();
            _periodClosingScheduler = null;
            _entryTipsPending = false;
            _pendingPeriodOpening = false;
            _waitForPeriodOpeningLevel = false;
            _periodOpeningLevelStarted = false;
            _popupFlow.Unregister();
            _nextStagePopupFlow.Unregister();
            MessageDispatch.Instance.RemoveEventListener<int>(Interface.Game.SplashQuestGameMessages.ReviveDiamondSpent, OnDiamondConsume);
            _entryProxy = null;
        }

        protected override void OnPreview(ActivityState fromState)
        {
            // 先不做预览面板，入口侧会展示锁态即可
        }

        protected override void OnOpen(ActivityState fromState)
        {
            CancelPeriodOpeningContinuation();
            _entryTipsPending = false;
            _profileReady = false;

            RefreshAndStoreUserLayerForThisPeriod();
            ValidateConfigs();

            var isNextPeriod = _observedPeriodId > 0 && _observedPeriodId != PeriodId;
            ResetForNewPeriod();
            _pendingPeriodOpening = isNextPeriod;
            _waitForPeriodOpeningLevel = isNextPeriod && !_loginExpiredPeriod;
            _periodOpeningLevelStarted = false;
            _observedPeriodId = PeriodId;
            _loginExpiredPeriod = false;
            _markForPopup = !_waitForPeriodOpeningLevel;

            DispatchRefreshActivityUi();
        }

        private void RefreshAndStoreUserLayerForThisPeriod()
        {
            if (_profile != null && ImplementHub.Instance.TryGet(out Interface.UserLayer.IUserLayerSystem layers))
            {
                _profile.UserLayer = layers.RefreshLayer("SplashQuest");
            }
        }

        protected override void OnActive(ActivityState fromState)
        {

            TryRepairProfileAgainstMainConfig();
        }

        protected override void OnFinished(ActivityState fromState)
        {
            _entryTipsPending = false;

            // 活动自然结束时不强制清档；下次开启由 OnOpen 重置（需求：跨期从档位一重新挑战）
            TryRemoveSplashQuestMainEntry();
        }

        private bool CanActive()
        {
            if (HasPendingWinRewardClaim() || HasPendingWinPresentation() || HasPendingTimeoutPopup())
            {
                return true;
            }

            if (MainViewStateView == SplashQuestMainViewState.SettleFail ||
                MainViewStateView == SplashQuestMainViewState.SettleSuccess)
            {
                return true;
            }

            if (StageViewStateView != SplashQuestStageViewState.NoChange)
            {
                return true;
            }

            if (CurrentState == SplashQuestState.Finished || CurrentState == SplashQuestState.Timeout)
            {
                return false;
            }

            if (IsAllRewardsClaimed())
            {
                return false;
            }

            return true;
        }

        private bool NeedToWaitForClaim()
        {
            if (ActivityData == null || ActivityData.TimeEnd == 0)
            {
                return false;
            }

            return HasPendingWinRewardClaim() || HasPendingWinPresentation() || HasPendingTimeoutPopup() || (CurrentState != SplashQuestState.Finished && CurrentState != SplashQuestState.Timeout);
        }

        private void TryRemoveSplashQuestMainEntry()
        {
            _entryProxy?.RemoveEntry(ActivityId);
        }

        protected override void OnLifecycleTick(float deltaTime, string reason)
        {
            if (!_profileReady && IsActive() && AreDlcAssetsReady())
            {
                if (_profile.UserLayer <= 0) RefreshAndStoreUserLayerForThisPeriod();
                if (_profile.UserLayer > 0 && GetMainCfg() != null)
                {
                    ValidateConfigs();
                    TryRepairProfileAgainstMainConfig();
                    _profileReady = true;
                }
            }
            if (!IsActive())
            {
                return;
            }

            CheckTimeOut();
            // 登录强弹：由活动逻辑控制进入 ToDo 队列
            TryMarkLoginForcePopup();
            if (_periodClosingScheduler != null)
            {
                if (!ImplementHub.Instance.TryGet(out IFlowScheduler scheduler) ||
                    !ReferenceEquals(scheduler, _periodClosingScheduler) || _waitForPeriodOpeningLevel)
                {
                    CancelPeriodOpeningContinuation();
                    _periodClosingScheduler = null;
                }
                else if (_pendingPeriodOpening)
                {
                    ContinueHomePopupFlow(null);
                }
            }
        }

        public bool PopupIsNecessary()
        {
            return true;
        }

        public bool NeedGoHome()
        {
            return CanPopup() && CurrentState == SplashQuestState.Ready && _profile != null &&
                   UtilsTime.TimeSeconds > _profile.FailCdEndTime && _profile.HasPopCD == 0;
        }

        public bool CanPopup()
        {
            if (IsWaitingForClaim)
            {
                return true;
            }

            if (State != ActivityState.Open)
            {
                return false;
            }

            if (_waitForPeriodOpeningLevel)
            {
                return false;
            }

            // 主动弹窗兜底：杀端前存在待恢复流程，或仍有待领取奖励时，允许活动弹窗恢复流程。
            if (_profile != null && _profile.PendingFlags != 0)
            {
                return true;
            }

            if (MainViewStateView == SplashQuestMainViewState.SettleFail ||
                MainViewStateView == SplashQuestMainViewState.SettleSuccess)
            {
                return true;
            }

            if (_markForPopup)
            {
                return true;
            }

            if (CurrentState == SplashQuestState.InRun)
            {
                return UtilsTime.TimeSeconds >= ActivityData.TimeEnd;
            }
            else if (CurrentState == SplashQuestState.Ready && _profile != null && UtilsTime.TimeSeconds > _profile.FailCdEndTime)
            {
                if (_profile.HasPopCD == 0 && _profile.RunSerial == 0)
                {
                    return true;
                }
                var dayKey = UtilsTime.GetDays(UtilsTime.TimeSeconds);

                if (_profile.PostSettlePopupCountDayKey != dayKey)
                {
                    _profile.LevelsSinceLastSettle = 0;
                }
                if (GetMainConfig() != null && _profile.LevelsSinceLastSettle >= GetMainConfig().postSettleForcePopupAfterLevels)
                {
                    hasPendingPopup = true;
                    return true;
                }
                else if (_profile.RunSerial == 0)
                {
                    return true;
                }
            }
            else if (CurrentState == SplashQuestState.Timeout)
            {
                return HasPendingTimeoutPopup();
            }

            return false;
        }

        public bool Check(PanelFlowArgs? token)
        {
            CheckTimeOut();
            if (!CanPopup())
            {
                return false;
            }

            if (hasPendingPopup)
            {
                var dayKey = UtilsTime.GetDays(UtilsTime.TimeSeconds);

                if (_profile.PostSettlePopupCountDayKey == dayKey)
                {
                    _profile.PostSettlePopupCountToday++;
                }
                hasPendingPopup = false;
            }

            _markForPopup = false;
            if (CurrentState == SplashQuestState.Ready &&
                MainViewStateView != SplashQuestMainViewState.SettleFail &&
                UtilsTime.TimeSeconds > _profile.FailCdEndTime)
            {
                _profile.HasPopCD = 1;
            }

            var result = TryOpenRoutedPanel(UIOperation.Auto, token);
            if (result)
            {
                _profile.LevelsSinceLastSettle = 0;
            }
            return result;
        }

        public void RefreshEntry(Interface.UIEntry.IEntryCreateProxy proxy)
        {
            _entryProxy = proxy;
            if (proxy == null) return;
            if (CanShowEntry()) proxy.Create<UIActSplashQuestEntry>();
            else proxy.RemoveEntry(ActivityId);
        }
        internal void RemoveEntry() => _entryProxy?.RemoveEntry(ActivityId);

        public void OnGameStateChanged(string gameName, string gameState)
        {
            if (gameName != "TileMatch") return;
            if (gameState == "Start")
            {
                CancelPeriodOpeningContinuation();
                _periodClosingScheduler = null;
            }
            if (!IsActive())
            {
                return;
            }

            CheckTimeOut();
            if (CurrentState == SplashQuestState.Timeout || CurrentState == SplashQuestState.Finished)
            {
                return;
            }

            if (_waitForPeriodOpeningLevel)
            {
                if (gameState == "Start")
                {
                    _periodOpeningLevelStarted = true;
                }
                else if (_periodOpeningLevelStarted &&
                    (gameState is "Succeeded" or "QuitFailed" or "GiveUpReviveFailed"))
                {
                    _periodOpeningLevelStarted = false;
                    _waitForPeriodOpeningLevel = false;
                    _markForPopup = true;
                }
                return;
            }

            if (CurrentState != SplashQuestState.InRun)
            {
                // 不在挑战中：用于“结算后 n 关强弹”计数
                if (gameState is "Succeeded" or "QuitFailed" or "GiveUpReviveFailed")
                {
                    OnAnyLevelFinishedOutsideActivity();
                }
                return;
            }

            if (gameState == "Succeeded")
            {
                OnLevelSucceeded();
                if (MainViewStateView == SplashQuestMainViewState.SettleSuccess)
                {
                    _entryTipsVersion++;
                    _entryTipsPending = true;
                }
            }
            else if (gameState == "Start")
            {
                OnRunLevelStart();
            }
            else if (gameState is "QuitFailed" or "GiveUpReviveFailed")
            {
                OnLevelFailed();
            }
        }

        public void StartRun()
        {
            CheckTimeOut();
            if (HasPendingWinRewardClaim() || HasPendingWinPresentation() || GetLeftTime() == 0)
            {
                return;
            }
            if (!IsActive())
            {
                return;
            }

            if (IsInFailCooldown())
            {
                return;
            }

            if (CurrentState == SplashQuestState.Timeout)
            {
                return;
            }

            if (CurrentState == SplashQuestState.InRun)
            {
                return;
            }

            TryRepairProfileWhenJudgingNextRound();

            if (IsAllRewardsClaimed())
            {
                SetState(SplashQuestState.Ready);
                SetStageViewState(SplashQuestStageViewState.NoChange);

                SetFailProgressBeforeSettleSnapshot(0);
                DispatchRefreshActivityUi();
                return;
            }

            var stageCfg = GetCurrentStageCfg();
            if (stageCfg == null)
            {
                return;
            }
            var lastIfPass = GetLastIfPassByWinNum(stageCfg.winNum);
            UtilsLog.L($"[SplashQuest][Flow][StartRun] stageId={stageCfg.id}, winNum={stageCfg.winNum}, diamondCount={stageCfg.DiamondCount}, lastIfPass={lastIfPass}");
            ResetPeopleRuleState();
            SetState(SplashQuestState.InRun);
            SetMainViewState(SplashQuestMainViewState.EnterRun);
            SetStageViewState(SplashQuestStageViewState.NoChange);

            SetFailProgressBeforeSettleSnapshot(0);
            ClearPerRunWinCountAndJewelLists();

            InitRunPeopleRule(stageCfg, lastIfPass);
            _profile.RunSerial++;
            ClearPeriodOpeningInvitation();

            // 跨轮次清理每日弹窗上限
            _profile.PostSettlePopupCountToday = 0;
            _markForPopup = false;
            hasPendingPopup = false;
            _profile.PendingFlags &= ~PendingFlagNextStageOpening;
            _profile.HasPopCD = 1;

            TrackEvent(1);
        }

        private void ClearStageRunState()
        {
            if (_profile == null)
            {
                return;
            }

            ResetPeopleRuleState();
            SetFailProgressBeforeSettleSnapshot(0);
            ClearPerRunWinCountAndJewelLists();

            _profile.LeftNumOfPeople = 0;
            _profile.LastLeftNumOfPeople = 0;
        }

        private void OnLevelSucceeded()
        {
            TrackEvent(CurrentLevel() + 1 >= MaxLevel() ? 3 : 2);

            ApplyPeopleRuleAndAdvance(false);
            var currentLevel = CurrentLevel();

            if (currentLevel >= MaxLevel())
            {
                AfterSettle(isWin: true);
            }
            else
            {
                SetMainViewState(SplashQuestMainViewState.SettleSuccess);
                SetStageViewState(SplashQuestStageViewState.NoChange);
                DispatchRefreshActivityUi();
            }
        }

        private void OnLevelFailed()
        {
            var failProgressBeforeSettle = CurrentLevel();
            TrackEvent(4);
            SetFailProgressBeforeSettleSnapshot(failProgressBeforeSettle);
            ApplyPeopleRuleAndAdvance(true);
            _profile.WinCount = 0;
            MarkFailCooldownOnLose();
            AfterSettle(isWin: false);
        }

        private void MarkFailCooldownOnLose()
        {
            if (_profile == null)
            {
                return;
            }

            _profile.HasPopCD = 0;
            var cdSeconds = Mathf.Max(0, GetMainCfg().CDtime);
            if (cdSeconds <= 0)
            {
                _profile.FailCdEndTime = 0;
                return;
            }

            var now = UtilsTime.TimeSeconds;
            _profile.FailCdEndTime = now + (ulong)cdSeconds;
            _profile.HasPopCD = 0;
        }

        private void AfterSettle(bool isWin = true)
        {
            // 用真实结算结果写入，下一次 StartRun 计算期望人数使用
            SaveCurrentStageCarryLastIfPass(isWin ? 1 : 0);
            var stageCfg = GetCurrentStageCfg();
            if (stageCfg != null)
            {
                UtilsLog.L($"[SplashQuest][Flow][AfterSettle] stageId={stageCfg.id}, winNum={stageCfg.winNum}, isWin={isWin}, winCount={_profile.WinCount}, leftPeople={_profile.LeftNumOfPeople}");
            }
            SetState(SplashQuestState.Ready);
            SetMainViewState(isWin
                ? SplashQuestMainViewState.SettleSuccess
                : SplashQuestMainViewState.SettleFail);
            if (isWin)
            {
                SetFailProgressBeforeSettleSnapshot(0);
                MarkPendingWinRewardClaim();
                SetStageViewState(SplashQuestStageViewState.Success);
            }
            else
            {
                SetStageViewState(SplashQuestStageViewState.Fail);
            }

            _profile.LevelsSinceLastSettle = 0;

            if (IsAllRewardsClaimed())
            {
                SetStageViewState(SplashQuestStageViewState.NoChange);
            }
            PersistActivityState();
            DispatchRefreshActivityUi();
        }

        private void OnAnyLevelFinishedOutsideActivity()
        {
            if (!IsActive())
            {
                return;
            }

            var mainCfg = GetMainCfg();
            if (mainCfg == null)
            {
                return;
            }

            if (mainCfg.postSettleForcePopupAfterLevels <= 0)
            {
                return;
            }

            var dayKey = UtilsTime.GetDays(UtilsTime.TimeSeconds);
            var dailyLimit = Mathf.Max(0, mainCfg.postSettleForcePopupDailyLimit);
            if (dailyLimit == 0)
            {
                return;
            }

            if (_profile.PostSettlePopupCountDayKey != dayKey)
            {
                _profile.PostSettlePopupCountDayKey = dayKey;
                _profile.PostSettlePopupCountToday = 0;
                _profile.LevelsSinceLastSettle = 0;
            }

            if (_profile.PostSettlePopupCountToday >= dailyLimit)
            {
                return;
            }

            _profile.LevelsSinceLastSettle++;
        }

        public void ApplyStageProgressAfterWinClaim()
        {
            if (!HasPendingWinPresentation() || _profile.PendingWinPeriodId != PeriodId)
            {
                return;
            }
            var completedIndex = _profile.PendingWinStageIndex;
            _profile.PendingFlags &= ~PendingFlagWinPresentation;
            ClearWinRewardSnapshot();
            SetMainViewState(SplashQuestMainViewState.None);
            SetStageViewState(SplashQuestStageViewState.NoChange);

            ClearStageRunState();
            _markForPopup = false;
            if (IsAllRewardsClaimed())
            {
                Finish();
                return;
            }
            if (CurrentState != SplashQuestState.Timeout && GetLeftTime() > 0)
            {
                _profile.CurrentStageIndex = completedIndex;
                AdvanceStage();
                SetState(SplashQuestState.Ready);
                _profile.PendingFlags |= PendingFlagNextStageOpening;
                hasPendingPopup = false;
            }
            PersistActivityState();
            DispatchRefreshActivityUi();
        }

        public void ClaimCurrentStageWinReward()
        {
            if (!HasPendingWinRewardClaim() || _claimInProgress)
            {
                return;
            }
            EnsureWinRewardSnapshot();
            if (_profile.PendingWinStageId <= 0 || _profile.PendingWinReward <= 0 ||
                _profile.PendingWinPeriodId != PeriodId)
            {
                return;
            }
            if (IsPromotionStageClaimed(_profile.PendingWinStageId))
            {
                _profile.PendingFlags = (_profile.PendingFlags & ~PendingFlagWinReward) | PendingFlagWinPresentation;
                PersistActivityState();
                return;
            }
            _claimInProgress = true;
            try
            {
                var rewards = new[] { new[] { (int)ITEM_ID.DIAMOND, _profile.PendingWinReward } };
                if (!GrantRewards(rewards, "act_splashquest_" + (_profile.PendingWinStageIndex + 1)))
                {
                    return;
                }
                MarkPromotionStageClaimed(_profile.PendingWinStageId);
                _profile.PendingFlags = (_profile.PendingFlags & ~PendingFlagWinReward) | PendingFlagWinPresentation;
                if (IsAllRewardsClaimed())
                {
                    _profile.PendingFlags &= ~PendingFlagTimeout;
                    SetState(SplashQuestState.Ready);
                }
                PersistActivityState();
                DispatchRefreshActivityUi();
            }
            finally
            {
                _claimInProgress = false;
            }
        }

        private void ResetForNewPeriod()
        {
            _profile.CurrentStageIndex = 0;
            SetState(SplashQuestState.Ready);
            _profile.MainViewState = (int)SplashQuestMainViewState.None;
            _profile.StageViewState = (int)SplashQuestStageViewState.NoChange;

            SetFailProgressBeforeSettleSnapshot(0);
            _profile.FailCdEndTime = 0;
            _profile.LevelTypeList.Clear();
            _profile.DailyLoginPopupDayKey = -1;
            _profile.PostSettlePopupCountToday = 0;
            _profile.PostSettlePopupCountDayKey = -1;
            _profile.LevelsSinceLastSettle = 0;
            _profile.WinCount = 0;
            _profile.RunSerial = 0;
            _profile.HasPopCD = 0;
            _profile.PendingFlags = 0;
            ClearWinRewardSnapshot();
            _profile.CarryDataByWinNum.Clear();
            ResetPeopleRuleState();
            _profile.PromotionStageClaimedIds.Clear();
        }

        private void SetState(SplashQuestState s)
        {
            CurrentState = s;
        }

        private void SetMainViewState(SplashQuestMainViewState s)
        {
            _profile.MainViewState = (int)s;
        }

        private void SetStageViewState(SplashQuestStageViewState s)
        {
            _profile.StageViewState = (int)s;
        }
    }
}
