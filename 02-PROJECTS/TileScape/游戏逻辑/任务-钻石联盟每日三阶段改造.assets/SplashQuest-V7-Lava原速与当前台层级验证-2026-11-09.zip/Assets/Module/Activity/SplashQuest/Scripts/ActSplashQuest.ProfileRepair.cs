using Module.Activity.SplashQuest;
using UnityEngine;

namespace Module.Activity
{
    public partial class ActSplashQuest
    {
        private void TryRepairProfileAgainstMainConfig()
        {
            if (CurrentState != SplashQuestState.InRun)
            {
                TryRepairProfileWhenJudgingNextRound();
            }
        }

        private void TryRepairProfileWhenJudgingNextRound()
        {
            if (_profile == null)
            {
                return;
            }
            _profile.PendingFlags &= PendingFlagWinReward | PendingFlagTimeout | PendingFlagWinPresentation;
            if (!TryGetStages(out _, out var stages))
            {
                return;
            }
            _profile.CurrentStageIndex = Mathf.Clamp(_profile.CurrentStageIndex, 0, stages.Length - 1);
            var claims = _profile.PromotionStageClaimedIds;
            for (var i = claims.Count - 1; i >= 0; i--)
            {
                var valid = false;
                for (var j = 0; j < stages.Length; j++)
                {
                    if (claims[i] == stages[j])
                    {
                        valid = true;
                        break;
                    }
                }
                for (var j = 0; j < i; j++)
                {
                    if (claims[j] == claims[i])
                    {
                        valid = false;
                        break;
                    }
                }
                if (!valid)
                {
                    claims.RemoveAt(i);
                }
            }
            if (HasPendingWinRewardClaim())
            {
                EnsureWinRewardSnapshot();
            }
        }
    }
}
