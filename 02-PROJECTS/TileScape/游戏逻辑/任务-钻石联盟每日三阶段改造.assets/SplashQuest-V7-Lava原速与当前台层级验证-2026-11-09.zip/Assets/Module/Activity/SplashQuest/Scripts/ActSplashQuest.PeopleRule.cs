using System;
using System.Collections.Generic;
using Module.Activity.SplashQuest;
using Module.SplashQuest.Config;
using BettaSDK;
using BettaSDK.Profile;

using UnityEngine;

namespace Module.Activity
{
    public partial class ActSplashQuest
    {
        private int _expectPeople = -1;
        private int _leftPeople;
        private int _lastLeftPeople;
        private int _lastLevel;
        private int _totalJewelUsed;
        private int _totalExtraFailNum;
        private int _jewelUse;

        private void LogExpectPeopleCalc(Stage stageCfg, int userLayer, int carryBucketWinNum, string methodName, int lastIfPass,
            int lastExpectPeople, int lastTotalJewelUsed, int resultExpectPeople)
        {
            var stageId = stageCfg == null ? 0 : stageCfg.id;
            var stageWinNum = stageCfg == null ? 0 : stageCfg.winNum;
            UtilsLog.L(
                "[SplashQuest][PeopleRule][ExpectCalc]\n" +
                $"  [Scope] stageId={stageId}, stageWinNum={stageWinNum}, userLayer={userLayer}, carryBucketWinNum={carryBucketWinNum}, fromCarryDataByWinNum=true\n" +
                $"  [Method] {methodName}\n" +
                $"  [Input] lastIfPass={lastIfPass}, lastExpectPeople={lastExpectPeople}, lastTotalJewelUsed={lastTotalJewelUsed}\n" +
                $"  [Output] expectPeople={resultExpectPeople}");
        }

        private void LogFailPeopleCalc(Stage stageCfg, int userLayer, int carryBucketWinNum, string methodName, int level, int expectPeople,
            int levelTypeCount, int jewelUseCount, int totalJewelUsedBefore, int currentTotalExtraFailNum, int currentLeftPeople,
            ActSplashQuestProcessData resultData)
        {
            var stageId = stageCfg == null ? 0 : stageCfg.id;
            var stageWinNum = stageCfg == null ? 0 : stageCfg.winNum;
            UtilsLog.L(
                "[SplashQuest][PeopleRule][FailCalc]\n" +
                $"  [Scope] stageId={stageId}, stageWinNum={stageWinNum}, userLayer={userLayer}, carryBucketWinNum={carryBucketWinNum}, fromCarryDataByWinNum=true\n" +
                $"  [Method] {methodName}\n" +
                $"  [Input] level={level}, expectPeople={expectPeople}, levelTypeCount={levelTypeCount}, jewelUseCount={jewelUseCount}, totalJewelUsed={totalJewelUsedBefore}, currentTotalExtraFailNum={currentTotalExtraFailNum}, currentLeftPeople={currentLeftPeople}\n" +
                $"  [Output] failPeopleNum={resultData.FailPeopleNum}, totalJewelUsed={resultData.TotalJewelUsed}, totalExtraFailNum={resultData.TotalExtraFailNum}");
        }

        public void RecordShowData()
        {
            if (_profile == null)
            {
                return;
            }

            // 记录展示帧时的“上次剩余人数”，供动画/展示使用。
            _profile.LastLeftNumOfPeople = _profile.LeftNumOfPeople;
            _lastLevel = CurrentLevel();
        }

        public ulong HelpLastPopTime()
        {
            return _profile != null ? _profile.HelpLastPopTime : 0;
        }

        public void RecordHelpPop()
        {
            if (_profile == null)
            {
                return;
            }

            _profile.HelpLastPopTime = UtilsTime.TimeSeconds;
        }

        public bool CanSkipMatchPanelAnim()
        {
            return _profile != null && _profile.MatchPanelAnimSeen != 0;
        }

        public void RecordMatchPanelAnimSeen()
        {
            if (_profile == null || _profile.MatchPanelAnimSeen != 0)
            {
                return;
            }

            _profile.MatchPanelAnimSeen = 1;
        }

        private void ResetPeopleRuleState()
        {
            _expectPeople = -1;
            _leftPeople = 0;
            _lastLeftPeople = 0;
            _lastLevel = 0;
            _totalJewelUsed = 0;
            _totalExtraFailNum = 0;
            _jewelUse = 0;
        }

        private void InitRunPeopleRule(Stage stageCfg, int lastIfPass)
        {
            if (stageCfg == null)
            {
                return;
            }

            _profile.TotalExtraFailNum = 0;
            _profile.JewelUseList.Clear();

            var carryData = GetOrCreateCarryDataByWinNum(stageCfg.winNum);
            var lastTotalJewelUsed = carryData.TotalJewelUsed;
            var lastExpectPeople = carryData.ExpectPeople;
            var useDiamondRule = stageCfg.DiamondCount != 0;
            var expectMethod = stageCfg.DiamondCount == 0 ? "GetExpectPeopleNoDiamond" : "GetExpectPeople";
            var userLayer = _profile != null ? _profile.UserLayer : 0;
            _expectPeople = stageCfg.DiamondCount == 0
                ? GetExpectPeopleNoDiamond(stageCfg, lastIfPass, lastExpectPeople)
                : GetExpectPeople(stageCfg, lastIfPass, lastTotalJewelUsed, lastExpectPeople);
            carryData.ExpectPeople = _expectPeople;
            LogExpectPeopleCalc(stageCfg, userLayer, stageCfg.winNum, expectMethod, lastIfPass, lastExpectPeople, lastTotalJewelUsed, _expectPeople);
            UtilsLog.L($"[SplashQuest][PeopleRule][InitRun] stageId={stageCfg.id}, winNum={stageCfg.winNum}, diamondCount={stageCfg.DiamondCount}, useDiamondRule={useDiamondRule}, lastIfPass={lastIfPass}, carryExpect={lastExpectPeople}, carryTotalJewel={lastTotalJewelUsed}, newExpect={_expectPeople}");

            _leftPeople = stageCfg.PlayerNum;
            _lastLeftPeople = _leftPeople;
            _profile.LeftNumOfPeople = _leftPeople;
            _profile.LastLeftNumOfPeople = _leftPeople;
            _lastLevel = 0;

            _totalJewelUsed = lastTotalJewelUsed;
            _totalExtraFailNum = 0;

            _profile.LevelTypeList.Clear();
            _profile.LevelTypeList.AddRange(GetLevelTypeList(stageCfg.winNum));
        }

        private void OnRunLevelStart()
        {
            _jewelUse = 0;
        }

        private void OnDiamondConsume(int count)
        {
            if (CurrentState != SplashQuestState.InRun)
            {
                return;
            }

            _jewelUse += Mathf.Abs(count);
        }

        private void ApplyPeopleRuleAndAdvance(bool includePlayerFail)
        {
            var stageCfg = GetCurrentStageCfg();
            if (stageCfg == null)
            {
                return;
            }

            var level = CurrentLevel();
            var carryData = GetOrCreateCarryDataByWinNum(stageCfg.winNum);
            var expectPeople = carryData.ExpectPeople;
            var totalJewelUsedBefore = carryData.TotalJewelUsed;
            var currentTotalExtraFailNum = _profile.TotalExtraFailNum;
            if (_profile.JewelUseList.Count == 0)
            {
                _profile.JewelUseList.Add(_jewelUse + totalJewelUsedBefore);
            }
            else
            {
                _profile.JewelUseList.Add(_jewelUse);
            }

            var useDiamondRule = stageCfg.DiamondCount != 0;
            var failMethod = stageCfg.DiamondCount == 0 ? "GetFailPeopleNoDiamond" : "GetFailPeople";
            var userLayer = _profile != null ? _profile.UserLayer : 0;
            var processData = stageCfg.DiamondCount == 0
                ? GetFailPeopleNoDiamond(stageCfg, expectPeople, level, _profile.LevelTypeList, totalJewelUsedBefore, currentTotalExtraFailNum, _profile.LeftNumOfPeople)
                : GetFailPeople(stageCfg, expectPeople, level, _profile.LevelTypeList, _profile.JewelUseList,
                    totalJewelUsedBefore, currentTotalExtraFailNum);
            LogFailPeopleCalc(stageCfg, userLayer, stageCfg.winNum, failMethod, level, expectPeople,
                _profile.LevelTypeList == null ? 0 : _profile.LevelTypeList.Count,
                _profile.JewelUseList == null ? 0 : _profile.JewelUseList.Count, totalJewelUsedBefore,
                currentTotalExtraFailNum, _profile.LeftNumOfPeople, processData);

            var failNum = Mathf.Max(0, processData.FailPeopleNum) + (includePlayerFail ? 1 : 0);

            _lastLeftPeople = _profile.LeftNumOfPeople;
            _profile.LastLeftNumOfPeople = _lastLeftPeople;
            _profile.LeftNumOfPeople = Mathf.Max(1, _profile.LeftNumOfPeople - failNum);
            _leftPeople = _profile.LeftNumOfPeople;

            _totalExtraFailNum = processData.TotalExtraFailNum;
            _profile.TotalExtraFailNum = _totalExtraFailNum;
            _totalJewelUsed = processData.TotalJewelUsed;
            carryData.TotalJewelUsed = _totalJewelUsed;
            UtilsLog.L($"[SplashQuest][PeopleRule][Advance] stageId={stageCfg.id}, winNum={stageCfg.winNum}, level={level}, includePlayerFail={includePlayerFail}, useDiamondRule={useDiamondRule}, expect={expectPeople}, failCore={processData.FailPeopleNum}, failFinal={failNum}, leftBefore={_lastLeftPeople}, leftAfter={_profile.LeftNumOfPeople}, totalExtraFail={_totalExtraFailNum}, totalJewelBefore={totalJewelUsedBefore}, totalJewelAfter={_totalJewelUsed}");
            if (!includePlayerFail)
            {
                _profile.WinCount = Mathf.Max(0, _profile.WinCount + 1);
            }

            _lastLevel = level;

            _jewelUse = 0;
        }

        private int GetLastIfPassByWinNum(int winNum)
        {
            if (_profile == null || _profile.CarryDataByWinNum == null)
            {
                UtilsLog.L($"[SplashQuest][CarryData][GetLastIfPass] winNum={winNum}, hit=false, reason=profile_or_dict_null");
                return 0;
            }

            if (_profile.CarryDataByWinNum.TryGetValue(winNum, out var carryData))
            {
                UtilsLog.L($"[SplashQuest][CarryData][GetLastIfPass] winNum={winNum}, hit=true, lastIfPass={carryData.LastIfPass}, expect={carryData.ExpectPeople}, totalJewel={carryData.TotalJewelUsed}");
                return carryData.LastIfPass;
            }

            UtilsLog.L($"[SplashQuest][CarryData][GetLastIfPass] winNum={winNum}, hit=false, reason=missing_bucket");
            return 0;
        }

        private void SaveCurrentStageCarryLastIfPass(int lastIfPass)
        {
            var stageCfg = GetCurrentStageCfg();
            if (stageCfg == null)
            {
                return;
            }

            var carryData = GetOrCreateCarryDataByWinNum(stageCfg.winNum);
            carryData.LastIfPass = lastIfPass;
            UtilsLog.L($"[SplashQuest][CarryData][SaveLastIfPass] stageId={stageCfg.id}, winNum={stageCfg.winNum}, lastIfPass={lastIfPass}, expect={carryData.ExpectPeople}, totalJewel={carryData.TotalJewelUsed}");
        }

        private SplashQuestCarryData GetOrCreateCarryDataByWinNum(int winNum)
        {
            if (_profile.CarryDataByWinNum == null)
            {
                _profile.CarryDataByWinNum.Clear();
                UtilsLog.L("[SplashQuest][CarryData][GetOrCreate] create dict");
            }

            if (_profile.CarryDataByWinNum.TryGetValue(winNum, out var carryData))
            {
                UtilsLog.L($"[SplashQuest][CarryData][GetOrCreate] winNum={winNum}, hit=true, lastIfPass={carryData.LastIfPass}, expect={carryData.ExpectPeople}, totalJewel={carryData.TotalJewelUsed}");
                return carryData;
            }

            carryData = new SplashQuestCarryData
            {
                LastIfPass = 0,
                TotalJewelUsed = 0,
                ExpectPeople = -1
            };
            _profile.CarryDataByWinNum[winNum] = carryData;
            UtilsLog.L($"[SplashQuest][CarryData][GetOrCreate] winNum={winNum}, hit=false, create_default=true");
            return carryData;
        }

        private int GetExpectPeople(Stage stageCfg, int lastIfPass, int lastTotalJewelUsed, int lastExpectPeople)
        {
            if (lastExpectPeople == -1)
            {
                lastExpectPeople = stageCfg.UserSegmentationExpect;
            }
            else
            {
                if (lastIfPass == 1)
                {
                    lastExpectPeople = Mathf.Max(
                        Mathf.Min(lastExpectPeople + stageCfg.AdjustIntensity, stageCfg.MaxExpectNum),
                        stageCfg.MinExpectNum);
                }

                if (lastIfPass == 0 && lastTotalJewelUsed > 200)
                {
                    lastExpectPeople = Mathf.Max(
                        Mathf.Min(lastExpectPeople - stageCfg.AdjustIntensity, stageCfg.MaxExpectNum),
                        stageCfg.MinExpectNum);
                }
            }

            return UnityEngine.Random.Range(Mathf.Max(stageCfg.MinExpectNum, lastExpectPeople - 1),
                Mathf.Min(stageCfg.MaxExpectNum, lastExpectPeople + 1));
        }

        private int GetExpectPeopleNoDiamond(Stage stageCfg, int lastIfPass, int lastExpectPeople)
        {
            var minExpect = Mathf.Min(stageCfg.MinExpectNum, stageCfg.MaxExpectNum);
            var maxExpect = Mathf.Max(stageCfg.MinExpectNum, stageCfg.MaxExpectNum);
            if (minExpect == maxExpect)
            {
                return minExpect;
            }

            // 无钻石奖励分支：直接在配置上下界内随机期望人数。
            return UnityEngine.Random.Range(minExpect, maxExpect + 1);
        }

        private ActSplashQuestProcessData GetFailPeople(Stage stageCfg, int expectPeople, int level, List<int> levelTypeList,
            ProfileList<int> jewelUseList, int totalJewelUsed, int currentTotalExtraFailNum)
        {
            if (stageCfg == null)
            {
                UtilsLog.E("[SplashQuest][PeopleRule][GetFailPeople] stageCfg is null, fallback to zero process data.");
                return new ActSplashQuestProcessData
                {
                    FailPeopleNum = 0,
                    TotalJewelUsed = totalJewelUsed,
                    TotalExtraFailNum = currentTotalExtraFailNum
                };
            }

            if (level < 0)
            {
                level = 0;
            }
            var totalLevelNum = stageCfg.winNum;
            if (totalLevelNum <= 0)
            {
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople] invalid stage winNum={stageCfg.winNum}, stageId={stageCfg.id}, fallback to zero process data.");
                return new ActSplashQuestProcessData
                {
                    FailPeopleNum = 0,
                    TotalJewelUsed = totalJewelUsed,
                    TotalExtraFailNum = currentTotalExtraFailNum
                };
            }
            if (level >= totalLevelNum)
            {
                level = totalLevelNum - 1;
            }
            expectPeople = Mathf.Max(1, expectPeople);
            var jewelNum = stageCfg.DiamondCount;
            var hasGuardFallback = false;

            if (levelTypeList == null)
            {
                hasGuardFallback = true;
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople][Guard] levelTypeList is null. stageId={stageCfg.id}, level={level}, totalLevelNum={totalLevelNum}");
                levelTypeList = new List<int>(totalLevelNum);
            }

            if (jewelUseList == null)
            {
                hasGuardFallback = true;
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople][Guard] jewelUseList is null. stageId={stageCfg.id}, level={level}, totalLevelNum={totalLevelNum}");
                jewelUseList = new ProfileList<int>();
            }

            if (stageCfg.LevelCoefList == null || stageCfg.LevelCoefList.Length == 0)
            {
                hasGuardFallback = true;
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople][Guard] LevelCoefList invalid. stageId={stageCfg.id}, level={level}, levelCoefLen={(stageCfg.LevelCoefList == null ? -1 : stageCfg.LevelCoefList.Length)}");
            }

            if (stageCfg.ExtraJewelCoef == null || stageCfg.ExtraJewelCoef.Length == 0)
            {
                hasGuardFallback = true;
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople][Guard] ExtraJewelCoef invalid. stageId={stageCfg.id}, level={level}, extraCoefLen={(stageCfg.ExtraJewelCoef == null ? -1 : stageCfg.ExtraJewelCoef.Length)}");
            }

            var avgDiff = Mathf.Pow(1 / ((float)expectPeople / stageCfg.PlayerNum), 1f / totalLevelNum);

            var failPropList = new List<float>(totalLevelNum);
            for (var i = 0; i < totalLevelNum; i++)
            {
                var failProp = 1 / Mathf.Pow(avgDiff, i) * (1 - 1 / avgDiff);
                failPropList.Add(failProp);
            }

            var coefList = new List<float>(totalLevelNum);
            for (var i = 0; i < totalLevelNum; i++)
            {
                var safeLevelType = 0;
                if (i < levelTypeList.Count)
                {
                    safeLevelType = levelTypeList[i];
                }
                else
                {
                    hasGuardFallback = true;
                    UtilsLog.E(
                        $"[SplashQuest][PeopleRule][GetFailPeople][Guard] levelTypeList index out of range. stageId={stageCfg.id}, level={level}, needIndex={i}, levelTypeCount={levelTypeList.Count}, totalLevelNum={totalLevelNum}");
                }

                var safeCoef = 1f;
                if (stageCfg.LevelCoefList != null && stageCfg.LevelCoefList.Length > 0)
                {
                    var clampedLevelType = Mathf.Clamp(safeLevelType, 0, stageCfg.LevelCoefList.Length - 1);
                    if (clampedLevelType != safeLevelType)
                    {
                        hasGuardFallback = true;
                        UtilsLog.E(
                            $"[SplashQuest][PeopleRule][GetFailPeople][Guard] levelType exceeds LevelCoefList range. stageId={stageCfg.id}, level={level}, levelType={safeLevelType}, clamped={clampedLevelType}, levelCoefLen={stageCfg.LevelCoefList.Length}");
                    }

                    safeCoef = stageCfg.LevelCoefList[clampedLevelType];
                }

                coefList.Add(safeCoef);
            }

            float sum1 = 0;
            float sum2 = 0;
            for (var i = 0; i < failPropList.Count; i++)
            {
                sum1 += failPropList[i] * coefList[i];
                sum2 += failPropList[i];
            }

            var avgCoef = sum1 / sum2;
            var expectFailNumList = new List<int>(totalLevelNum);
            var sum3 = 0;
            for (var i = 0; i < totalLevelNum; i++)
            {
                if (i == totalLevelNum - 1)
                {
                    var expectFailNum = Mathf.Max(0, stageCfg.PlayerNum - expectPeople - sum3);
                    expectFailNumList.Add(expectFailNum);
                    sum3 += expectFailNum;
                }
                else
                {
                    var safeCoef = i < coefList.Count ? coefList[i] : 1f;
                    if (i >= coefList.Count)
                    {
                        hasGuardFallback = true;
                        UtilsLog.E(
                            $"[SplashQuest][PeopleRule][GetFailPeople][Guard] coefList index out of range. stageId={stageCfg.id}, level={level}, index={i}, coefCount={coefList.Count}, fallbackCoef=1");
                    }

                    var expectFailNum =
                        Mathf.RoundToInt(safeCoef / avgCoef * failPropList[i] * stageCfg.PlayerNum);
                    expectFailNumList.Add(expectFailNum);
                    sum3 += expectFailNum;
                }
            }

            var extraFailNum = 0;
            var safeJewelUseAtLevel = 0;
            if (level < jewelUseList.Count)
            {
                safeJewelUseAtLevel = jewelUseList[level];
            }
            else
            {
                hasGuardFallback = true;
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople][Guard] jewelUseList index out of range. stageId={stageCfg.id}, level={level}, jewelUseCount={jewelUseList.Count}, fallbackValue=0");
            }

            var safeExtraCoefAtLevel = 0f;
            if (stageCfg.ExtraJewelCoef != null && stageCfg.ExtraJewelCoef.Length > 0)
            {
                var safeExtraCoefIndex = Mathf.Clamp(level, 0, stageCfg.ExtraJewelCoef.Length - 1);
                safeExtraCoefAtLevel = stageCfg.ExtraJewelCoef[safeExtraCoefIndex];
                if (safeExtraCoefIndex != level)
                {
                    hasGuardFallback = true;
                    UtilsLog.E(
                        $"[SplashQuest][PeopleRule][GetFailPeople][Guard] ExtraJewelCoef index out of range. stageId={stageCfg.id}, level={level}, clamped={safeExtraCoefIndex}, extraCoefLen={stageCfg.ExtraJewelCoef.Length}");
                }
            }

            if (expectPeople - currentTotalExtraFailNum > stageCfg.MinExpectNum &&
                safeJewelUseAtLevel * safeExtraCoefAtLevel + totalJewelUsed >
                (float)jewelNum / (expectPeople - currentTotalExtraFailNum - 1) -
                (float)jewelNum / (expectPeople - currentTotalExtraFailNum))
            {
                extraFailNum = 1;
            }

            var totalExtraFailNum = currentTotalExtraFailNum + extraFailNum;
            var failPeopleNum = expectFailNumList[level] + extraFailNum;

            float sum4 = 0;
            for (var i = 0; i <= level; i++)
            {
                var safeJewelUse = 0;
                if (i < jewelUseList.Count)
                {
                    safeJewelUse = jewelUseList[i];
                }
                else
                {
                    hasGuardFallback = true;
                    UtilsLog.E(
                        $"[SplashQuest][PeopleRule][GetFailPeople][Guard] jewelUseList sum index out of range. stageId={stageCfg.id}, level={level}, needIndex={i}, jewelUseCount={jewelUseList.Count}, fallbackValue=0");
                }

                var safeExtraCoef = 0f;
                if (stageCfg.ExtraJewelCoef != null && stageCfg.ExtraJewelCoef.Length > 0)
                {
                    var safeExtraCoefIndex = Mathf.Clamp(i, 0, stageCfg.ExtraJewelCoef.Length - 1);
                    safeExtraCoef = stageCfg.ExtraJewelCoef[safeExtraCoefIndex];
                    if (safeExtraCoefIndex != i)
                    {
                        hasGuardFallback = true;
                        UtilsLog.E(
                            $"[SplashQuest][PeopleRule][GetFailPeople][Guard] ExtraJewelCoef sum index out of range. stageId={stageCfg.id}, level={level}, needIndex={i}, clamped={safeExtraCoefIndex}, extraCoefLen={stageCfg.ExtraJewelCoef.Length}");
                    }
                }

                sum4 += safeJewelUse * safeExtraCoef;
            }

            totalJewelUsed = Mathf.RoundToInt(sum4 - (float)jewelNum / (expectPeople - totalExtraFailNum) +
                                              jewelNum / (float)expectPeople);
            if (hasGuardFallback)
            {
                UtilsLog.E(
                    $"[SplashQuest][PeopleRule][GetFailPeople][GuardSummary] stageId={stageCfg.id}, level={level}, totalLevelNum={totalLevelNum}, levelTypeCount={levelTypeList.Count}, jewelUseCount={jewelUseList.Count}, levelCoefLen={(stageCfg.LevelCoefList == null ? -1 : stageCfg.LevelCoefList.Length)}, extraCoefLen={(stageCfg.ExtraJewelCoef == null ? -1 : stageCfg.ExtraJewelCoef.Length)}, fallbackApplied=true");
            }

            return new ActSplashQuestProcessData
            {
                FailPeopleNum = failPeopleNum,
                TotalJewelUsed = totalJewelUsed,
                TotalExtraFailNum = totalExtraFailNum
            };
        }

        private ActSplashQuestProcessData GetFailPeopleNoDiamond(Stage stageCfg, int expectPeople, int level, List<int> levelTypeList,
            int totalJewelUsed, int currentTotalExtraFailNum, int currentLeftPeople)
        {
            if (level < 0)
            {
                level = 0;
            }
            var totalLevelNum = stageCfg.winNum;
            if (level >= totalLevelNum)
            {
                level = totalLevelNum - 1;
            }
            expectPeople = Mathf.Max(1, expectPeople);

            currentLeftPeople = Mathf.Clamp(currentLeftPeople, 1, stageCfg.PlayerNum);
            var remainNeedEliminate = Mathf.Max(0, currentLeftPeople - expectPeople);
            var remainLevels = Mathf.Max(1, totalLevelNum - level);

            int failPeopleNum;
            if (remainLevels == 1)
            {
                // 最后一关强制收敛，确保最终剩余人数精确等于期望人数。
                failPeopleNum = remainNeedEliminate;
            }
            else
            {
                var avgEliminate = remainNeedEliminate / remainLevels;
                var jitterMin = Mathf.Max(0, avgEliminate - 1);
                var jitterMax = Mathf.Min(remainNeedEliminate, avgEliminate + 1);
                failPeopleNum = UnityEngine.Random.Range(jitterMin, jitterMax + 1);
            }

            return new ActSplashQuestProcessData
            {
                FailPeopleNum = failPeopleNum,
                TotalJewelUsed = totalJewelUsed,
                TotalExtraFailNum = currentTotalExtraFailNum
            };
        }

        private List<int> GetLevelTypeList(int levelCount)
        {
            var result = new List<int>(levelCount);
            if (ImplementHub.Instance.Get<Interface.Game.ILeveledGame>() is Interface.Game.ISplashQuestGameData gameData)
            {
                gameData.TryGetUpcomingLevelTypes(levelCount, result);
            }
            return result;
        }

    }

    public struct ActSplashQuestProcessData
    {
        public int FailPeopleNum;
        public int TotalJewelUsed;
        public int TotalExtraFailNum;
    }

    public struct DiamondLevelHard
    {
        public int LevelHard;
        public int LevelType;
        public bool IsEndLessLevel;
        public bool IsTutorial;
    }
}
