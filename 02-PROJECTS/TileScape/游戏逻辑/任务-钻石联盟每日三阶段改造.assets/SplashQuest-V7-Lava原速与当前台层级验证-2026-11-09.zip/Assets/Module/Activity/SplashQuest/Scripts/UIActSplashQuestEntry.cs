using Module.Activity.EntryAnimation;
using DG.Tweening;
using Module.UIMain;
using Interface.UI;
using Module.Activity;
using TransformUtils = Module.Utils.UtilsTransform;
using System;
using Interface.Activity;
using Module.Activity.Message;
using Betta.Framework;
using BettaSDK;

using UnityEngine;
using UnityEngine.UI;

namespace Module.Activity.SplashQuest
{
    public class UIActSplashQuestEntry : UIEntryBase, IEntryAnimationDataSource, IEntryAnimationPlayer
    {
        private Transform Transform => RectTransform;

        protected override string AssetPath => "Assets/Module/Activity/SplashQuest/ResDLC/Default/Entry/ActSplashQuestEntry.prefab";
        public override string Name => ActSplashQuest.ActivityId;

        private Transform _root;
        private Transform _lockRoot;
        private Transform _unlockRoot;
        private Button _entryBtn;
        private UIText _timeLeft;
        private UIText _unlockText;

        private Slider _slider;

        private Transform _traTips;
        private UIText _txtTips;
        private UIText _txtStage;

        private ActSplashQuest _activity;

        private Tween _timerId = null;
        private Tween _tipsTimerId = null;
        private Action _tipsCompleted;
        private int _playingTipsVersion;
        private bool _playingTips;
        public string EntryId => Name;
        public IEntryAnimationPlayer Player => this;

        public override void OnOpen(params object[] args)
        {
            base.OnOpen(args);
            FindComponents();
            InitProperties();
            RegisterEvents();
            RefreshUI();
            EntryAnimationSourceRegistry.Register(this);
        }

        private void FindComponents()
        {
            _root = TransformUtils.Find<Transform>(Transform, "Root");
            _lockRoot = TransformUtils.Find<Transform>(Transform, "Root/LockRoot");
            _unlockRoot = TransformUtils.Find<Transform>(Transform, "Root/UnlockRoot");
            _entryBtn = Transform.GetComponent<UIButtonBetta>();
            _timeLeft = TransformUtils.Find<UIText>(Transform, "Root/UnlockRoot/Scale/TimeLeft");

            _unlockText = TransformUtils.Find<UIText>(Transform, "Root/LockRoot/Scale/TimeLeft");

            _slider = _unlockRoot.GetComponentInChildren<Slider>(true);

            _traTips = TransformUtils.Find<Transform>(Transform, "Root/UnlockRoot/tra_tips");
            _txtTips = TransformUtils.Find<UIText>(Transform, "Root/UnlockRoot/tra_tips/txt_tips");
            _txtStage = TransformUtils.Find<UIText>(Transform, "Root/UnlockRoot/tra_tips/stageBg/txt_stage");
        }

        private void InitProperties()
        {
            _activity = ImplementHub.Instance.Get<IActivitySystem>().GetActivity<ActSplashQuest>();
        }

        private void RegisterEvents()
        {
            _entryBtn.onClick.AddListener(OnClickEntry);
            MessageDispatch.Instance.AddEventListener<string>(ActivityMessageType.OpenActivity, OnOpen);
            MessageDispatch.Instance.AddEventListener<string>(ActivityMessageType.FinishActivity, OnFinish);
            MessageDispatch.Instance.AddEventListener<string>(ActivityMessageType.PauseActivity, OnPause);
            MessageDispatch.Instance.AddEventListener<string>(ActivityMessageType.ResumeActivity, OnResume);
            MessageDispatch.Instance.AddEventListener<string>(ActivityMessageType.RefreshActivityUI, OnRefresh);
        }

        private void UnRegisterEvents()
        {
            _entryBtn.onClick.RemoveListener(OnClickEntry);
            MessageDispatch.Instance.RemoveEventListener<string>(ActivityMessageType.OpenActivity, OnOpen);
            MessageDispatch.Instance.RemoveEventListener<string>(ActivityMessageType.FinishActivity, OnFinish);
            MessageDispatch.Instance.RemoveEventListener<string>(ActivityMessageType.PauseActivity, OnPause);
            MessageDispatch.Instance.RemoveEventListener<string>(ActivityMessageType.ResumeActivity, OnResume);
            MessageDispatch.Instance.RemoveEventListener<string>(ActivityMessageType.RefreshActivityUI,
                OnRefresh);
        }

        private void OnRefresh(string activityName)
        {
            if (activityName == ActSplashQuest.ActivityId)
            {
                RefreshUI();
            }
        }

        private void OnOpen(string activityName)
        {
            if (activityName == ActSplashQuest.ActivityId)
            {
                Show();
            }
        }

        private void OnFinish(string activityName)
        {
            if (activityName == ActSplashQuest.ActivityId)
            {
                Hide();
            }
        }

        private void OnPause(string activityName)
        {
            if (activityName == ActSplashQuest.ActivityId)
            {
                Hide();
            }
        }

        private void OnResume(string activityName)
        {
            if (activityName == ActSplashQuest.ActivityId)
            {
                Show();
            }
        }

        public override void OnClose()
        {
            EntryAnimationSourceRegistry.Unregister(this);
            Cancel();
            UnRegisterEvents();
            ClearActivityTimer();
            ClearTipsTimer();
            base.OnClose();
        }

        private void ClearActivityTimer()
        {
            if (_timerId != null)
            {
                _timerId?.Kill();
                _timerId = null;
            }
        }

        private void ClearTipsTimer()
        {
            if (_tipsTimerId != null)
            {
                _tipsTimerId?.Kill();
                _tipsTimerId = null;
            }
        }

        private void OnClickEntry()
        {
            _activity.CheckTimeOut();
            if (_activity.TryOpenRoutedPanel(UIOperation.Click))
            {
                return;
            }

            MessageDispatch.Instance.Dispatch(ActivityMessageType.RefreshActivityUI, Name);
        }

        public void RefreshUI()
        {
            if (_activity.CanShowEntry())
            {
                Show();
            }
            else
            {
                Hide();
            }
        }

        private void Show()
        {
            ClearActivityTimer();
            _root.gameObject.SetActive(true);
            _entryBtn.enabled = true;

            if (_activity.State == ActivityState.Preview)
            {
                _lockRoot.gameObject.SetActive(true);
                _unlockRoot.gameObject.SetActive(false);
                _unlockText.SetLocale("str_id_UnlockLevel",
                    args: ImplementHub.Instance.Get<IActivitySystem>().GetActivity<ActSplashQuest>()
                        .OpenLevel);
                return;
            }

            ShowUnlockContent();
        }

        private void ShowUnlockContent()
        {
            _lockRoot.gameObject.SetActive(false);
            _unlockRoot.gameObject.SetActive(true);

            if (_traTips != null && !_playingTips)
            {
                _traTips.gameObject.SetActive(false);
            }

            ApplyUnlockPhasePresentation();
            ApplyTimeLeftText();
            _timerId = DOVirtual.DelayedCall(1, () =>
            {
                if (_activity.State == ActivityState.None || _activity.State == ActivityState.Finished)
                {
                    ClearActivityTimer();
                    return;
                }

                if (!_activity.CanShowEntry())
                {
                    ClearActivityTimer();
                    _activity.RemoveEntry();
                    return;
                }

                ApplyTimeLeftText();
                ApplyUnlockPhasePresentation();

                RefreshRedDot();

            }, false).SetLoops(-1).SetLink(Transform.gameObject);

            RefreshRedDot();
        }

        private void RefreshRedDot()
        {
            if (_activity == null)
            {
                return;
            }

            var showRedDot = _activity.CanJoinCurrentStage() && !_activity.IsInFailCooldown();
            ImplementHub.Instance.Get<Interface.RedDot.IRedDot>()?.Set(ActSplashQuest.ActivityId, showRedDot ? 1 : 0);
        }

        private bool ShouldShowActivityFinishedEarly()
        {
            var ad = _activity.ActivityData;
            if (ad == null || ad.TimeEnd == 0)
            {
                return false;
            }

            if (UtilsTime.TimeSeconds >= ad.TimeEnd)
            {
                return false;
            }

            return _activity.State == ActivityState.Finished || _activity.State == ActivityState.Closed;
        }

        private void ApplyTimeLeftText()
        {
            if (ShouldShowActivityFinishedEarly())
            {
                _timeLeft.SetLocale("str_id_Activity_Finished");
                return;
            }

            if (_activity != null && _activity.IsInFailCooldown())
            {
                _timeLeft.SetLocale("str_id_Activity_coolDown");
                return;
            }

            if (_activity.IsFirstParticipationThisPeriod() || _activity.SplashQuestStateView == SplashQuestState.Ready)
            {
                _timeLeft.SetLocale("str_id_Activity_start");
                return;
            }

            var ad = _activity.ActivityData;
            if (ad == null || ad.TimeEnd == 0)
            {
                _timeLeft.SetLocale("str_id_Activity_End");
                return;
            }

            ulong now = UtilsTime.TimeSeconds;
            if (ad.TimeEnd > now)
            {
                _timeLeft.text = Module.Utils.UtilsTimeString.FormatCountdownTime(ad.TimeEnd - now);
                return;
            }

            _timeLeft.SetLocale("str_id_Activity_End");
        }

        private void ApplyUnlockPhasePresentation()
        {
            var runState = _activity.SplashQuestStateView;
            switch (runState)
            {
                case SplashQuestState.Ready:
                    _slider.gameObject.SetActive(true);
                    _slider.value = 0f;
                    break;
                case SplashQuestState.InRun:
                    ApplySliderForInRunOrTimeout();
                    break;
                case SplashQuestState.Timeout:
                    ApplySliderForInRunOrTimeout();
                    break;
                default:
                    _slider.gameObject.SetActive(false);
                    break;
            }
        }

        private void ApplySliderForInRunOrTimeout()
        {
            _slider.gameObject.SetActive(true);
            var maxLevel = _activity.MaxLevel();
            _slider.value = maxLevel > 0
                ? Mathf.Clamp01((float)_activity.CurrentLevel() / maxLevel)
                : 0f;

        }

        public bool NeedsAnimation()
        {
            return !_playingTips && _activity != null && _activity.HasPendingEntryTips &&
                RectTransform != null && RectTransform.gameObject.activeInHierarchy &&
                _traTips != null && _txtTips != null && _txtStage != null;
        }

        public void CollectAnimationData(ref EntryAnimationDataWriter writer)
        {
            writer.Duration = 1.5f;
            writer.Side = RectTransform.position.x >= 0f ? EntryAnimationSide.Right : EntryAnimationSide.Left;
            writer.VerticalOrder = RectTransform.GetSiblingIndex();
            writer.HasCover = true;
            writer.CoverRectTransform = _traTips as RectTransform;
            writer.PreferLeftOnSameRow = true;
            int version = _activity.EntryTipsVersion;
            writer.Suppressed = () => _activity.CompleteEntryTips(version);
        }

        public float Play(EntryAnimationPlayContext context, Action completed)
        {
            if (!NeedsAnimation() || _activity.MaxLevel() <= 0)
            {
                _activity?.CompleteEntryTips(_activity.EntryTipsVersion);
                completed?.Invoke();
                return 0f;
            }

            _playingTipsVersion = _activity.EntryTipsVersion;
            _playingTips = true;
            _tipsCompleted = completed;
            _txtTips.SetLocale(_activity.GetCurrentStageTitleLocaleKey());
            _txtStage.SetText($"{_activity.CurrentLevel()}/{_activity.MaxLevel()}");
            _traTips.gameObject.SetActive(true);
            _tipsTimerId = DOVirtual.DelayedCall(1.5f, FinishTips, false).SetLink(Transform.gameObject);
            return 0f;
        }

        public void Cancel()
        {
            FinishTips();
        }

        private void FinishTips()
        {
            ClearTipsTimer();
            if (_traTips != null)
            {
                _traTips.gameObject.SetActive(false);
            }
            if (_playingTips)
            {
                _activity?.CompleteEntryTips(_playingTipsVersion);
                _playingTips = false;
            }
            var completed = _tipsCompleted;
            _tipsCompleted = null;
            completed?.Invoke();
        }

        private void Hide()
        {
            Cancel();
            _root.gameObject.SetActive(false);
            ClearActivityTimer();
            ClearTipsTimer();
            _entryBtn.enabled = false;

            _activity.RemoveEntry();
        }
    }
}
