using System.Collections.Generic;
using BettaSDK;
using Module.Activity.SplashQuest;
using UnityEngine;

public partial class UIActSplashQuestMainPanel
{
    private Transform _portraitGroupOriginalParent;
    private int _portraitGroupOriginalSibling;
    private Vector3 _portraitGroupOriginalPosition;
    private Vector3 _portraitGroupOriginalScale;
    private Quaternion _portraitGroupOriginalRotation;

    private void CapturePortraitGroupLayout()
    {
        _portraitGroupOriginalParent = trans_ItemParent.parent;
        _portraitGroupOriginalSibling = trans_ItemParent.GetSiblingIndex();
        _portraitGroupOriginalPosition = trans_ItemParent.localPosition;
        _portraitGroupOriginalScale = trans_ItemParent.localScale;
        _portraitGroupOriginalRotation = trans_ItemParent.localRotation;
    }

    private void AttachPortraitGroup(Transform target)
    {
        trans_ItemParent.SetParent(target, true);
        var offset = trans_ItemParent.InverseTransformVector(trans_ItemParent.position - target.position);
        trans_ItemParent.position = target.position;
        for (var i = 0; i < trans_ItemParent.childCount; i++)
        {
            trans_ItemParent.GetChild(i).localPosition += offset;
        }
    }

    private void RestorePortraitGroupLayout()
    {
        if (_portraitGroupOriginalParent == null)
        {
            return;
        }
        trans_ItemParent.SetParent(_portraitGroupOriginalParent, false);
        trans_ItemParent.SetSiblingIndex(_portraitGroupOriginalSibling);
        trans_ItemParent.localPosition = _portraitGroupOriginalPosition;
        trans_ItemParent.localScale = _portraitGroupOriginalScale;
        trans_ItemParent.localRotation = _portraitGroupOriginalRotation;
        _portraitGroupOriginalParent = null;
    }

    private void InitMap()
    {
        var maxLevel = _activity.MaxLevel();
        var progress = GetMapProgressForDisplay();
        _mapSections = new List<UISplashQuestMapSection>(maxLevel + 1);
        for (var level = 0; level <= maxLevel; level++)
        {
            var path = level == 0 ? "Bottom" : level == maxLevel ? "Top" : $"Middle/Level_{level}";
            var section = new UISplashQuestMapSection(trans_MapRoot.Find(path), _activity, level, maxLevel);
            if (level < progress)
            {
                section.Hide();
            }
            _mapSections.Add(section);
        }

        txt_RewardPool.SetText(_activity.GetTotalDiamondCount().ToString());
        Canvas.ForceUpdateCanvases();
    }

    private void InitAvatars()
    {
        CapturePortraitGroupLayout();
        _animPortraits = new List<UIActSplashQuestAnimPortrait>();
        var count = trans_ItemParent.childCount;
        var leftNum = _activity.LastLeftNumOfPeople() - 1;
        for (int i = count - 1; i >= 0; i--)
        {
            var trans = trans_ItemParent.GetChild(i);
            if (trans.name == "MyPortrait")
            {
                _myAnimPortrait = new UIActSplashQuestAnimPortrait(trans);
                var playerInfo = ImplementHub.Instance.Get<Interface.PlayerInfo.IPlayerInfo>();
                _myAnimPortrait.Show(playerInfo.GetAvatarId(), playerInfo.GetFrameId(), 0);
                _myAnimPortrait.SetPosition(_myAnimPortrait.Transform.GetComponent<RectTransform>().anchoredPosition);
            }
            else if (i > count - 1 - leftNum)
            {
                var portrait = new UIActSplashQuestAnimPortrait(trans);
                portrait.ShowRandom();
                portrait.SetPosition(portrait.Transform.GetComponent<RectTransform>().anchoredPosition);
                _animPortraits.Add(portrait);
            }
            else
            {
                trans.gameObject.SetActive(false);
            }
        }

        _myAnimPortrait.Transform.SetAsLastSibling();
        var itemParent = _mapSections[GetMapProgressForDisplay()].ItemRoot;
        trans_ItemParent.position = itemParent.position;
        AttachPortraitGroup(itemParent);
    }

    private int GetMapProgressForDisplay()
    {
        if (_activity.MainViewStateView == SplashQuestMainViewState.SettleFail)
        {
            return Mathf.Clamp(_activity.FailProgressBeforeSettle(), 0, _activity.MaxLevel());
        }

        return Mathf.Clamp(_activity.LastLevel(), 0, _activity.MaxLevel());
    }
}
