using System;
using System.IO;
using System.Threading.Tasks;
using System.Reflection;
using BettaSDK.Profile;
using DG.Tweening;
using Module.Activity;
using Module.Activity.SplashQuest;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;
public static class SplashMotionSequencePreviewV7
{
 public static async Task<string> Run()
 {
  var field=typeof(DOTween).GetField("initialized",BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic);
  var previous=field.GetValue(null);field.SetValue(null,true);
  try {
  Directory.CreateDirectory("Temp/SplashQuestUI/frames-v7");
  await Render(5, false, false); await Render(5, true, false); await Render(5, true, true); await Render(7, false, false, 2);
  return "Rendered success, failure and starting failure to frames-v7";
  } finally { field.SetValue(null,previous); }
 }
 static async Task Render(int levels, bool failed, bool starting, int previousProgress = 1)
 {
  var previousScene=SceneManager.GetActiveScene();
  var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);
  var go=(GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/UIActSplashQuestMainPanel_"+levels+".prefab"),scene);
  PrefabUtility.UnpackPrefabInstance(go,PrefabUnpackMode.Completely,InteractionMode.AutomatedAction);
  var cameraGo=new GameObject("MotionPreviewCamera",typeof(Camera));
  SceneManager.MoveGameObjectToScene(cameraGo,go.scene);
  var camera=cameraGo.GetComponent<Camera>();
  go.SetActive(true);camera.scene=go.scene;camera.overrideSceneCullingMask=EditorSceneManager.GetSceneCullingMask(go.scene);
  camera.orthographic=true;camera.orthographicSize=960;camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(.05f,.12f,.2f);camera.transform.position=new Vector3(0,0,-100);camera.nearClipPlane=.1f;camera.farClipPlane=3000;
  var rt=new RenderTexture(540,960,24);camera.targetTexture=rt;
  var canvas=go.GetComponent<Canvas>();if(canvas==null)canvas=go.AddComponent<Canvas>();
  canvas.renderMode=RenderMode.WorldSpace;canvas.worldCamera=camera;
  ((RectTransform)go.transform).sizeDelta=new Vector2(1080,1920);
  go.transform.position=Vector3.zero;go.transform.localScale=Vector3.one;
  var scaler=go.GetComponent<CanvasScaler>();if(scaler!=null)scaler.enabled=false;
  canvas.scaleFactor=.5f;
  foreach(var a in go.GetComponentsInChildren<Animator>(true))a.enabled=false;
  foreach(var cg in go.GetComponentsInChildren<CanvasGroup>(true))cg.alpha=1;
  EditorApplication.QueuePlayerLoopUpdate();
  await Task.Delay(150);
  Canvas.ForceUpdateCanvases();
  var map=go.transform.Find("Content/trans_MapRoot");
  var parent=go.transform.Find("Content/trans_ItemParent");
  var activity=new ActSplashQuest(ActSplashQuest.ActivityId);
  typeof(ActSplashQuest).GetField("_profile",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(activity,new SplashQuestData{CurrentStageIndex=levels==5?0:levels==7?1:2});
  var old=new UISplashQuestMapSection(map.Find(starting?"Bottom":"Middle/Level_"+previousProgress),activity,starting?0:previousProgress,levels);
  var target=map.Find("Middle/Level_"+(previousProgress+1)+"/Root/Background/ItemRoot");
  var panel=new UIActSplashQuestMainPanel();
  var flags=BindingFlags.Instance|BindingFlags.NonPublic;
  var panelType=panel.GetType();
  panelType.GetField("trans_ItemParent",flags).SetValue(panel,parent);
  panelType.GetMethod("CapturePortraitGroupLayout",flags).Invoke(panel,null);
  parent.position=old.ItemRoot.position;
  panelType.GetMethod("AttachPortraitGroup",flags).Invoke(panel,new object[]{old.ItemRoot});
  var avatar=parent.Find("MyPortrait");
  var portrait=new UIActSplashQuestAnimPortrait(avatar);portrait.SetPosition(((RectTransform)avatar).anchoredPosition);
  var robots=new System.Collections.Generic.List<UIActSplashQuestAnimPortrait>();
  for(int c=parent.childCount-1;c>=0;c--) {var child=parent.GetChild(c);if(child==avatar)continue;child.gameObject.SetActive(true);var robot=new UIActSplashQuestAnimPortrait(child);robot.SetPosition(((RectTransform)child).anchoredPosition);robots.Add(robot);}
  avatar.SetAsLastSibling();
  var sequence=DOTween.Sequence().SetUpdate(UpdateType.Manual).SetAutoKill(false);
  var motion=typeof(UIActSplashQuestAnimPortrait).Assembly.GetType("Module.Activity.SplashQuest.SplashQuestMotion");
  int progress=starting?0:previousProgress;
  float survivorStart=failed?0f:(float)motion.GetMethod("SurvivorStart").Invoke(null,new object[]{progress});
  float fallStart=(float)motion.GetMethod("EliminationStart").Invoke(null,new object[]{progress,failed});
  float jumpStart=0f;
  int failCount=2;
  int robotFailCount=failCount-(failed?1:0);
  if(failed)sequence.Insert(fallStart,portrait.JumpOffPlatform(old.ItemRoot,-1,old.SinkParent));
  else sequence.Insert(jumpStart,portrait.JumpToNext(target));
  for(int r=0;r<robots.Count;r++) {
   if(r>=robots.Count-robotFailCount)sequence.Insert(fallStart,robots[r].JumpOffPlatform(old.ItemRoot,((r-(robots.Count-robotFailCount)+(failed?1:0))%2==0)?-1:1,old.SinkParent));
   else if(!starting)sequence.Insert(survivorStart,robots[r].JumpToNext(target,1+r%2));
  }
  if(!starting)sequence.InsertCallback(failed?25f/30f:22f/30f,()=>panelType.GetMethod("AttachPortraitGroup",flags).Invoke(panel,new object[]{target}));
  if(old.CanSink)sequence.Insert(1f,old.PlaySink());
  var progressText=go.transform.Find("Content/Progress/txt_Progress").GetComponent<Betta.Framework.UIText>();
  var peopleText=go.transform.Find("Content/LeftNum/txt_LeftNum").GetComponent<Betta.Framework.UIText>();
  progressText.SetText(progress+"/"+levels);peopleText.SetText("100");
  progressText.transform.parent.gameObject.SetActive(!failed);peopleText.transform.parent.gameObject.SetActive(!failed);
  if(!failed){
   var method=motion.GetMethod("AnimateCounter");
   var numbers=DOTween.Sequence();
   numbers.Append((Sequence)method.Invoke(null,new object[]{progressText.transform,new Action<int>(value=>progressText.SetText(value+"/"+levels)),progress,progress+1,false,null}));
   numbers.Append((Sequence)method.Invoke(null,new object[]{peopleText.transform,new Action<int>(value=>peopleText.SetText(value.ToString())),100,70,true,null}));
   sequence.Insert((float)motion.GetField("COUNTER_START").GetRawConstantValue(),numbers);
  }
  try
  {
   int i=0;
   for(var frame=0;frame<=120;frame++)
   {
    var t=frame/24f;sequence.ManualUpdate(frame == 0 ? 0f : 1f/24f, frame == 0 ? 0f : 1f/24f);
    Canvas.ForceUpdateCanvases();camera.Render();
    var prev=RenderTexture.active;RenderTexture.active=rt;var image=new Texture2D(540,960,TextureFormat.RGB24,false);image.ReadPixels(new Rect(0,0,540,960),0,0);image.Apply();RenderTexture.active=prev;
    File.WriteAllBytes("Temp/SplashQuestUI/frames-v7/"+(starting?"start-failure":failed?"failure":previousProgress==2?"special-success":"success")+"-"+(i++).ToString("D3")+".png",image.EncodeToPNG());UnityEngine.Object.DestroyImmediate(image);
   }
  }
  finally
  {
   sequence.Kill();foreach(var robot in robots)robot.OnRelease();portrait.OnRelease();panelType.GetMethod("RestorePortraitGroupLayout",flags).Invoke(panel,null);old.OnRelease();camera.targetTexture=null;rt.Release();UnityEngine.Object.DestroyImmediate(rt);UnityEngine.Object.DestroyImmediate(cameraGo);EditorSceneManager.CloseScene(scene,true);SceneManager.SetActiveScene(previousScene);
  }
 }
}
