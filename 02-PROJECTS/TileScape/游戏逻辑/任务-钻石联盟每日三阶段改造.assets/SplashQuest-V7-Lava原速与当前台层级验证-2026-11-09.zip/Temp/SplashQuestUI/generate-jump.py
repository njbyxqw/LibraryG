import json,math
from pathlib import Path
x=json.load(open('Temp/SplashQuestUI/lava-data.json'))
rows=[]
for name in ['PP0StepUp','PP0SingleStepUp','PP1SingleStepUp']:
 c=x['clips'][name];ts={t['prop']:t['v'] for t in c['tracks']};p=ts['p'];a=p[0];b=p[-1];out=[]
 for i in range(math.ceil(c['duration']*30)+1):
  u=(p[i][0]-a[0])/(b[0]-a[0]);arc=p[i][1]-a[1]-(b[1]-a[1])*u
  scale=[ts['s'][i][j]/(ts['s'][0][j]+(ts['s'][-1][j]-ts['s'][0][j])*max(0,min(1,u))) for j in range(2)]
  out.append([u,arc,ts['e'][i][2],*scale])
 rows.append(out)
 print(name,'duration',c['duration'],'sound',next(i/30 for i,r in enumerate(out) if r[0]>.01))
 def f(v):return (f'{v:.6f}'.rstrip('0').rstrip('.') or '0')+'f'
parts=['        private static readonly SplashQuestJumpSample[][] JumpSamples =\n        {']
for row in rows:
 parts.append('            new SplashQuestJumpSample[]\n            {')
 for r in row:parts.append('                new('+', '.join(f(v) for v in r)+'),')
 parts.append('            },')
parts.append('        };\n')
p=Path('Assets/Module/Activity/SplashQuest/Scripts/SplashQuestMotion.cs');s=p.read_text();start=s.index('        public const float PREPARE_DELAY');end=s.index('        // Lava Step1',start)
s=s[:start]+'''        public const float JUMP_DURATION = 22f / 30f;
        public const float FAIL_DURATION = 80f / 30f;
        public const float SINK_DURATION = 50f / 30f;
        public const float SINK_START = 1f;
        public const float COUNTER_START = JUMP_DURATION * 0.6f;

'''+ '\n'.join(parts)+s[end:]
pos=s.index('        public static float SurvivorStart')
s=s[:pos]+'''        public static float JumpDuration(int profile)
        {
            return profile == 0 ? JUMP_DURATION : profile == 1 ? 25f / 30f : 49f / 60f;
        }

        public static SplashQuestJumpSample SampleJump(float time, int profile)
        {
            var samples = JumpSamples[profile];
            var duration = JumpDuration(profile);
            var index = Mathf.Min(Mathf.FloorToInt(Mathf.Max(0f, time) * 30f), samples.Length - 2);
            var endTime = Mathf.Min((index + 1f) / 30f, duration);
            var fraction = Mathf.InverseLerp(index / 30f, endTime, time);
            var motion = Vector3.Lerp(samples[index].Motion, samples[index + 1].Motion, fraction);
            var scale = Vector2.Lerp(samples[index].Scale, samples[index + 1].Scale, fraction);
            return new SplashQuestJumpSample(motion.x, motion.y, motion.z, scale.x, scale.y);
        }

'''+s[pos:]
pos=s.rfind('\n}')
s=s[:pos]+'''

    internal readonly struct SplashQuestJumpSample
    {
        public readonly Vector3 Motion;
        public readonly Vector2 Scale;

        public SplashQuestJumpSample(float progress, float height, float rotation, float scaleX, float scaleY)
        {
            Motion = new Vector3(progress, height, rotation);
            Scale = new Vector2(scaleX, scaleY);
        }
    }
'''+s[pos:];p.write_text(s)
