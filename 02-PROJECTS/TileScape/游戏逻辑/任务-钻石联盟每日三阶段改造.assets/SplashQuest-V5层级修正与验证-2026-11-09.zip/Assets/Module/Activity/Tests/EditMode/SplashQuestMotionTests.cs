using System.Reflection;
using BettaSDK.Profile;
using DG.Tweening;
using Module.Activity.SplashQuest;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace Module.Activity.Tests.EditMode
{
    public sealed class SplashQuestMotionTests
    {
        private bool _wasTweenInitialized;
        private static readonly FieldInfo TweenInitialized = typeof(DOTween).GetField("initialized",
            BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);

        [SetUp]
        public void EnableManualTweenLifecycle()
        {
            // DOTween.Init does not initialize outside Play mode; Goto can sample, but Kill otherwise returns early.
            _wasTweenInitialized = (bool)TweenInitialized.GetValue(null);
            TweenInitialized.SetValue(null, true);
        }

        [TearDown]
        public void RestoreTweenLifecycle()
        {
            TweenInitialized.SetValue(null, _wasTweenInitialized);
        }

        [TestCase(5)]
        [TestCase(7)]
        [TestCase(10)]
        public void JumpUsesExistingLandingPointsAndSurvivesInterruption(int levels)
        {
            var root = Load(levels);
            UIActSplashQuestAnimPortrait portrait = null;
            try
            {
                var map = root.transform.Find("Content/trans_MapRoot");
                var parent = root.transform.Find("Content/trans_ItemParent");
                var avatar = (RectTransform)parent.Find("MyPortrait");
                var offset = avatar.localPosition;
                portrait = new UIActSplashQuestAnimPortrait(avatar);
                portrait.SetPosition(avatar.anchoredPosition);
                for (var level = 0; level < levels; level++)
                {
                    var from = Landing(map, level, levels);
                    var target = Landing(map, level + 1, levels);
                    parent.position = from.position;
                    avatar.localPosition = offset;
                    var start = avatar.localPosition;
                    var end = parent.InverseTransformPoint(target.position) + offset;
                    var jump = portrait.JumpToNext(target).Pause();
                    Assert.That(jump.Duration(), Is.EqualTo(0.816f).Within(0.0001f));
                    jump.Goto(0.55f);
                    Assert.That(Vector3.Distance(avatar.localPosition, start), Is.LessThan(0.01f));
                    jump.Goto(0.688f);
                    var jumpHeight = parent.InverseTransformVector(target.TransformVector(Vector3.up * 120f)).magnitude;
                    Assert.That(avatar.localPosition.y,
                        Is.EqualTo(Mathf.Lerp(start.y, end.y, 0.75f) + jumpHeight).Within(0.1f));
                    portrait.FastJump(target);
                    Assert.That(jump.IsActive(), Is.False);
                    Assert.That(Vector3.Distance(avatar.localPosition, end), Is.LessThan(0.01f));
                    Assert.That(avatar.localScale, Is.EqualTo(Vector3.one * 0.8f));
                    var complete = portrait.JumpToNext(target).Pause();
                    complete.Complete(true);
                    Assert.That(Vector3.Distance(avatar.localPosition, end), Is.LessThan(0.01f));
                }
            }
            finally
            {
                portrait?.OnRelease();
                PrefabUtility.UnloadPrefabContents(root);
            }
        }

        [TestCase(5, 0, 50f / 30f)]
        [TestCase(7, 1, 50f / 30f)]
        [TestCase(10, 2, 50f / 30f)]
        public void FailedPortraitAndPlatformFollowSampledLavaTiming(int levels, int stage, float duration)
        {
            var root = Load(levels);
            UISplashQuestMapSection section = null;
            UIActSplashQuestAnimPortrait portrait = null;
            try
            {
                var map = root.transform.Find("Content/trans_MapRoot");
                var activity = new ActSplashQuest(ActSplashQuest.ActivityId);
                typeof(ActSplashQuest).GetField("_profile", BindingFlags.Instance | BindingFlags.NonPublic)
                    .SetValue(activity, new SplashQuestData { CurrentStageIndex = stage });
                section = new UISplashQuestMapSection(map.Find("Middle/Level_1"), activity, 1, levels);
                var parent = root.transform.Find("Content/trans_ItemParent");
                var avatar = parent.Find("MyPortrait");
                parent.position = section.ItemRoot.position;
                var original = avatar.localPosition;
                var originalOrder = avatar.GetSiblingIndex();
                var originalRotation = avatar.localRotation;
                portrait = new UIActSplashQuestAnimPortrait(avatar);
                var jump = portrait.JumpOffPlatform(section.ItemRoot, stage == 1 ? -1 : 1, map).Pause();
                Assert.That(avatar.parent, Is.SameAs(parent));
                jump.Goto(0.2f);
                Assert.That(avatar.parent, Is.SameAs(parent));
                Assert.That(avatar.localPosition.y, Is.GreaterThan(original.y + 50f));
                Assert.That(Quaternion.Angle(avatar.localRotation, originalRotation), Is.GreaterThan(1f));
                Assert.That(avatar.GetComponent<CanvasGroup>().alpha, Is.EqualTo(1f));
                jump.Goto(0.91f);
                Assert.That(avatar.parent, Is.SameAs(map));
                Assert.That(avatar.GetSiblingIndex(), Is.LessThan(map.Find("Bottom").GetSiblingIndex()));
                Assert.That(avatar.GetSiblingIndex(), Is.LessThan(map.Find("Middle").GetSiblingIndex()));
                var fallPosition = parent.InverseTransformPoint(avatar.position);
                Assert.That(Mathf.Abs(fallPosition.x - original.x), Is.GreaterThan(100f));
                Assert.That(fallPosition.y, Is.LessThan(original.y));
                Assert.That(Vector3.Distance(avatar.lossyScale, parent.lossyScale * 0.8f), Is.LessThan(0.0001f));
                var backgroundStart = section.SinkParent.localPosition;
                var tween = section.PlaySink().Pause();
                Assert.That(tween.Duration(), Is.EqualTo(duration).Within(0.0001f));
                tween.Goto(1.5f);
                Assert.That(section.SinkParent.localPosition.y, Is.LessThan(backgroundStart.y - 80f));
                Assert.That(section.SinkParent.GetComponent<CanvasGroup>().alpha, Is.EqualTo(1f));
                tween.Goto(1.6f);
                Assert.That(section.SinkParent.GetComponent<CanvasGroup>().alpha, Is.EqualTo(0.41701f).Within(0.001f));
                jump.Complete(true);
                Assert.That(avatar.GetComponent<CanvasGroup>().alpha, Is.Zero);
                section.Hide();
                Assert.That(tween.IsActive(), Is.False);
                Assert.That(section.SinkParent.GetComponent<CanvasGroup>().alpha, Is.Zero);
                Assert.That(section.SinkParent.GetComponent<CanvasGroup>().blocksRaycasts, Is.False);
                portrait.OnRelease();
                portrait = null;
                Assert.That(avatar.parent, Is.SameAs(parent));
                Assert.That(avatar.localPosition, Is.EqualTo(original));
                Assert.That(avatar.GetSiblingIndex(), Is.EqualTo(originalOrder));
                Assert.That(avatar.localRotation, Is.EqualTo(originalRotation));
                section.OnRelease();
                section = null;
                Assert.That(map.Find("Middle/Level_1/Root/Background").localPosition, Is.EqualTo(backgroundStart));
            }
            finally
            {
                portrait?.OnRelease();
                section?.OnRelease();
                PrefabUtility.UnloadPrefabContents(root);
            }
        }

        [Test]
        public void StartRaftStaysVisibleWhenFailedPortraitSinksAndStopsOnRelease()
        {
            var root = Load(5);
            UIActSplashQuestAnimPortrait portrait = null;
            UISplashQuestMapSection section = null;
            try
            {
                var map = root.transform.Find("Content/trans_MapRoot");
                section = new UISplashQuestMapSection(map.Find("Bottom"),
                    new ActSplashQuest(ActSplashQuest.ActivityId), 0, 5);
                Assert.That(section.CanSink, Is.False);
                var parent = root.transform.Find("Content/trans_ItemParent");
                var avatar = parent.Find("MyPortrait");
                var position = avatar.localPosition;
                portrait = new UIActSplashQuestAnimPortrait(avatar);
                var sink = portrait.JumpOffPlatform(section.ItemRoot, -1, map).Pause();
                Assert.That(sink.Duration(), Is.EqualTo(80f / 30f).Within(0.0001f));
                sink.Goto(0.91f);
                Assert.That(parent.InverseTransformPoint(avatar.position).y, Is.LessThan(position.y));
                Assert.That(avatar.parent, Is.SameAs(map));
                Assert.That(avatar.GetSiblingIndex(), Is.LessThan(map.Find("Bottom").GetSiblingIndex()));
                section.Hide();
                Assert.That(section.SinkParent.GetComponent<CanvasGroup>().alpha, Is.EqualTo(1f));
                portrait.OnRelease();
                portrait = null;
                Assert.That(sink.IsActive(), Is.False);
                Assert.That(avatar.parent, Is.SameAs(parent));
                Assert.That(avatar.localPosition, Is.EqualTo(position));
            }
            finally
            {
                portrait?.OnRelease();
                section?.OnRelease();
                PrefabUtility.UnloadPrefabContents(root);
            }
        }

        [TestCase(5, -1)]
        [TestCase(7, 1)]
        [TestCase(10, -1)]
        public void FallKeepsItsWorldPathAfterGoingBehindBoatAndCanReturnToPortraitGroup(int levels, int direction)
        {
            var root = Load(levels);
            UIActSplashQuestAnimPortrait portrait = null;
            try
            {
                var map = root.transform.Find("Content/trans_MapRoot");
                var parent = root.transform.Find("Content/trans_ItemParent");
                var reference = Landing(map, 0, levels);
                parent.position = reference.position;
                var avatar = (RectTransform)parent.Find("MyPortrait");
                var original = avatar.localPosition;
                portrait = new UIActSplashQuestAnimPortrait(avatar);
                portrait.SetPosition(avatar.anchoredPosition);
                var sampleMethod = typeof(UIActSplashQuestAnimPortrait).Assembly
                    .GetType("Module.Activity.SplashQuest.SplashQuestMotion").GetMethod("SampleFall");
                var fall = portrait.JumpOffPlatform(reference, direction, map).Pause();
                for (var frame = 1; frame <= 80; frame++)
                {
                    var time = frame / 30f;
                    fall.Goto(time);
                    var sample = (Vector4)sampleMethod.Invoke(null, new object[] { time });
                    var expected = parent.TransformPoint(original)
                        + reference.TransformVector(new Vector3(sample.x * (direction < 0 ? 1f : -1f), sample.y, 0f) * 100f);
                    Assert.That(Vector3.Distance(avatar.position, expected), Is.LessThan(0.01f), "frame " + frame);
                }
                var target = Landing(map, 1, levels);
                portrait.FastJump(target);
                Assert.That(fall.IsActive(), Is.False);
                Assert.That(avatar.parent, Is.SameAs(parent));
                Assert.That(Vector3.Distance(avatar.localPosition,
                    parent.InverseTransformPoint(target.position) + original), Is.LessThan(0.01f));
                Assert.That(avatar.localScale, Is.EqualTo(Vector3.one * 0.8f));
                Assert.That(avatar.GetComponent<CanvasGroup>().alpha, Is.EqualTo(1f));
                var replay = portrait.JumpOffPlatform(target, direction, map).Pause();
                replay.Goto(0.91f);
                portrait.OnRelease();
                portrait = null;
                Assert.That(replay.IsActive(), Is.False);
                Assert.That(avatar.parent, Is.SameAs(parent));
                Assert.That(avatar.localPosition, Is.EqualTo(original));
                Assert.That(avatar.localScale, Is.EqualTo(Vector3.one));
            }
            finally
            {
                portrait?.OnRelease();
                PrefabUtility.UnloadPrefabContents(root);
            }
        }

        [TestCase(5)]
        [TestCase(7)]
        [TestCase(10)]
        public void SettlingSurvivorsDoesNotCoverPlayerAfterPortraitsLeaveTheGroup(int levels)
        {
            var root = Load(levels);
            var portraits = new System.Collections.Generic.List<UIActSplashQuestAnimPortrait>();
            UIActSplashQuestAnimPortrait player = null;
            try
            {
                var parent = root.transform.Find("Content/trans_ItemParent");
                for (var i = parent.childCount - 1; i >= 0; i--)
                {
                    var child = parent.GetChild(i);
                    var portrait = new UIActSplashQuestAnimPortrait(child);
                    portrait.SetPosition(((RectTransform)child).anchoredPosition);
                    if (child.name == "MyPortrait")
                    {
                        player = portrait;
                    }
                    else
                    {
                        portraits.Add(portrait);
                    }
                }
                var target = Landing(root.transform.Find("Content/trans_MapRoot"), 2, levels);
                var sink = new GameObject("Sink").transform;
                sink.SetParent(root.transform, false);
                portraits[portraits.Count - 1].Transform.SetParent(sink, true);
                portraits[portraits.Count - 2].Transform.SetParent(sink, true);
                player.FastJump(target);
                for (var i = 0; i < portraits.Count - 2; i++)
                {
                    portraits[i].FastJump(target);
                }
                Assert.That(player.Transform.GetSiblingIndex(), Is.EqualTo(parent.childCount - 1));
            }
            finally
            {
                for (var i = 0; i < portraits.Count; i++)
                {
                    portraits[i].OnRelease();
                }
                player?.OnRelease();
                PrefabUtility.UnloadPrefabContents(root);
            }
        }

        [TestCase(0, false, 0)]
        [TestCase(0, true, 1)]
        [TestCase(1, false, 1)]
        [TestCase(1, true, 2)]
        [TestCase(5, false, 2)]
        [TestCase(5, true, 2)]
        public void EliminationUsesExactlyTwoAvailableSlotsIncludingPlayer(int robots, bool playerFailed, int expected)
        {
            var method = typeof(UIActSplashQuestAnimPortrait).Assembly
                .GetType("Module.Activity.SplashQuest.SplashQuestMotion")
                .GetMethod("FailurePortraitCount", BindingFlags.Static | BindingFlags.Public);
            Assert.That((int)method.Invoke(null, new object[] { robots, playerFailed }), Is.EqualTo(expected));
        }

        [TestCase(0, 25f / 60f, 65f / 60f, 50f / 60f)]
        [TestCase(1, 25f / 60f, 65f / 60f, 50f / 60f)]
        [TestCase(2, 40f / 60f, 80f / 60f, 1f)]
        [TestCase(3, 25f / 60f, 65f / 60f, 50f / 60f)]
        [TestCase(5, 40f / 60f, 80f / 60f, 1f)]
        [TestCase(6, 25f / 60f, 65f / 60f, 50f / 60f)]
        public void BatchTimingMapsOneBasedReferenceStepsToCompletedProgress(int progress, float survivor,
            float elimination, float playerFailure)
        {
            var type = typeof(UIActSplashQuestAnimPortrait).Assembly
                .GetType("Module.Activity.SplashQuest.SplashQuestMotion");
            Assert.That((float)type.GetMethod("SurvivorStart").Invoke(null, new object[] { progress }),
                Is.EqualTo(survivor).Within(0.0001f));
            Assert.That((float)type.GetMethod("EliminationStart").Invoke(null, new object[] { progress, false }),
                Is.EqualTo(elimination).Within(0.0001f));
            Assert.That((float)type.GetMethod("EliminationStart").Invoke(null, new object[] { progress, true }),
                Is.EqualTo(playerFailure).Within(0.0001f));
        }

        [Test]
        public void LevelsFinishBeforePlayersChangeAndInterruptedCountersRestoreScale()
        {
            var levelObject = new GameObject("Levels");
            var peopleObject = new GameObject("Players");
            var level = 1;
            var people = 100;
            var impacts = 0;
            Sequence seq = null;
            try
            {
                levelObject.transform.localScale = new Vector3(0.7f, 0.8f, 1f);
                var original = levelObject.transform.localScale;
                var type = typeof(UIActSplashQuestAnimPortrait).Assembly
                    .GetType("Module.Activity.SplashQuest.SplashQuestMotion");
                var method = type.GetMethod("AnimateCounter");
                var levels = (Sequence)method.Invoke(null, new object[]
                {
                    levelObject.transform, new System.Action<int>(value => level = value), 1, 2, false, null
                });
                var players = (Sequence)method.Invoke(null, new object[]
                {
                    peopleObject.transform, new System.Action<int>(value => people = value), 100, 70, true,
                    new System.Action(() => impacts++)
                });
                var delay = (float)type.GetField("COUNTER_START").GetRawConstantValue();
                seq = DOTween.Sequence().SetAutoKill(false).Pause();
                seq.AppendInterval(delay);
                seq.Append(levels);
                seq.Append(players);
                Assert.That(seq.Duration(), Is.EqualTo(delay + 1.85f).Within(0.0001f));
                seq.Goto(delay + 0.12f);
                Assert.That(levelObject.transform.localScale.x, Is.EqualTo(original.x + 0.4f).Within(0.001f));
                Assert.That(level, Is.EqualTo(1));
                seq.Goto(delay + 0.69f);
                Assert.That(level, Is.EqualTo(2));
                Assert.That(people, Is.EqualTo(100));
                seq.Goto(delay + 0.94f);
                Assert.That(people, Is.EqualTo(100));
                seq.Goto(delay + 1.25f);
                Assert.That(people, Is.LessThan(100).And.GreaterThan(70));
                seq.Complete(true);
                Assert.That(people, Is.EqualTo(70));
                Assert.That(impacts, Is.EqualTo(1));
                seq.Rewind();
                seq.Goto(delay + 0.3f);
                seq.Kill();
                Assert.That(levelObject.transform.localScale, Is.EqualTo(original));
                Assert.That(peopleObject.transform.localScale, Is.EqualTo(Vector3.one));
            }
            finally
            {
                seq?.Kill();
                Object.DestroyImmediate(levelObject);
                Object.DestroyImmediate(peopleObject);
            }
        }

        private static GameObject Load(int levels)
        {
            return PrefabUtility.LoadPrefabContents(
                $"Assets/Module/Activity/SplashQuest/ResDLC/Default/Panel/Prefab/UIActSplashQuestMainPanel_{levels}.prefab");
        }

        private static Transform Landing(Transform map, int level, int levels)
        {
            var path = level == 0 ? "Bottom" : level == levels ? "Top" : $"Middle/Level_{level}";
            return map.Find(path + "/Root/Background/ItemRoot");
        }
    }
}
