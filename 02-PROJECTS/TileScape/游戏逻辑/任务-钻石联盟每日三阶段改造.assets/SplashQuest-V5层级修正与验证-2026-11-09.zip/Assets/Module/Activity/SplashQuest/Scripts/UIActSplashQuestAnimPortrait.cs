using TransformUtils = Module.Utils.UtilsTransform;
using Betta.Framework;
using BettaSDK;
using DG.Tweening;
using Module.PlayerInfo;

using UnityEngine;

namespace Module.Activity.SplashQuest
{
    public class UIActSplashQuestAnimPortrait
    {
        public Transform Transform { get; private set; }
        public RectTransform RectTransform => Transform as RectTransform;

        private readonly Transform _originalParent;
        private readonly int _originalSiblingIndex;
        private readonly Vector3 _originalScale;
        private readonly Vector3 _displayScale;
        private readonly Vector3 _originalPosition;
        private readonly Quaternion _originalRotation;
        private readonly CanvasGroup _canvasGroup;

        private Animator _animator;

        private Transform _portraitTransform;

        private UIPortraitView _portraitView;

        private Vector2 _anchoredPosition;

        private int _avatarId;
        private int _frameId;
        private int _badgeId;

        private readonly int _appear = Animator.StringToHash("Appear");

        private Sequence _seq;

        public UIActSplashQuestAnimPortrait(Transform transform)
        {
            Transform = transform;
            _originalParent = transform.parent;
            _originalSiblingIndex = transform.GetSiblingIndex();
            _originalScale = transform.localScale;
            _displayScale = _originalScale * SplashQuestMotion.PORTRAIT_SCALE;
            transform.localScale = _displayScale;
            _originalPosition = transform.localPosition;
            _originalRotation = transform.localRotation;
            _canvasGroup = transform.GetComponent<CanvasGroup>();
            if (_canvasGroup == null)
            {
                _canvasGroup = transform.gameObject.AddComponent<CanvasGroup>();
            }
            _canvasGroup.alpha = 1f;
            FindComponents();
            InitProperties();
            RegisterEvents();
        }

        private void FindComponents()
        {
            _animator = Transform.GetComponent<Animator>();
            _portraitTransform = TransformUtils.Find(Transform, "AnimRoot/ScaleRoot/UIPortraitView");
        }

        private void InitProperties()
        {
            _portraitView = new UIPortraitView(_portraitTransform);
            _avatarId = PortraitConfig.DefaultAvatarId;
            _frameId = PortraitConfig.DefaultFrameId;
            _badgeId = 0;
        }

        private void RegisterEvents()
        {

        }

        private void UnregisterEvents()
        {

        }

        public void OnRelease()
        {
            UnregisterEvents();
            _portraitView.OnRelease();
            _seq?.Kill();
            Transform.SetParent(_originalParent, false);
            Transform.SetSiblingIndex(_originalSiblingIndex);
            Transform.localPosition = _originalPosition;
            Transform.localScale = _originalScale;
            Transform.localRotation = _originalRotation;
            _canvasGroup.alpha = 1f;
        }

        public void Show(int avatarId, int frameId, int badgeId)
        {
            _portraitView.Show(avatarId, frameId);
        }

        public void ShowRandom()
        {
            _avatarId = ImplementHub.Instance.Get<Interface.PlayerInfo.IPlayerInfo>().GetRandomId(PortraitType.Avatar);
            _frameId = ImplementHub.Instance.Get<Interface.PlayerInfo.IPlayerInfo>().GetRandomId(PortraitType.Frame);
            _badgeId = 0;

            _portraitView.Show(_avatarId, _frameId, false);
        }

        public void SetPosition(Vector2 position)
        {
            _anchoredPosition = position;
        }

        public void Appear()
        {
            if (_animator != null)
            {
                _animator.Play(_appear);
            }

            DOVirtual.DelayedCall(0.2f, () =>
            {
                HapticsHub.Instance.DoHaptic(HapticsTypes.Light);
            }, false).SetLink(Transform.gameObject);
        }

        public void CompleteAppear()
        {
            if (_animator == null)
            {
                return;
            }

            _animator.Play(_appear, 0, 1f);
            _animator.Update(0f);
        }

        public Sequence JumpToNext(Transform target)
        {
            _seq?.Kill();
            var targetPos = GetTargetPosition(target);
            var jumpHeight = Transform.parent.InverseTransformVector(
                target.TransformVector(Vector3.up * SplashQuestMotion.JUMP_HEIGHT)).magnitude;
            _seq = DOTween.Sequence();
            _seq.SetLink(Transform.gameObject);
            _seq.AppendInterval(SplashQuestMotion.PREPARE_DELAY);
            _seq.Append(Transform.DOScale(Vector3.Scale(_displayScale, new Vector3(1.1f, 0.95f, 1f)),
                (SplashQuestMotion.MOVE_START - SplashQuestMotion.PREPARE_DELAY) * 0.5f).SetEase(Ease.OutQuad));
            _seq.Append(Transform.DOScale(Vector3.Scale(_displayScale, new Vector3(0.9f, 1.1f, 1f)),
                (SplashQuestMotion.MOVE_START - SplashQuestMotion.PREPARE_DELAY) * 0.5f).SetEase(Ease.OutQuad));
            _seq.AppendCallback(() =>
            {
                ImplementHub.Instance.Get<Interface.Sound.IAudioSystem>()?.PlayAudio(
                    Module.Audio.SoundConst.SFX_Temple_Jump, false, 1f);
            });
            _seq.Append(Transform.DOLocalJump(targetPos, jumpHeight, 1, SplashQuestMotion.JUMP_DURATION, false)
                .SetEase(Ease.Linear));
            _seq.Join(Transform.DOScale(_displayScale, SplashQuestMotion.JUMP_DURATION).SetEase(Ease.OutQuad));
            _seq.OnComplete(() =>
            {
                Transform.localPosition = targetPos;
                Transform.localScale = _displayScale;
            });
            return _seq;
        }

        private Vector3 GetTargetPosition(Transform target)
        {
            return Transform.parent.InverseTransformPoint(target.position) + (Vector3)_anchoredPosition;
        }

        public Sequence JumpOffPlatform(Transform reference, int direction, Transform fallParent)
        {
            _seq?.Kill();
            var parent = Transform.parent;
            var start = Transform.localPosition;
            var horizontal = parent.InverseTransformVector(reference.TransformVector(Vector3.right * 100f));
            var vertical = parent.InverseTransformVector(reference.TransformVector(Vector3.up * 100f));
            var mirror = direction < 0 ? 1f : -1f;
            _seq = DOTween.Sequence().SetLink(Transform.gameObject);
            _seq.Append(DOVirtual.Float(0f, SplashQuestMotion.FAIL_DURATION, SplashQuestMotion.FAIL_DURATION, time =>
            {
                var sample = SplashQuestMotion.SampleFall(time);
                if (sample.y < 0f && Transform.parent != fallParent)
                {
                    Transform.SetParent(fallParent, true);
                    Transform.SetAsFirstSibling();
                }
                Transform.position = parent.TransformPoint(start + horizontal * (sample.x * mirror) + vertical * sample.y);
                Transform.rotation = parent.rotation * _originalRotation * Quaternion.Euler(0f, 0f, sample.z * mirror);
                _canvasGroup.alpha = sample.w;
            }).SetEase(Ease.Linear));
            return _seq;
        }

        public void FastJump(Transform target)
        {
            _seq?.Kill();
            if (Transform.parent != _originalParent)
            {
                Transform.SetParent(_originalParent, false);
            }
            Transform.localScale = _displayScale;
            Transform.localRotation = _originalRotation;
            _canvasGroup.alpha = 1f;
            Transform.localPosition = GetTargetPosition(target);
        }

        public void CompleteSink()
        {
            _seq?.Kill();
            _canvasGroup.alpha = 0f;
        }

        public int[] GetPortraitInfo()
        {
            return new[] { _avatarId, _frameId, _badgeId };
        }
    }
}
