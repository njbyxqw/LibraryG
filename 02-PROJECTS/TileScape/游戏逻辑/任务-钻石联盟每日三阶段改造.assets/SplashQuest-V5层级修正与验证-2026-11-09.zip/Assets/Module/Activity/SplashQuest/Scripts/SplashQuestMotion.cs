using System;
using DG.Tweening;
using UnityEngine;

namespace Module.Activity.SplashQuest
{
    internal static class SplashQuestMotion
    {
        public const float PORTRAIT_SCALE = 0.8f;
        public const float PREPARE_DELAY = 0.4f;
        public const float MOVE_START = 0.56f;
        public const float JUMP_DURATION = 0.256f;
        public const float JUMP_HEIGHT = 120f;
        public const float FAIL_DURATION = 80f / 30f;
        public const float SINK_DURATION = 50f / 30f;
        public const float SINK_START = 1f;
        public const float COUNTER_START = (MOVE_START + JUMP_DURATION) * 0.6f;

        // Lava Step1 PP0Fail1 and BuryRock at 30 Hz; omit the already invisible clip tails.
        private static readonly Vector4[] FallSamples =
        {
            new(0f, 0f, 0f, 1f),
            new(0.00002f, -0.11121f, 0f, 1f),
            new(-0.30213f, 0.05654f, 13.83927f, 1f),
            new(-0.44714f, 0.37073f, 11.00556f, 1f),
            new(-0.59214f, 0.7165f, 8.17184f, 1f),
            new(-0.73714f, 0.99911f, 5.33812f, 1f),
            new(-0.88214f, 1.12383f, 2.5044f, 1f),
            new(-1.02715f, 1.02481f, -0.32932f, 1f),
            new(-1.17215f, 0.7342f, -3.16304f, 1f),
            new(-1.31715f, 0.30425f, -5.99675f, 1f),
            new(-1.46215f, -0.21279f, -8.83047f, 1f),
            new(-1.60716f, -0.76467f, -11.66419f, 1f),
            new(-1.75216f, -1.29912f, -14.49791f, 1f),
            new(-1.89716f, -1.76391f, -17.33163f, 1f),
            new(-1.90092f, -1.77427f, -16.7716f, 1f),
            new(-1.90942f, -1.78519f, -16.17327f, 1f),
            new(-1.91979f, -1.79584f, -15.59408f, 1f),
            new(-1.92915f, -1.80537f, -15.09151f, 1f),
            new(-1.93463f, -1.81296f, -14.723f, 1f),
            new(-1.93707f, -1.81894f, -14.43794f, 1f),
            new(-1.93925f, -1.82427f, -14.14953f, 1f),
            new(-1.94117f, -1.82906f, -13.86098f, 1f),
            new(-1.94286f, -1.83346f, -13.57547f, 1f),
            new(-1.94432f, -1.83756f, -13.2962f, 1f),
            new(-1.94558f, -1.8415f, -13.02636f, 1f),
            new(-1.94664f, -1.8454f, -12.76915f, 1f),
            new(-1.94753f, -1.84938f, -12.52776f, 1f),
            new(-1.94825f, -1.85355f, -12.30538f, 1f),
            new(-1.94883f, -1.85805f, -12.10521f, 1f),
            new(-1.94927f, -1.86299f, -11.93043f, 1f),
            new(-1.9496f, -1.86849f, -11.78425f, 1f),
            new(-1.94982f, -1.87468f, -11.66986f, 1f),
            new(-1.94996f, -1.88168f, -11.59045f, 1f),
            new(-1.95002f, -1.88961f, -11.54922f, 1f),
            new(-1.94985f, -1.89859f, -11.56402f, 1f),
            new(-1.94855f, -1.90867f, -11.71695f, 1f),
            new(-1.94607f, -1.91984f, -12.00247f, 1f),
            new(-1.94255f, -1.93205f, -12.39936f, 1f),
            new(-1.93813f, -1.94526f, -12.88642f, 1f),
            new(-1.93293f, -1.95944f, -13.44243f, 1f),
            new(-1.9271f, -1.97455f, -14.04617f, 1f),
            new(-1.92077f, -1.99056f, -14.67643f, 1f),
            new(-1.91408f, -2.00741f, -15.31199f, 1f),
            new(-1.90715f, -2.02509f, -15.93165f, 1f),
            new(-1.90012f, -2.04354f, -16.51417f, 1f),
            new(-1.89314f, -2.06274f, -17.03836f, 1f),
            new(-1.88632f, -2.08264f, -17.48299f, 1f),
            new(-1.87982f, -2.10321f, -17.82685f, 1f),
            new(-1.87375f, -2.12441f, -18.04872f, 1f),
            new(-1.86827f, -2.14621f, -18.12739f, 1f),
            new(-1.86462f, -2.16856f, -18.10082f, 1f),
            new(-1.86374f, -2.19142f, -18.02604f, 1f),
            new(-1.86525f, -2.21477f, -17.91048f, 1f),
            new(-1.86878f, -2.23856f, -17.76155f, 1f),
            new(-1.87396f, -2.26275f, -17.58667f, 1f),
            new(-1.88041f, -2.28732f, -17.39324f, 1f),
            new(-1.88777f, -2.31221f, -17.1887f, 0.97983f),
            new(-1.89565f, -2.3374f, -16.98044f, 0.936362f),
            new(-1.90369f, -2.36284f, -16.77589f, 0.892462f),
            new(-1.91152f, -2.3885f, -16.58247f, 0.848183f),
            new(-1.91876f, -2.41435f, -16.40758f, 0.803575f),
            new(-1.92504f, -2.44033f, -16.25865f, 0.758743f),
            new(-1.92998f, -2.46642f, -16.14309f, 0.713722f),
            new(-1.93322f, -2.49259f, -16.06832f, 0.668562f),
            new(-1.93439f, -2.51878f, -16.04174f, 0.623368f),
            new(-1.93281f, -2.54496f, -16.13324f, 0.578191f),
            new(-1.92858f, -2.57111f, -16.3773f, 0.533066f),
            new(-1.9224f, -2.59717f, -16.72832f, 0.488096f),
            new(-1.915f, -2.62311f, -17.14067f, 0.443334f),
            new(-1.90711f, -2.6489f, -17.56872f, 0.39883f),
            new(-1.89944f, -2.67449f, -17.96686f, 0.354671f),
            new(-1.89273f, -2.69985f, -18.28946f, 0.310909f),
            new(-1.88781f, -2.72494f, -18.4936f, 0.267613f),
            new(-1.88561f, -2.74973f, -18.57706f, 0.224835f),
            new(-1.88566f, -2.77418f, -18.56639f, 0.182643f),
            new(-1.88731f, -2.79824f, -18.4885f, 0.141125f),
            new(-1.88994f, -2.82189f, -18.37027f, 0.100314f),
            new(-1.89288f, -2.84508f, -18.2386f, 0.060296f),
            new(-1.8955f, -2.86778f, -18.12037f, 0.021125f),
            new(-1.89716f, -2.88994f, -18.04248f, 0f),
            new(-1.89716f, -2.88994f, -18.04248f, 0f),
        };

        private static readonly Vector3[] SinkSamples =
        {
            new(0f, 0f, 1f),
            new(-0.01681f, -0.00214f, 1f),
            new(-0.03362f, -0.00611f, 1f),
            new(-0.03015f, -0.00826f, 1f),
            new(-0.00639f, -0.00812f, 1f),
            new(0.01737f, -0.00777f, 1f),
            new(0.01218f, -0.00728f, 1f),
            new(0.00698f, -0.00674f, 1f),
            new(0.00179f, -0.00623f, 1f),
            new(-0.00341f, -0.00583f, 1f),
            new(-0.00145f, -0.00563f, 1f),
            new(0.00766f, -0.0057f, 1f),
            new(0.01677f, -0.00614f, 1f),
            new(0.01909f, -0.00701f, 1f),
            new(0.01462f, -0.00841f, 1f),
            new(0.01014f, -0.01042f, 1f),
            new(0.00903f, -0.01312f, 1f),
            new(0.01128f, -0.01659f, 1f),
            new(0.01352f, -0.02091f, 1f),
            new(0.01576f, -0.02617f, 1f),
            new(0.01443f, -0.03244f, 1f),
            new(0.01309f, -0.03982f, 1f),
            new(0.01175f, -0.04838f, 1f),
            new(0.01802f, -0.05821f, 1f),
            new(0.02429f, -0.06938f, 1f),
            new(0.03056f, -0.08199f, 1f),
            new(0.03683f, -0.09611f, 1f),
            new(0.02426f, -0.11182f, 1f),
            new(0.01169f, -0.12921f, 1f),
            new(-0.00088f, -0.14837f, 1f),
            new(-0.01345f, -0.16936f, 1f),
            new(-0.00412f, -0.19228f, 1f),
            new(0.00522f, -0.21721f, 1f),
            new(0.01456f, -0.24422f, 1f),
            new(0.0239f, -0.32896f, 1f),
            new(0.02425f, -0.3801f, 1f),
            new(0.01561f, -0.41601f, 1f),
            new(0.00698f, -0.45179f, 1f),
            new(-0.00165f, -0.51361f, 1f),
            new(-0.01029f, -0.54878f, 1f),
            new(-0.01892f, -0.56316f, 1f),
            new(-0.01336f, -0.59076f, 1f),
            new(-0.00699f, -0.64459f, 1f),
            new(-0.00079f, -0.71068f, 1f),
            new(0.0043f, -0.78038f, 1f),
            new(0.0073f, -0.8451f, 1f),
            new(0.00746f, -0.91126f, 0.96571f),
            new(0.00572f, -1.04633f, 0.74074f),
            new(0.00322f, -1.22038f, 0.41701f),
            new(0.00097f, -1.38681f, 0.1262f),
            new(0f, -1.49906f, 0f),
        };

        public static Vector4 SampleFall(float time)
        {
            var frame = Mathf.Clamp(time * 30f, 0f, FallSamples.Length - 1);
            var index = Mathf.FloorToInt(frame);
            return Vector4.LerpUnclamped(FallSamples[index], FallSamples[Mathf.Min(index + 1, FallSamples.Length - 1)],
                frame - index);
        }

        public static Vector3 SampleSink(float time)
        {
            var frame = Mathf.Clamp(time * 30f, 0f, SinkSamples.Length - 1);
            var index = Mathf.FloorToInt(frame);
            return Vector3.LerpUnclamped(SinkSamples[index], SinkSamples[Mathf.Min(index + 1, SinkSamples.Length - 1)],
                frame - index);
        }

        public static float SurvivorStart(int previousProgress)
        {
            return IsSpecialStep(previousProgress) ? 40f / 60f : 25f / 60f;
        }

        public static float EliminationStart(int previousProgress, bool playerFailed)
        {
            if (playerFailed)
            {
                return IsSpecialStep(previousProgress) ? 1f : 50f / 60f;
            }
            return SurvivorStart(previousProgress) + 40f / 60f;
        }

        private static bool IsSpecialStep(int previousProgress)
        {
            return previousProgress == 2 || previousProgress == 5;
        }

        public static Sequence AnimateCounter(Transform target, Action<int> setValue, int from, int to,
            bool isPlayers, Action onImpact = null)
        {
            var originalScale = target.localScale;
            var returnDuration = isPlayers ? 0.1f : 0.07f;
            var displayedValue = from;
            var seq = DOTween.Sequence().SetLink(target.gameObject);
            seq.Append(target.DOScale(originalScale + Vector3.one * 0.4f, isPlayers ? 0.15f : 0.12f));
            seq.Append(target.DOScale(originalScale + Vector3.one * 0.3f, isPlayers ? 0.1f : 0.07f));
            seq.Append(DOTween.To(() => from, value =>
            {
                if (value == displayedValue)
                {
                    return;
                }
                displayedValue = value;
                setValue(value);
            }, to, isPlayers ? 0.6f : 0.3f).SetEase(Ease.OutQuad));
            seq.Append(target.DOScale(originalScale + Vector3.one * 0.4f, returnDuration));
            seq.Append(target.DOScale(originalScale - Vector3.one * 0.2f, returnDuration));
            if (onImpact != null)
            {
                seq.AppendCallback(() => onImpact());
            }
            seq.Append(target.DOScale(originalScale, returnDuration));
            seq.OnKill(() => target.localScale = originalScale);
            return seq;
        }

        public static int FailurePortraitCount(int robotCount, bool playerFailed)
        {
            return Mathf.Min(2, robotCount + (playerFailed ? 1 : 0));
        }
    }
}
