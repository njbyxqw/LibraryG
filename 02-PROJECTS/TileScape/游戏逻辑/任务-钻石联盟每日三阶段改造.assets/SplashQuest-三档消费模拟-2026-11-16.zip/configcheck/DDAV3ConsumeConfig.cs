﻿//////////////////////////////////////////////////////////////////////////////////
// Config sheet : Game.TileV2.Scripts.Config.TableConfigLevelControlV3.DDAV3ConsumeConfig (行类型 + 主键访问)
// This file cannot be modified!!!
// If there is a problem, please contact zengyunhan@bettagames.com or lianyonggang@bettagames.com
//////////////////////////////////////////////////////////////////////////////////

// ReSharper disable ClassNeverInstantiated.Global
// ReSharper disable UnassignedField.Global
// ReSharper disable InconsistentNaming

using Newtonsoft.Json;
using ProtoBuf;

namespace Game.TileV2.Scripts.Config.TableConfigLevelControlV3.Config
{
    [ProtoContract]
    public partial class DDAV3ConsumeConfig
    {
        [ProtoMember(1)]
        [JsonProperty]
        public int id { get; private set; } // 折算配置 ID
        [ProtoMember(2)]
        [JsonProperty]
        public int propType { get; private set; } // 道具类型; 沿用 PropType
        [ProtoMember(3)]
        [JsonProperty]
        public string source { get; private set; } // Inventory / Ad / Unlimited / Paid
        [ProtoMember(4)]
        [JsonProperty]
        public float recoveryPerUnit { get; private set; } // 折算比例（百分比）; 100 表示 100%
    }

    internal static class DDAV3ConsumeConfigConfigKeys
    {
        internal static int GetKey(DDAV3ConsumeConfig row) => row.id;
    }
}
