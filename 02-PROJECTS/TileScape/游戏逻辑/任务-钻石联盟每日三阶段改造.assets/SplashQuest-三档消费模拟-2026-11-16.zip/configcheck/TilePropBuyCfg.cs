﻿//////////////////////////////////////////////////////////////////////////////////
// Config sheet : Game.TileV2.Scripts.Config.TableConfig.TilePropBuyCfg (行类型 + 主键访问)
// This file cannot be modified!!!
// If there is a problem, please contact zengyunhan@bettagames.com or lianyonggang@bettagames.com
//////////////////////////////////////////////////////////////////////////////////

// ReSharper disable ClassNeverInstantiated.Global
// ReSharper disable UnassignedField.Global
// ReSharper disable InconsistentNaming

using Newtonsoft.Json;
using ProtoBuf;

namespace Game.TileV2.Scripts.Config.TableConfig.Config
{
    [ProtoContract]
    public partial class TilePropBuyCfg
    {
        [ProtoMember(1)]
        [JsonProperty]
        public int id { get; private set; } // 道具ID
        [ProtoMember(2)]
        [JsonProperty]
        public int type { get; private set; } // 类型
        [ProtoMember(3)]
        [JsonProperty]
        public string name { get; private set; } // 标题名
        [ProtoMember(4)]
        [JsonProperty]
        public string desc { get; private set; } // 描述文本
        [ProtoMember(5)]
        [JsonProperty]
        public int[] consume { get; private set; } = System.Array.Empty<int>(); // 消耗
        [ProtoMember(6)]
        [JsonProperty]
        public int buyCount { get; private set; } // 购买数量
    }

    internal static class TilePropBuyCfgConfigKeys
    {
        internal static int GetKey(TilePropBuyCfg row) => row.id;
    }
}
