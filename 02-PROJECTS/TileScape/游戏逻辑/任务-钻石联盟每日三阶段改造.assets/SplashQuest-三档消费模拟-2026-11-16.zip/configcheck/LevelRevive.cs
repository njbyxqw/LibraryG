﻿//////////////////////////////////////////////////////////////////////////////////
// Config sheet : Game.TileV2.Scripts.Config.TableConfig.LevelRevive (行类型 + 主键访问)
// This file cannot be modified!!!
// If there is a problem, please contact zengyunhan@bettagames.com or lianyonggang@bettagames.com
//////////////////////////////////////////////////////////////////////////////////

// ReSharper disable ClassNeverInstantiated.Global
// ReSharper disable UnassignedField.Global
// ReSharper disable InconsistentNaming

using Newtonsoft.Json;
using ProtoBuf;

namespace Game.TileV2.Scripts.Config.TableConfig.Config
{
    [ProtoContract]
    public partial class LevelRevive
    {
        [ProtoMember(1)]
        [JsonProperty]
        public int id { get; private set; } // 复活次数
        [ProtoMember(2)]
        [JsonProperty]
        public int[] RebirthConsume { get; private set; } = System.Array.Empty<int>(); // 复活消耗
        [ProtoMember(3)]
        [JsonProperty]
        public int RemoveNum { get; private set; } // 退牌数量
        [ProtoMember(4)]
        [JsonProperty]
        public bool UseHint { get; private set; } // 是否使用磁铁
    }

    internal static class LevelReviveConfigKeys
    {
        internal static int GetKey(LevelRevive row) => row.id;
    }
}
