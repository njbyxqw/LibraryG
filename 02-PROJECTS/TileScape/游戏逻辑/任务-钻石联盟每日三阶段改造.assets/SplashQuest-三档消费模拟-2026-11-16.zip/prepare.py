from pathlib import Path
import json,hashlib,shutil,re,subprocess
r=Path('/Users/dean/TileScape');o=Path('/tmp/splashquest-consumption-20261116');o.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
old=read(Path('/tmp/splashquest_sim_20261116/inputs.json'))
source=(r/'Assets/Module/Activity/SplashQuest/Scripts/ActSplashQuest.PeopleRule.cs').read_text()
calc=Path('/tmp/splashquest_sim_20261116/unitymath/Calculator.cs').read_text()
for name in ['GetExpectPeople','GetFailPeople']:
 m=re.search(r'        private [^\n]+ '+name+r'\(',source);b=source.index('{',m.end());depth=1;i=b+1
 while depth:depth+=(source[i]=='{')-(source[i]=='}');i+=1
 assert source[m.start():i].replace('private ','public ',1) in calc
(o/'Calculator.cs').write_text(calc)
hashes={}
def take(rel):
 p=r/rel;hashes[rel]=hashlib.sha256(p.read_bytes()).hexdigest();return read(p)
stages=take('Assets/Module/Activity/SplashQuest/Config/Data/stage.json~')
levels=take('Assets/Game/TileV2/Config/TableConfig/levels.json~')
groups={x['id']:x for x in take('Assets/Game/TileV2/Config/TableConfigLevelGroup/levelgroup.json~')}
types=[]
for level in levels[:500]:
 data=take('Assets/Game/TileV2/Config/LevelConfig/'+groups[level['levelGroup']]['levelPath']+'.json')
 types.append(3 if data['LevelType']==5 else 4 if level['TutorialType']==1 else level['hard'] if data['LevelType']==2 else 0)
assert types==old['levelTypes'][:500]
consume=take('Assets/Game/TileV2/Config/TableConfigLevelControlV3/ddav3consumeconfig.json~')
buy=take('Assets/Game/TileV2/Config/TableConfig/tilepropbuycfg.json~')
revive=take('Assets/Game/TileV2/Config/TableConfig/levelrevive.json~')
prop=[]
for typ,item in [(10,11),(11,14),(12,13),(13,12)]:
 row=next(x for x in buy if x['id']==item)
 for src in ['Inventory','Ad']:
  rate=next(x['recoveryPerUnit'] for x in consume if x['propType']==typ and x['source']==src)
  value=row['consume'][1]/row['buyCount']*rate/100;assert int(value)==value
  prop.append({'type':typ,'item':item,'source':src,'value':int(value)})
for rel in ['Assets/Module/Activity/SplashQuest/Scripts/ActSplashQuest.PeopleRule.cs','Assets/Game/TileV2/Scripts/DataCenter/TileMatchDataCenter.Recovery.cs','Assets/Game/TileV2/Scripts/Entry/TileMatch.cs']:
 hashes[rel]=hashlib.sha256((r/rel).read_bytes()).hexdigest()
inputs={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'stages':stages,'tiers':old['tiers'],'levelTypes':types,'propValues':prop,'revive':revive,'consume':consume,'entryGroups':{'protection':[55,104],'regular':[105,200]},'weighting':'entry levels equally weighted for reference only, not player weights','sourceHashes':hashes}
(o/'inputs.json').write_text(json.dumps(inputs,ensure_ascii=False,indent=2))
shutil.copy('/tmp/splashquest_sim_20261116/NuGet.Config',o/'NuGet.Config')
(o/'Sim.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net10.0</TargetFramework><EnableDefaultCompileItems>false</EnableDefaultCompileItems><ImplicitUsings>enable</ImplicitUsings><Nullable>disable</Nullable><NoWarn>CS0436</NoWarn></PropertyGroup><ItemGroup><Compile Include="Calculator.cs"/><Compile Include="Program.cs"/><Reference Include="UnityEngine.CoreModule"><HintPath>/Applications/Unity/Hub/Editor/6000.0.60f1/Unity.app/Contents/Managed/UnityEngine/UnityEngine.CoreModule.dll</HintPath></Reference></ItemGroup></Project>''')
print('Prepared 500 current level types, unchanged source methods, existing 3 coefficient families, DDAV3 valuation',prop)
