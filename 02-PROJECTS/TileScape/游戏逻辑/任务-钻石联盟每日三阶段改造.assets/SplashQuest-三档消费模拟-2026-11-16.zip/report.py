from pathlib import Path
import json,csv,io,html,hashlib,zipfile,math
p=Path('/tmp/splashquest-consumption-20261116');out=p/'delivery';out.mkdir(exist_ok=True)
data=json.loads((p/'results.json').read_text());rows=data['rows'];inp=json.loads((p/'inputs.json').read_text());ver=json.loads((p/'verification.json').read_text())
cn={'more':'多发','normal':'正常','less':'少发','current_A':'当前层1','current_B':'当前层2','current_C':'当前 C（层3/4/5）'}
labels={'no_spend':'无消费直接完成','free_retry1_last':'每阶段末关失败1次再完成','free_retry3_last':'每阶段末关失败3次再完成','free_retry10_last':'每阶段末关失败10次再完成','free_retry3_first':'每阶段首关失败3次再完成','free_retry3_mid':'每阶段中段失败3次再完成','free_retry20_first':'每阶段首关失败20次再完成','paid900_early':'每阶段首关复活1次（各900）','paid900_late':'每阶段末关复活1次（各900）','paid2800_same_level':'每阶段首关复活2次（各2800）','paid900_each_level':'每关复活1次（22×900）','paid_fail3_first':'每阶段首关付900后失败3次，再无消费完成','paid_fail3_last':'每阶段末关付900后失败3次，再无消费完成','paid_fail10_last':'每阶段末关付900后失败10次，再无消费完成','inventory_single10':'每阶段用1个库存撤回','inventory_single11':'每阶段用1个库存移出','inventory_single12':'每阶段用1个库存自动配对','inventory_single13':'每阶段用1个库存洗牌','inventory_four_pack':'每阶段各用1个四种库存道具','inventory_auto_each_level':'每关用1个库存自动配对','inventory_retry3_last':'每阶段末关失败3次，所有尝试每关用库存自动配对','paid900_plus_auto_each_level':'每阶段首关复活900＋每关库存自动配对','ad_revive900':'每阶段1次广告复活（报价900）','ad_auto_once':'每阶段广告获得并用1个自动配对','unlimited_auto_once':'每阶段用1次无限自动配对'}
def get(cohort,tier,scenario,family=None):
 family=family or ('C' if cohort=='protection' else {'more':'A','normal':'B','less':'C','current_A':'A','current_B':'B','current_C':'C'}[tier])
 return next(r for r in rows if r['cohort']==cohort and r['pack']['Name']==tier and r['pack']['Family']==family and r['scenario']['Name']==scenario)
def n(x):return f'{x:,.1f}'
def cell(s):return n(s['mean'])+' / '+n(s['netAssetMean'])
def table(head,items):return '| '+' | '.join(head)+' |\n|'+ '|'.join('---' for _ in head)+'|\n'+''.join('| '+' | '.join(map(str,r))+' |\n' for r in items)

# Check consequence invariants and ordinal means; preserve exceptions as findings rather than changing the model.
index={(r['cohort'],r['pack']['Name'],r['pack']['Family'],r['scenario']['Name']):r for r in rows}
invariants=0;exceptions=[]
for r in rows:
 key=(r['cohort'],r['pack']['Name'],r['pack']['Family']);sc=r['scenario']['Name']
 baseline='free_retry3_last' if sc=='inventory_retry3_last' else 'paid900_early' if sc=='paid900_plus_auto_each_level' else 'no_spend'
 if sc.startswith('inventory') or sc.startswith('ad_') or sc.startswith('unlimited') or sc=='paid900_plus_auto_each_level':
  b=index[(*key,baseline)]
  for s,t in zip(r['stages'],b['stages']):
   assert s['stats']['distribution']==t['stats']['distribution'];invariants+=1
 for s in [x['stats'] for x in r['stages']]+[r['total']]:
  assert math.isclose(s['mean']-s['diamondPaid']-s['inventoryValue'],s['netAssetMean'],abs_tol=1e-6)
 # Funding bounds: rewards credited only at stage ends; no external income/purchases.
 paid=0;bestPrior=0;worstPrior=0;needBest=0;needWorst=0
 for s in r['stages']:
  v=s['stats'];paid+=v['diamondPaid'];needBest=max(needBest,paid-bestPrior);needWorst=max(needWorst,paid-worstPrior);bestPrior+=v['max'];worstPrior+=v['min']
 r['minimumInitialDiamondsRange']=[needBest,needWorst]
for co in ['protection','regular']:
 for f in 'ABC':
  for sc in labels:
   a=[get(co,t,sc,f)['total']['mean'] for t in ['more','normal','less']]
   if not(a[0]>=a[1]>=a[2]):exceptions.append({'cohort':co,'family':f,'scenario':sc,'means':a})
ver.update({'configBytesJsonChecks':{'ddav3consumeconfig':10,'tilepropbuycfg':7,'levelrevive':5},'propAndAdRewardIdentityChecks':invariants,'sameCoefficientOrdinalMeanExceptions':exceptions,'sourceMethodEdits':False})
(p/'verification.json').write_text(json.dumps(ver,ensure_ascii=False,indent=2));(p/'results.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')))
flat=[]
for r in rows:
 for stage,s in [(x['stage'],x['stats']) for x in r['stages']]+[(0,r['total'])]:
  flat.append({'cohort':r['cohort'],'entry_min':r['entryMin'],'entry_max':r['entryMax'],'tier':r['pack']['Name'],'coefficient':r['pack']['Family'],'scenario':r['scenario']['Name'],'stage':stage,**{k:v for k,v in s.items() if k not in ('distribution','inventoryConsumed')},'inventoryConsumed':json.dumps(s['inventoryConsumed'],ensure_ascii=False)})
buf=io.StringIO();writer=csv.DictWriter(buf,fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat);(out/'scenarios.csv').write_text('\ufeff'+buf.getvalue())

main='''#### 三档消费模拟 R1（按当前逻辑，2026-11-16）

用户确认先保留 C1～C4 待程序确认，模拟按当前逻辑执行，具体系数不改。使用前述 R0 三档人数候选；保护组将三档均配当前第 5 层 C 系数，另保留当前第 5 层完整参数对照。常规组以多发 A／正常 B／少发 C 比较，并补齐三档×A/B/C 的同系数对照；候选调整步长沿用 R0 的 1，当前 C 基线保留 2；补偿系数和关型权重未变。这些是离线输入，未改游戏配置或确认保护组目标档位。

**统计口径**：保护组按活动选组时下一关 55～104 扫描，常规对照扫描 105～200；一期内跨过 105 仍保留原分组。每个入口关卡等权、人数随机分支精确枚举，先按指定失败／消费路径，再完成三个阶段。下表是“三阶段全部完成”的条件发放与活动相关净资产变化，不是线上参与者均值或实际到账保证。净资产＝活动奖励−实付钻石−已消耗库存道具的 DDAV3 存量价值；不含主线过关奖励、其他活动收入、购买补充和时间／体力成本。不预设道具、复活对胜率的提升。

**保护组：同 C 系数下的三档差异**。每格为“发放均值 / 净资产变化”，单位为钻石等值。“每阶段”表示三个阶段都执行一次该消费或重试安排。

'''
chosen=['no_spend','free_retry3_last','free_retry10_last','free_retry20_first','paid900_early','paid900_late','paid2800_same_level','paid_fail3_last','inventory_single12','inventory_auto_each_level','paid900_plus_auto_each_level']
main+=table(['固定行为场景','当前保护组','多发候选','正常候选','少发候选'],[[labels[sc]]+[cell(get('protection',t,sc)['total']) for t in ['current_C','more','normal','less']] for sc in chosen])
main+='''
**保护组分阶段首次无消费发放范围**（三阶段为 5/7/10 关）：

'''
main+=table(['配置','第一阶段','第二阶段','第三阶段','全通范围'],[[('当前保护组（层5）' if t=='current_C' else cn[t])]+[str(s['stats']['min'])+'～'+str(s['stats']['max']) for s in get('protection',t,'no_spend')['stages']]+[str(get('protection',t,'no_spend')['total']['min'])+'～'+str(get('protection',t,'no_spend')['total']['max'])] for t in ['current_C','more','normal','less']])
main+='''
**常规组与系数对照**：无消费三档全通均值同为 3579.5／2646.0／1740.5；每阶段首关复活 900 时，按 A/B/C 原对应关系为 3778.5／2992.5／1992.0，净资产为 +1078.5／+292.5／−708.0。保护组的正常档采用 C 时为 2902.0／净 +202.0。同样人数下，正常档 A/B 比 C 多 90.5；多发档首关同关复活两次，A/B 发 4275.0、C 发 4096.0。系数差异是离散触发效果，不能按系数倍数线性放大奖励。完整阶段分布及所有同系数对照见附件。

若最终未完成当前阶段，该阶段发放为 0，净资产变化为负的累计消耗。例如同一阶段 3 次各花 900 复活后仍失败并退出，则该阶段发放 0、净钻石 −2700，额外道具另扣；此前阶段已领取的奖励不追回。主表是重试后最终完成的分支，不含退出概率。

**本轮读数与下一步判断**：

- 三档在本轮固定行为下的均值保持多发≥正常≥少发；在同样消费下，净资产差距等于发放差距。这不表示跨行为区间不重叠，也不表示三档对同一玩家的完成率相同。
- 当前保护组首次全通 1891.5，新的少发候选仅 1740.5；每阶段末关免费失败 10 次后，当前为 2805.97、少发仅 2024.41。每阶段首关免费失败 20 次后，当前约 4469.17，还超过多发候选约 4274.99。原因是现有第二／三阶段 min=10/5，而候选收紧了人数下限；保护组不能直接按“原来层 5 数值较低”迁到少发。
- 900 复活不是返 900：保护组多发候选每阶段首关各花 900，总花 2700，全通发放仅比无消费多 199；第三阶段单次 900 在本轮覆盖路径下不增加奖励。阶段末关消费通常更少获得后续补偿机会。
- 道具不增加活动补偿：每阶段用 1 个库存自动配对共折算 2700，三档发放不变，净资产为 +879.5／−54.0／−959.5。每关用 1 个则共消耗 22 个、折算 19800，属于高消费压力样例，不代表前期用户常态。
- DDAV3 当前库存单价为撤回 500、移出 900、自动配对 900、洗牌 1300；广告与库存消费配置比例均为 100%。广告取得并立即使用的道具不减少原有净库存，广告复活不扣钻石，但满足 V3 有效记录条件时仍有回收折算；不能将“奖励减有效回收”误写为真实资产净变化。无限道具不消耗有限库存时，本口径不计其存量扣减或有效回收。
- 付费失败重试保留了旧余额问题及负余额，不截零、不修正。报告的负余额路径概率只针对指定行为与随机分支，不是线上问题发生率；这些场景的绝对数值仍随未来代码确认结果变化。
- 本轮足以比较在既定完成路径下的发放、资源负担与档位差距；尚不能证明保护效果或最终选择某档。下一轮优先明确保护组希望覆盖的消费水平，再结合完成／退出数据评估净资源；当前不调系数、不改分组、不接活动 DDA。

**复核与附件**：原计算方法未改，直接使用 Unity 6000.0.60f1 的 Mathf 做离线计算；重新解析 500 个本地关卡，重试每通过一关就推进主线并在新一轮重取类型序列。25 个行为场景×12 个参数／系数组合×2 个入口区间，共 600 行组合、2400 个阶段／全通分布；180 项独立二项分布核对、576 项余额转移与关型独立性核对通过。三张消费／价格表 bytes 与 JSON 对齐。失败立即手动重试、期内时间与消费库存充足、奖励成功入账均为本次情景假设；没有模拟 UI 故障、关中重启、玩家胜率或在线配置覆盖。报告包含最低初始钻石需求，避免把高消费压力路径当作所有低余额用户都能走的路径。

附件：[[02-PROJECTS/TileScape/游戏逻辑/任务-钻石联盟每日三阶段改造.assets/SplashQuest-三档消费模拟-2026-11-16.html|完整模拟报告与筛选表]]；[[02-PROJECTS/TileScape/游戏逻辑/任务-钻石联盟每日三阶段改造.assets/SplashQuest-三档消费模拟-2026-11-16.zip|场景明细与复现包]]。

'''
(p/'result-section.md').write_text(main)

def esc(x):return html.escape(str(x))
def ht(head,items):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(x)+'</td>' for x in row)+'</tr>' for row in items)+'</tbody></table></div>'
h=['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SplashQuest 三档消费模拟</title><style>body{margin:0;background:#f1f5f7;color:#183044;font:15px/1.65 system-ui,sans-serif}main{max-width:1350px;margin:24px auto;padding:32px;background:white;border-radius:14px}h1{font-size:29px}h2{margin-top:32px;font-size:22px}p{max-width:1100px}.callout{padding:16px;background:#edf6f3;border-left:4px solid #168466}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:9px 11px;border-bottom:1px solid #dce5ea;text-align:right;white-space:nowrap}td:first-child,th:first-child{text-align:left}th{background:#eaf1f6}tbody tr:nth-child(even){background:#f8fafb}.note{color:#567;font-size:13px}select{padding:7px;margin:5px;border:1px solid #bac9d4;border-radius:5px}label{display:inline-block}a{color:#087c75}@media print{main{margin:0;padding:0}select{display:none}}</style><main><h1>SplashQuest 三档消费模拟</h1><p>2026-11-16 · 按当前代码计算 · 原有 A/B/C 系数不变 · 游戏代码及配置未修改</p>']
h+=['<div class="callout">三档首次发放可以拉开；当前保护组在多次免费重试后可能超过候选。复活补偿取决于消费位置，道具消耗目前不增加活动奖励。以上为指定路径最终完成时的结果。</div>', '<h2>1. 比较口径</h2>', '<p>保护组按活动选组时下一关55～104独立扫描，三档统一保留第5层C系数；常规组扫描105～200，主表采用多发A／正常B／少发C，并提供完整交叉对照。全通表指每个阶段均执行所列行为，最终完成5+7+10关。失败期间已胜的主线关卡会推进；跨105仍保留原分组。入口关卡等权只是技术参考，不是线上人群权重。</p>', '<p><b>净资产变化＝活动发放−实付钻石−消耗的原有库存价值。</b>不含主线／其他活动收入、购买补充或时间体力。库存价值按DDAV3折算；“奖励减有效回收”另列，不作为真实净资产。指定复活和道具有效使用、库存足够、即时手动重试、期内完成、领奖入账成功；没有假设道具能提高多少胜率，也没有修改现有负余额逻辑。</p>']
h.append(ht(['候选','E 5/7/10','min','max','步长'],[[cn[t['name']],t['expected'],t['mins'],t['maxs'],1] for t in inp['tiers']]))
h+=['<h2>2. 前期保护组：统一C系数</h2>','<p>每格：发放均值 / 净资产变化；单位为钻石等值。</p>',ht(['场景','当前保护组','多发','正常','少发'],[[labels[sc]]+[cell(get('protection',t,sc)['total']) for t in ['current_C','more','normal','less']] for sc in chosen])]
h+=['<h2>3. 保护组发放范围与净资源范围</h2>', '<p>每格：发放最小～最大；括号内净资产最小～最大。均为本轮覆盖入口和随机分支的条件范围，不是置信区间或系统理论上限。</p>',ht(['场景','多发','正常','少发'],[[labels[sc]]+[f"{get('protection',t,sc)['total']['min']}～{get('protection',t,sc)['total']['max']}（{get('protection',t,sc)['total']['netAssetMin']}～{get('protection',t,sc)['total']['netAssetMax']}）" for t in ['more','normal','less']] for sc in ['no_spend','free_retry3_last','free_retry10_last','paid900_early','paid900_late','paid2800_same_level','paid_fail3_last','inventory_single12']])]
h+=['<p>若最终放弃当前阶段，该阶段发放0、净变化为负的累计消耗；例如3次各花900后仍失败退出，该阶段净钻石−2700，额外道具另扣，之前阶段已领奖励不追回。主表不包含退出概率。</p>','<h2>4. 常规组：原系数对应关系</h2>',ht(['场景','多发 A：发放 / 净资产','正常 B：发放 / 净资产','少发 C：发放 / 净资产'],[[labels[sc]]+[cell(get('regular',t,sc)['total']) for t in ['more','normal','less']] for sc in chosen[:9]]),'<h2>5. 同人数包，只比较现有系数</h2>',ht(['候选','场景','A发放','B发放','C发放'],[[cn[t],labels[sc]]+[n(get('regular',t,sc,f)['total']['mean']) for f in 'ABC'] for t in ['more','normal','less'] for sc in ['paid900_early','paid900_late','paid2800_same_level','paid_fail3_last']])]
h+=['<h2>6. 消费计价与可达条件</h2>',ht(['道具／来源','实际资产扣减','满足V3有效记录条件的回收值','活动补偿输入'],[['库存撤回','1个，等值500',500,0],['库存移出','1个，等值900',900,0],['库存自动配对','1个，等值900',900,0],['库存洗牌','1个，等值1300',1300,0],['付费复活','实际支付900；同关两次共2800','与实付相同','与实付相同'],['广告复活','0钻石','示例报价900→900',0],['广告获得并使用自动配对','获得1个再用1个，净库存0',900,0],['无限自动配对','不扣有限库存',0,0]]),'<p>库存道具已持有，不等于本次花钻购买；若实际走购买流程，应同时计支付和新增／剩余库存，不能再重复扣道具价值。实际 V3 未启用、未成功应用或未消耗有限库存时，有效回收可能为0，表中是满足条件后的口径。</p>',ht(['保护组候选','全通消费路径','实付合计','完成路径所需初始钻石范围'],[[cn[t],labels[sc],get('protection',t,sc)['total']['diamondPaid'],'～'.join(map(str,get('protection',t,sc)['minimumInitialDiamondsRange']))] for t in ['more','normal','less'] for sc in ['paid900_early','paid2800_same_level','paid900_each_level']]),'<p>初始钻石需求只考虑阶段结束领取的活动奖励可用于后续支付，其他收入为0；区间来自奖励随机分支。每关消费样例需要充足钻石或库存，属于压力对照，不代表普通前期玩家可直接走完。</p>']
h+=['<h2>7. 全部阶段与全通结果</h2>','<p>可筛选入口区间、人数包、系数、场景和阶段。均值与分位基于入口关卡等权及精确人数随机；min/max包含所有该组合扫描结果。负余额率为出现负补偿余额的路径概率，不是线上发生率。</p>']
selectors=[('co','入口',[('protection','55～104保护入口'),('regular','105～200常规对照')]),('tier','人数包',[(k,v) for k,v in cn.items()]),('fam','系数',[(x,x) for x in 'ABC']),('scene','场景',list(labels.items())),('stage','阶段',[(str(x),('全通' if x==0 else '阶段'+str(x))) for x in [0,1,2,3]])]
for id,label,options in selectors:
 h.append('<label>'+label+'<select id="'+id+'"><option value="">全部</option>'+''.join('<option value="'+esc(v)+'">'+esc(t)+'</option>' for v,t in options)+'</select></label>')
small=[]
for r in flat:
 small.append([r['cohort'],r['tier'],r['coefficient'],r['scenario'],str(r['stage']),round(r['mean'],3),r['min'],r['max'],r['p05'],r['p50'],r['p95'],round(r['netAssetMean'],3),r['netAssetMin'],r['netAssetMax'],r['diamondPaid'],r['inventoryValue'],r['effectiveRecovery'],round(r['rewardMinusRecoveryMean'],3),round(r['negativeBalanceProbability']*100,3)])
h+=['<p id="count" class="note"></p><div class="scroll"><table><thead><tr>'+''.join('<th>'+v+'</th>' for v in ['入口','人数包','系数','场景','阶段','发放均值','最小','最大','P05','P50','P95','净资产均值','净最小','净最大','实付钻石','库存折值','有效回收','奖励−回收','负余额率%'])+'</tr></thead><tbody id="grid"></tbody></table></div>']
h.append('<script>const rows='+json.dumps(small,ensure_ascii=False)+';const tiers='+json.dumps(cn,ensure_ascii=False)+';const scenes='+json.dumps(labels,ensure_ascii=False)+''';const ids=['co','tier','fam','scene','stage'];function show(){let filters=ids.map(id=>document.getElementById(id).value),filtered=rows.filter(r=>filters.every((v,i)=>!v||r[i]===v));document.getElementById('count').textContent=filtered.length+' 条结果';const body=document.getElementById('grid');body.replaceChildren();for(const r of filtered){const tr=document.createElement('tr');r.forEach((v,i)=>{const td=document.createElement('td');td.textContent=i===0?(v==='protection'?'保护入口':'常规对照'):i===1?tiers[v]:i===3?scenes[v]:i===4?(v==='0'?'全通':v):v;tr.append(td)});body.append(tr)}}ids.forEach(id=>document.getElementById(id).addEventListener('change',show));document.getElementById('co').value='protection';document.getElementById('fam').value='C';document.getElementById('scene').value='no_spend';document.getElementById('stage').value='0';show();</script>''')
h+=['<h2>8. 证据与边界</h2>','<p>源码版本 '+esc(inp['head'])+'。使用原方法及实际 Unity Mathf 进行离线计算；500个本地关卡重新解析，远端动更／AB关卡替换不在本次覆盖内。600个组合、2400个分布，180项独立二项分布核对、576项余额转移与关型独立性核对、'+str(invariants)+'项道具／广告发放一致性核对通过。同系数三档均值倒序案例：'+str(len(exceptions))+'。消费配置10行、道具价格7行、复活价格5行 bytes/JSON 对齐。未进行Unity业务运行、设备或线上验证。</p>','<p>代码问题仍保留待原程序确认。关中重启丢记录、领奖失败等异常没有被擅自修复，也未为它们假设发生概率；主表按无此异常的完整消费与结算路径计算。负补偿余额算术已原样保留。</p>','<p><a href="SplashQuest-三档消费模拟-2026-11-16.zip">下载场景CSV、完整结果、输入及复现包</a></p></main></html>']
(out/'SplashQuest-三档消费模拟-2026-11-16.html').write_text('\n'.join(h))
(p/'README.md').write_text('''# SplashQuest 三档消费模拟 R1

2026-11-16，按当前游戏算法和原系数运行，所有配置替换仅存在于分析输入。

报告 HTML 可直接打开；CSV stage=0 表示全通，1/2/3 表示阶段；results.json 保存全分布，inputs.json 保存原表、候选、500个本地关型、DDAV3计价与源码哈希。报表中的概率只针对指定行为、入口关卡等权、人数随机分支，不是线上人群概率。

保护组在选组时下一关55～104，期间跨105不换系数。常规入口扫描105～200。全部成功／失败／消费都是情景输入，未运行DDA求胜率，也未假设额外活动调控。重试通过的主线关卡继续推进，重新取得下一轮关型；通过独立检查确认余额转移与类型序列无关，因此余额分布可预计算，发放仍按实际最终序列计算。

库存消耗按DDAV3价值计净资产；广告获得立即使用不扣原有净库存，有效回收另列。无限道具不扣有限库存。主线奖励、其他活动收入、购买补充和时间体力不在净资产口径。高消费样例需要足够库存／初始钻石。全通数值不可充当参与者日均。

复现需要.NET10与项目使用的Unity6000.0.60f1 CoreModule程序集；按本机位置修改Sim.csproj引用路径后，在包目录运行 dotnet run --project Sim.csproj -c Release。不依赖Unity随机种子流，随机人数的每个合法结果精确枚举；Mathf使用Unity原程序集。prepare.py用于重新取本机项目输入，路径需按环境调整。report.py生成报表和指标检查。configcheck包含三表bytes/JSON校验工具。

没有修复C1负余额；没有为C2重启或C3入账异常编造概率，按完整有效结算路径计算；C4分桶不在本次动态改动范围。不要把本包当作可导入游戏的生产配置。
''')
with zipfile.ZipFile(out/'SplashQuest-三档消费模拟-2026-11-16.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['README.md','inputs.json','results.json','verification.json','Calculator.cs','Program.cs','Sim.csproj','NuGet.Config','prepare.py','report.py']:z.write(p/name,name)
 z.write(out/'scenarios.csv','scenarios.csv')
 for name in ['Program.cs','Check.csproj','DDAV3ConsumeConfig.cs','TilePropBuyCfg.cs','LevelRevive.cs','NuGet.Config']:z.write(p/'configcheck'/name,'configcheck/'+name)
 for rel in ['Assets/Module/Activity/SplashQuest/Config/Data/stage','Assets/Game/TileV2/Config/TableConfig/levelrevive','Assets/Game/TileV2/Config/TableConfig/tilepropbuycfg','Assets/Game/TileV2/Config/TableConfigLevelControlV3/ddav3consumeconfig']:
  for ext in ['.json~','.bytes']:
   f=Path('/Users/dean/TileScape')/(rel+ext);z.write(f,'snapshots/'+f.name)
with zipfile.ZipFile(out/'SplashQuest-三档消费模拟-2026-11-16.zip') as z:assert z.testzip() is None
print(json.dumps({'resultRows':len(flat),'propIdentityChecks':invariants,'ordinalExceptions':exceptions,'artifacts':[(x.name,x.stat().st_size) for x in out.iterdir()]},ensure_ascii=False))
