---
tags: [TileMatch, 游戏逻辑, MOC]
status: draft
date: 2026-07-01
workbuddy_sync: true
---

# 局内障碍知识库 MOC

> 覆盖局内两种障碍体系：Tile 自身的障碍牌 + 挂载在 Tile 上的 Effect 层。

## 两大体系

| 体系 | 定义 | 作用 |
|------|------|------|
| **障碍牌** | TileType >= 5000 的特殊 Tile | 独立占据棋盘格子，可进 Bar，有序列子牌 |
| **Effect** | 挂载在 Tile/Board 上的装饰层 | 不占格子，遮挡/阻挡/改变交互 |

---

## Effect 牌（16 种 + 方向变体）

📁 目录：[[Effect/Effect牌-类型全览|Effect 牌类型全览]]

| 分类 | Effect | 笔记 |
|------|--------|------|
| 受击护盾 | Golden 金砖 | [[Effect/Effect-Golden]] |
| 受击护盾 | Crate 木箱 | [[Effect/Effect-Crate]] |
| 受击护盾 | Ice 冰块 | [[Effect/Effect-Ice]] |
| 受击护盾 | Stone 石板 | [[Effect/Effect-Stone]] |
| 受击护盾 | Pig 小猪 | [[Effect/Effect-Pig]] |
| 受击护盾 | Ice2x2 冰块2×2 | [[Effect/Effect-Ice2x2]] |
| 受击护盾 | Cookie 饼干 | [[Effect/Effect-Cookie]] |
| 可见消除 | Cloud 云朵 | [[Effect/Effect-Cloud]] |
| 可见消除 | GiftBox 礼盒 | [[Effect/Effect-GiftBox]] |
| 可见消除 | Grass 草丛 | [[Effect/Effect-Grass]] |
| 可见消除 | Jelly 果冻 | [[Effect/Effect-Jelly]] |
| 点击交互 | Cirrus 云层 | [[Effect/Effect-Cirrus]] |
| 点击交互 | Mystery 神秘盒 | [[Effect/Effect-Mystery]] |
| 状态切换 | Curtain 帷幕 | [[Effect/Effect-Curtain]] |
| 链接传递 | Chain 锁链 | [[Effect/Effect-Chain]] |

---

## 障碍牌（8 大类，33 种变体）

📁 目录：[[障碍牌/障碍牌-类型全览|障碍牌类型全览]]

| 分类 | 笔记 |
|------|------|
| 可点击消除 | [[障碍牌/障碍牌-Rocket\|Rocket 火箭牌]] |
| 容器系列 | [[障碍牌/障碍牌-ShellBox\|ShellBox 贝壳盒]] |
| 容器系列 | [[障碍牌/障碍牌-容器系列\|MagicBox/SlotMachine/CardBox/SuitCase]] |
| 翻转系列 | [[障碍牌/障碍牌-翻转系列\|Flip/JokerFlip/Switch]] |
| 收集系列 | [[障碍牌/障碍牌-CandyCube系列\|CandyCube 糖果系列]] |
| 配对体系 | [[障碍牌/障碍牌-Ore系列\|Ore矿石 + Pickaxe镐]] |
| 特殊机制 | [[障碍牌/障碍牌-特殊机制\|Butterfly/Clock/Volcano等]] |

---

## 通用机制

| 笔记 | 内容 |
|------|------|
| [[Effect/Effect牌-ECA行为引擎\|ECA 行为引擎]] | JSON → Event/Condition/Action 映射 |
| 障碍Tile生成与序列逻辑 | [[分析-障碍Tile生成与序列逻辑-v1]] |

---

## 后续计划

- [x] 创建障碍牌-类型全览（33 种 TileType >= 5000）
- [ ] 创建 Effect牌-ECA行为引擎（通用框架）
- [ ] 交互式知识库网页
- [ ] Skill 形式可查询
