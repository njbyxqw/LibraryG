---
tags: [TileMatch, 游戏逻辑, Effect牌]
status: draft
date: 2026-07-01
workbuddy_sync: true
---

# Effect：Ice2x2 冰块 2×2

详细说明见 [[Effect-Ice]]（与 Ice 1×1 并列对比）。

## 快速速查

| 属性 | 值 |
|------|-----|
| EffectType | `200` |
| 尺寸 | 2×2 |
| 血量 | 4 |
| 伤害源 | `4`（AddToBar） |
| TakeOverDestroy | ✅ |
| ITileViewCustomControl | ✅ |
| 入场动画 | ✅（整块掉落 _fallAsWhole） |

## 关联笔记

- [[Effect-Ice]]
- [[Effect牌-类型全览]]
- [[../局内障碍知识库_MOC]]
