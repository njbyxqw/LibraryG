---
tags: [TileMatch, 游戏逻辑, 障碍牌]
status: draft
date: 2026-07-01
workbuddy_sync: true
---

# 障碍牌：Rocket 火箭牌

## 基础属性

| 属性 | 值 |
|------|-----|
| TileType | `5000` |
| Group | `Blocker` |
| Tags | `Blocker` |
| MatchCount | `3`（可点击匹配进 Bar） |
| 尺寸 | 1×1（Fixed） |
| 血量 | 1 (`Life: {"0": 1}`) |
| 配置文件 | `TileConfig/Rocket.json` |

---

## 数据层：配置 & 深度策略

- **MatchCount=3**：3 个同花色火箭牌可以匹配消除
- **深度控制**：`RocketDepthStrategy.cs` 决定火箭牌在关卡中的生成深度（通常较浅，确保可被发现）
- **生成规则**：由 DDA（动态难度调控）控制生成概率

---

## 逻辑层：ECA 行为引擎（5 条规则）

### ① Rocket_TileClicked — 点击进 Bar（`5000001`）

| 层级 | 内容 |
|------|------|
| **事件** | `TileClicked`（SourceSelector=25） |
| **条件** | `BarHasSpace(1)` 且 `Lives >= 1` |
| **动作** | 发射 3 次 Attack → `AddToBar(Click)` |

三次 Attack 发射：

| Attack | TargetSelectorType | DamageSourceType | 含义 |
|--------|-------------------|-----------------|------|
| 1 | `2` | `1` | Tap 伤害（点触本身） |
| 2 | `1` | `4` | AddToBar 伤害（进 Bar） |
| 3 | `4` | `2` | 范围伤害（炸弹波及） |

### ② Rocket_BarChanged — 匹配检查（`5000002`）

| 层级 | 内容 |
|------|------|
| **事件** | `BarChanged` |
| **条件** | — |
| **动作** | `BarMatch` — 触发 Bar 匹配检测 |

### ③ Rocket_BarMatched — 匹配后攻击（`5000003`）

| 层级 | 内容 |
|------|------|
| **事件** | `BarMatched` |
| **条件** | — |
| **动作** | `PrepareAttack(TargetFilter="Rocket", MaxTarget=6)` |

> 匹配消除后，火箭牌准备对最多 6 个目标发射链式攻击。

### ④ Rocket_Attack_When_Direct_TileDestroyed（`5000004`） `Once=true`

| 层级 | 内容 |
|------|------|
| **事件** | `TileDestroyed` |
| **条件** | `StateEquals(1)` |
| **动作** | `EmitEvent(Attack, TargetSelectorType=4, DamageSourceType=2)` |

> 当火箭牌被直接摧毁（如被炸弹波击毁），发射一次范围伤害。

### ⑤ Rocket_TileDestroyed（`5000005`） `Once=true`

| 层级 | 内容 |
|------|------|
| **事件** | `TileDestroyed` |
| **条件** | — |
| **动作** | `DestroyTile` → 最终销毁 |

---

## 视图层

| 模块 | 文件 | 职责 |
|------|------|------|
| 视觉特效 | `RocketViewAction.cs` | 爆炸动画、链式特效 |
| 闪电球 | `RocketVLLightingViewAction.cs` | 闪电球视觉替换（RocketVL） |

---

## 可见性规则

- 火箭牌是普通 Blocker Tile，没有特殊可见性限制
- 标准 VisibilityState 体系：被遮挡→不可交互，暴露后→高亮可点击

---

## 关联笔记

- [[RocketV2-完整逻辑（重构版）]]
- [[RocketVL-闪电球视觉替换]]
- [[障碍牌-类型全览]]
- [[../局内障碍知识库_MOC]]
