---
tags: [TileMatch, 游戏逻辑, 障碍牌]
status: draft
date: 2026-07-01
workbuddy_sync: true
---

# 障碍牌：ShellBox 贝壳 + MagicBox 魔法盒

ShellBox 和 MagicBox 逻辑高度一致，区别仅在于开口方向和内部序列。

---

## 变体

| 变体 | TileType | 开口方向 | 可见内部 |
|------|----------|---------|---------|
| ShellBoxUp | 5030 | 上方开口（向 (0,-2) 弹出） | ✅ ShellBox |
| ShellBoxDown | 5031 | 下方 | ✅ |
| ShellBoxLeft | 5032 | 左方 | ✅ |
| ShellBoxRight | 5033 | 右方 | ✅ |
| ShellBoxOpaqueUp | 5040 | 上方 | ❌ 不透明 |
| ShellBoxOpaqueDown | 5041 | 下方 | ❌ |
| ShellBoxOpaqueLeft | 5042 | 左方 | ❌ |
| ShellBoxOpaqueRight | 5043 | 右方 | ❌ |
| MagicBox | 5010 | 上方（向 (0,2) 弹出） | ✅ |

---

## 共同基础属性

| 属性 | 值 |
|------|-----|
| Group | `Blocker` |
| MatchCount | `0` |
| 尺寸 | 1×1（Fixed） |
| CoveredTileIgnoreVisible | `true`（内部子牌覆盖时忽略可见性） |
| CustomTileController | `ShellBoxTileController` / `MagicBoxTileController` |
| SequenceDepthMode | `2` |
| 血量 | 1 (`Life: {"0": 1}`) |

---

## 数据层：配置

- **序列子牌**：关卡编辑器中配置 Sequences，每张子牌可设置不同花色
- **SequenceDepthMode=2**：影响序列在深度排序中的位置
- ShellBoxOpaque 内部子牌不可见（提高关卡难度）
- ShellBox/MagicBox 内部子牌可见（玩家可提前规划）

---

## 逻辑层：ECA 行为引擎（4 条规则，以 ShellBoxUp 为例）

### ① TryToEjectCovered — 尝试弹出子牌（`5030001`）

| 层级 | 内容 |
|------|------|
| **事件** | `LevelEnterAnimationStepOneFinished` / `AfterTileDestroyed` / `AddingToBarByClick` / `AfterAttack` / `AutoMatchUse` |
| **条件** | `SequenceCount >= 1` 且 `VisibilityState = 4`（可见）且 `GridIsEmpty`（目标格子空闲） |
| **动作** | `EjectSequenceTo(Position=(0,-2), FullCover=true)` → `UpdateSequenceState(FirstNVisible, Count=1)` |

> 目标格子检测 LayerType=3，检查相对位置 (0,-1)、(0,-2)、(1,-1)、(1,-2) 是否全部空闲。

### ② TileDestroyedWhenNoCovered — 无子牌时销毁（`5030002`） `Once=true`

| 层级 | 内容 |
|------|------|
| **事件** | `AfterAttack` / `AutoMatchUse` |
| **条件** | `SequenceCount = 0` |
| **动作** | `PlayDestroyAnim` |

### ③ UpdateStateWhenAttacked — 受击后刷新（`5030003`）

| 层级 | 内容 |
|------|------|
| **事件** | `AfterTileDestroyed` / `AddingToBarByClick` / `AfterAttack` / `AutoMatchUse` |
| **条件** | `SequenceCount >= 1`（且 >=1 个） |
| **动作** | `UpdateSequenceState` — 刷新显示 |

### ④ TileDestroyed（`5030004`） `Once=true`

| 层级 | 内容 |
|------|------|
| **事件** | `TileDestroyed` |
| **条件** | — |
| **动作** | `DestroyTile` |

---

## MagicBox 差异

| | ShellBox | MagicBox |
|------|---------|---------|
| 弹出方向 | 向开口方向 | 固定向上 (0,2) |
| GridIsEmpty 检测 | 开口方向对应格 | (0,2)/(0,3)/(1,2)/(1,3) |

---

## 视图层

| 模块 | 职责 |
|------|------|
| `ShellBoxTileController.cs` | 贝壳控制逻辑：序列可见性管理、弹出动画 |
| `MagicBoxTileController.cs` | 魔法盒控制逻辑 |
| `ShellBoxViewAction.cs` | 贝壳外观：打开/闭合动画 |
| Spine 动画 | 开盖动画 + 子牌弹出粒子效果 |

---

## 可见性 & 选中规则

| 状态 | 规则 |
|------|------|
| 被遮挡 | 不可点击 |
| 可见（VisibilityState=4） | 可点击，点击后弹出内部子牌 |
| 子牌被弹入棋盘 | 自动变为普通 Tile，可进 Bar |
| 无子牌后 | 贝壳/MagicBox 自动销毁 |

---

## 关联笔记

- [[障碍牌-类型全览]]
- [[障碍牌-容器系列]]
- [[../局内障碍知识库_MOC]]
