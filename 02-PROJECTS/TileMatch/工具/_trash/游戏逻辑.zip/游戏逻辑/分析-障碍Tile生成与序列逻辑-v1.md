---
title: 障碍 Tile 生成 / 打乱 / 牌局序列逻辑梳理
tags: [TileMatch, 游戏逻辑]
type: analysis
version: v1
status: finalized
date: 2026-06-25
---

# 障碍 Tile 生成 / 打乱 / 牌局序列逻辑梳理

> 基于 `client/Assets/Game/TileV2/Scripts/` 源码分析，2026-06-16

---

## 一、整体牌局初始化流程（时序图）

```
LevelConfig (JSON)
  │
  ├─ 1. InitLevelConfigTileType()   ← 花色分配策略
  │     ├─ ReconnectStrategy          (录像回放/断线重连)
  │     ├─ AssignTileTypeStrategy     (DDA V1，默认)
  │     └─ AssignTileTypeByDepthStrategy (DDA V2)
  │
  ├─ 2. LoadTileConfigsForLevel()   ← 加载各 TileType 的配置表
  ├─ 3. RefreshLevelConfigByTileAndEffectConfigs() ← 补全 Size/Life
  ├─ 4. InitializeDataList()        ← LevelTileConfig → TileData
  │     └─ 处理 SequenceSource (序列父子关系)
  │
  ├─ 5. ApplyBatchBindingStrategy() ← 批次绑定
  │
  ├─ 6. InitEntities()
  │     ├─ InitializeBoard()         ← 棋盘 + 所有 Tile 实体
  │     ├─ InitializeBar()           ← 暂存栏
  │     ├─ InitializeOverBar()       ← 溢出栏
  │     ├─ InitializeSequenceControl() ← 序列索引
  │     └─ InitializeBatchControl()    ← 批次索引
  │
  └─ 7. Board.InitializeFromLevelConfig()
        ├─ AddLevelTiles()           (逐个 CreateTile)
        ├─ AddLevelEffect()          (逐个 CreateEffect)
        ├─ AddGoldenEffects()        (金牌 Effect)
        ├─ ModifyTilesToGolden()     (金牌策略)
        ├─ ModifyTileToRocket()      (火箭牌策略)
        └─ UpdateAllIndexes / Visibility
```

---

## 二、花色分配策略（核心的“打乱”逻辑）

### 2.1 入口与策略选择

**文件**: `TileMatchGameLogic.Config.cs` → `InitLevelConfigTileType()`

```csharp
if (录像回放/重连) → ReconnectStrategy (直接恢复记录的花色)
else if (DDA V2)   → AssignTileTypeByDepthStrategy (按可达深度排序分配)
else (DDA V1默认)  → AssignTileTypeStrategy (按难度步频打乱)
```

### 2.2 AssignTileTypeStrategy（默认策略）

**文件**: `Module/LevelTileType/Strategy/AssignTileTypeStrategy.cs`

#### 步骤 A：统计目标数量

```csharp
targetCount = GetRandomTileCount() + GetSequenceRandomTileCount()
```

- `GetRandomTileCount()`：统计 JSON 中 `TileType == Random` 且 `SequenceSource < 0` 的 grid 数量
- `GetSequenceRandomTileCount()`：统计序列容器内部还有多少随机花色需要分配（`Sequences` 列表中的 `Random` 项 + `SequenceCount`）

#### 步骤 B：生成均匀分布的花色队列 `GetColors()`

```csharp
// 例如 4 种花色、12 个牌块：
// 生成 [0,0,0, 1,1,1, 2,2,2, 3,3,3]
// 每种颜色按 3 个一组轮转，保证每种花色数量均匀（最多差 3）
```

#### 步骤 C：按难度步频打乱 `ShuffleTileType()`

```csharp
randomStep  ← 来自 DiffStepTimeList[难度][0]
randomTime  ← 来自 DiffStepTimeList[难度][1]

// 对每个位置 i：
//   rm = Random(1, randomStep)
//   targetIndex = i + rm  (不超出数组)
//   swap(colors[i], colors[targetIndex])
//   目标颜色的 RandomTime -= 1
//   result[i] = targetColor
```

**关键点**：这里是“随机步进交换”，不是完全 Fisher-Yates 洗牌。`randomStep` 越大，元素可以跳跃越远，牌局花色分布越不整齐；`randomStep` 越小（比如 1），花色几乎保持原始均匀分布。

#### 步骤 D：应用到关卡配置

```csharp
// 第 1 轮：给所有 FromRandom 的 grid 分配花色
foreach tileConfig (FromRandom && SequenceSource < 0):
    tileConfig.TileType = 花色列表[typeIndex++]

// 第 2 轮：给所有序列容器创建子牌块
foreach tileConfig (SequenceCount > 0 或 Sequences 不为空):
    为每个序列成员创建新的 LevelTileConfig
    设置 newConfig.SequenceSource = i  (指向父级在 Tiles 列表的索引)
```

#### 序列容器的花色去重约束

**文件**: `Services/SequenceConstraints/SequenceConstraintHelper.cs`

目前以下障碍类型要求序列内花色去重（`Prefer` 级别）：

| 障碍类型 | 初始分配 | 洗牌 | DDA | 保护序列子牌 |
|---------|---------|------|-----|-------------|
| **Flip** (翻转) | Prefer | Prefer | None | ✅ 是 |
| **CardBox** (卡盒) | Prefer | Prefer | None | ✅ 是 |
| **SuitCase** (行李箱) | Prefer | Prefer | None | ✅ 是 |

`PrepareNextRandomTypeForSequence()` 方法在分配花色时，如果当前花色与已分配重复，会向后搜索一个不重复的花色进行交换。

### 2.3 AssignTileTypeByDepthStrategy（V2 策略）

**文件**: `Module/LevelTileType/Strategy/AssignTileTypeByDepthStrategy.cs`

与 V1 的核心区别是：按每个 Tile 的"可达深度"（即被多少层覆盖）排序后，将更难的花色分配给更深层的牌块。这使得牌局难度更渐进。

---

## 三、序列（Sequence）体系

### 3.1 什么是序列？

序列是 **一对多** 的 Tile 父子关系：

- **父（容器 Tile）**：一个障碍牌（如 Flip、CardBox、SuitCase），其 `TileData.Id` 作为 `SequenceId`
- **子（序列 Tile）**：多个小牌块，`TileData.SequenceId = 父的 Id`，`SequenceIndex = 0, 1, 2...`

### 3.2 序列的创建时机

在 `InitializeDataList()` 中（`TileMatchGameLogic.Config.cs`）：

```csharp
foreach tileConfig in LevelConfig.Tiles:
    if tileConfig.SequenceSource < 0:
        // 普通 Tile / 序列容器本身
        dataList.Add(new TileData(tileConfig))
    else:
        // 序列子牌
        parentId = dataList[tileConfig.SequenceSource].Id   // 父 Tile 的 Id
        index = _indexes[tileConfig.SequenceSource]++
        dataList.Add(new TileData(tileConfig, parentId, index))
        // → TileData 构造函数重载：SetSequenceId(parentId), SetSequenceIndex(index)
```

**关键层级关系**：

```
LevelConfig.Tiles[3]         ← Flip 牌（容器），SequenceCount=3
  └─ 在 RandomizeTileTypeWithLevelConfig() 中动态追加 3 个 LevelTileConfig：
      Tiles.Add(new LevelTileConfig { SequenceSource=3, ... })  ← 子牌 0
      Tiles.Add(new LevelTileConfig { SequenceSource=3, ... })  ← 子牌 1
      Tiles.Add(new LevelTileConfig { SequenceSource=3, ... })  ← 子牌 2

然后在 InitializeDataList() 中：
  dataList[3]  = TileData(Tiles[3])           ← 容器 TileData，Id=100
  dataList[N]  = TileData(Tiles[N], 100, 0)   ← 子牌 SequenceId=100, Index=0
  dataList[N+1]= TileData(Tiles[N+1], 100, 1) ← 子牌 SequenceId=100, Index=1
  dataList[N+2]= TileData(Tiles[N+2], 100, 2) ← 子牌 SequenceId=100, Index=2
```

### 3.3 SequenceData 结构

**文件**: `Data/SequenceData.cs`

```csharp
Dictionary<long, List<long>> _sequenceIds;
// key   = 容器 Tile 的 Id (SequenceId)
// value = 子牌 Tile Id 的列表 (按 SequenceIndex 排序)
```

### 3.4 SequenceControl 初始化

**文件**: `Entity/SequenceControl.cs` → `InitializeFromTileDataList()`

```csharp
// 遍历所有 TileData，把 SequenceId > 0 的加入索引
for ti in tileDataList:
    if tileData.SequenceId > 0:
        _sequenceData.AddSequence(tileData.SequenceId, tileData.Id)
// 最后按 SequenceIndex 排序
_sequenceData.Sort(comparer)
```

### 3.5 序列排序比较器

比较器按 `TileData.SequenceIndex` 排序，保证序列内的子牌始终保持正确的顺序。

---

## 四、洗牌（Shuffle）道具逻辑

### 4.1 触发流程

```
用户点击洗牌道具
  → UI: Shuffle.StartUseSkill() 播动画
  → Logic: ShuffleProp.Use()
    1. 通过 CustomTargetFilterType.ShuffleProp 过滤器选中目标 Tile
       （包含 Highlight、Visible、NotVisible、Bar、OverBar 中的所有 Tile）
    2. TileService.ExchangeTilePairsPosition(targets)
    3. 重置所有参与 Tile 的 CanJoinDDA = true
    4. 返回 ActionType.ShuffleTile 事件
  → View: ShuffleViewAction.DoAction() 播交换动画
```

### 4.2 ExchangeTilePairsPosition 核心逻辑

**文件**: `Services/TileService.cs`

两两一组交换（`i += 2`）：

```
tileList[0] ↔ tileList[1]
tileList[2] ↔ tileList[3]
...
```

每次交换处理：

| 交换项 | 处理方式 |
|-------|---------|
| **Position** | 直接对调 |
| **SequenceId / SequenceIndex** | 对调 |
| **SequenceData 记录** | 同序列内：`ExchangeInSameSequence`；不同序列：`ExchangeFromOneSequence` |
| **Effect（非 Golden）** | 留在原位置不跟随 |
| **Effect（Golden 等）** | 跟随 Tile 移动，重置 Sequence 绑定 |
| **Grid Index** | 清除后重新计算 |
| **HasSeen** | 按新位置的可见性重置 |

---

---

## 四、序列容器类型全览

### 4.1 两套序列配置方式

任何 TileType 理论上都可以成为序列容器，只需在关卡 JSON 中配置以下任一字段：

| 配置方式 | JSON 字段 | 含义 |
|---------|-----------|------|
| **SeqCount 模式** | `"SequenceCount": N` | 动态生成 N 个子牌，花色全为 Random，由算法自动分配 |
| **Sequences 模式** | `"Sequences": [5110, 0, 5140]` | 预定义子牌列表，每个值可以是具体 TileType 或 `0`(Random) |

实际项目中，以下 **11 种** 障碍类型在关卡 JSON 中出现了序列配置：

### 4.2 序列容器清单（按约束策略分两类）

#### A 类 — 有花色去重约束 (SequenceConstraintProfile)

| TileType | 枚举值 | 初始去重 | 洗牌去重 | DDA 去重 | 保护子牌 | 关卡中是否在用 |
|----------|--------|---------|---------|---------|---------|:--:|
| **Flip** (翻转) | 5110 | Prefer | Prefer | None | ✅ | ✅ 大量使用 |
| **CardBox** (卡盒) | 5140 | Prefer | Prefer | None | ✅ | ❌ 未上线 |
| **SuitCaseHorizontal** (行李箱横) | 5130 | Prefer | Prefer | None | ✅ | ❌ 未上线 |
| **SuitCaseVertical** (行李箱竖) | 5131 | Prefer | Prefer | None | ✅ | ❌ 未上线 |

#### B 类 — 无花色去重约束 (DefaultProfile = None)

| TileType | 枚举值 | 约束 | 关卡中是否在用 |
|----------|--------|------|:--:|
| **MagicBox** (魔法盒) | 5010 | 无任何限制 | ✅ (Test/001) |
| **ShellBoxUp** (贝壳盒上) | 5030 | 无任何限制 | ✅ |
| **ShellBoxDown** (贝壳盒下) | 5031 | 无任何限制 | ✅ 大量使用 |
| **ShellBoxLeft** (贝壳盒左) | 5032 | 无任何限制 | ✅ |
| **ShellBoxRight** (贝壳盒右) | 5033 | 无任何限制 | ✅ |
| **JokerFlip** (小丑翻转) | 5150 | 无任何限制 | ✅ (3926, 3950) |
| **Thief** (盗贼盒) | 5160 | 无任何限制 | ✅ (3951, 3960, 3966) |

> **关键差异**：A 类（Flip/CardBox/SuitCase）序列内子牌花色尽量不重复，且 DDA 不交换其子牌；B 类（ShellBox/MagicBox/JokerFlip/Thief）无此限制，可能出现同花色子牌。

### 4.3 序列子牌排列与普通 Tile 的区别

| 维度 | 普通 Tile（FromRandom） | 序列容器 Tile | 序列子牌 Tile |
|------|----------------------|-------------|------------|
| **JSON 配置方式** | 关卡 JSON 直接列出 | 关卡 JSON 直接列出 | **运行时动态追加** 到 `LevelConfig.Tiles` |
| **Position** | JSON 中指定的坐标 | JSON 中指定的坐标 | **与容器共享坐标**（所有子牌同位置） |
| **TileType 来源** | `Random` -> 算法分配 | 固定类型（如 5110） | `Random` -> 算法分配 或 Sequences 中指定 |
| **SequenceSource** | `-1` | `-1` | `= 容器在 Tiles 列表的索引`（指向父级） |
| **SequenceId (TileData)** | `-1`（无序列） | 自身的 `Id` | `= 容器 TileData 的 Id` |
| **FromRandom** | `true` | `false`（固定类型） | `true`（如果花色为 Random） |
| **Board 上表现为** | 一个独立格子 | 一个障碍牌格子 | 共享容器格子的牌面（覆盖/分层） |

**核心点**：序列子牌是运行时动态追加的，不会出现在原始关卡 JSON 中。它们和容器共享同一个 Position，在 `LevelConfig.Tiles` 列表中紧跟在所有原始 Tile 之后。

### 4.4 棋盘上的实际表现

```
原始 JSON Tiles:
  [0] TileType=Random  Pos=(2,3,0)    <- 普通花色 Tile
  [1] TileType=Random  Pos=(4,3,0)    <- 普通花色 Tile
  [2] TileType=5110    Pos=(3,5,0)    <- Flip 容器，SeqCount=2

运行后 Tiles（追加后）:
  [0] TileType=Puppy   Pos=(2,3,0)  SeqSource=-1      <- 已分配花色
  [1] TileType=Kitty   Pos=(4,3,0)  SeqSource=-1      <- 已分配花色
  [2] TileType=Flip    Pos=(3,5,0)  SeqSource=-1      <- 容器本身
  [3] TileType=Bunny   Pos=(3,5,0)  SeqSource=2  Id=105  <- 子牌 0
  [4] TileType=Bear    Pos=(3,5,0)  SeqSource=2  Id=106  <- 子牌 1

SequenceData:
  容器Id(Flip) -> [105, 106]
```

---

## 五、打乱是统一的还是分开的？

**结论：V1 统一打乱，V2 分池打乱。**

### 5.1 V1 策略 (AssignTileTypeStrategy)

```
targetCount = GetRandomTileCount() + GetSequenceRandomTileCount()
            =  普通 Random 牌数   +  序列内 Random 牌数

ShuffleTileType() 对全部 targetCount 个花色索引做一次打乱 ↓

         +-------------------------------------------------+
         |  统一花色队列: [2,0,3,1,0,1,2,2,3,0,1,3]        |  <- 一次打乱
         +-------------------------------------------------+
                      |
          +-----------+-----------+
          v                       v
    普通 FromRandom Tile       序列容器子牌
    (第一轮 for 循环)         (第二、三轮 for 循环)
```

**关键代码**（`AssignTileTypeStrategy.cs` 第 23-25 行）：

```csharp
var count1 = GetRandomTileCount();           // 普通随机牌数
var count2 = GetSequenceRandomTileCount();    // 序列随机牌数
var targetCount = count1 + count2;           // 总和 -> 一个池子
```

然后 `typeIndex` 只生成一份，第一轮和第二轮共用同一个 `typeIndex` 指针递增。

### 5.2 V2 策略 (AssignTileTypeByDepthStrategy)

```
targetCount = GetRandomTileCount() + GetSequenceRandomTileCount()

InitializeTypeIndex(targetCount)  <- 先生成完整的花色队列

然后按阈值 (ShufflePositionThreshold=0.75) 拆成三个池：

  +-----------------+------------------+-----------------+
  |  shufflePool     | deterministicPool |  sequencePool    |
  |  (深层的普通牌)   |  (浅层的普通牌)    |  (序列子牌)       |
  |  Fisher-Yates 洗 |  保持原始顺序       |  Fisher-Yates 洗 |
  +-----------------+------------------+-----------------+
         |                  |                    |
         v                  v                    v
    按深度排序分配        按深度排序分配         按深度排序分配
```

**关键代码**（`AssignTileTypeByDepthStrategy.cs` 第 146-158 行）：

```csharp
PartitionColorsByThrees(colors, tileTypeCount, n1, n2, s,
    out shufflePool, out deterministicPool, out sequencePool);

_gameContext.RandomService.Shuffle(shufflePool);     // 普通牌深池：Fisher-Yates
_gameContext.RandomService.Shuffle(sequencePool);    // 序列子牌池：Fisher-Yates
// deterministicPool 不打乱，保持原始均匀分布

AssignPoolByDepthRank(0, n1, ..., shufflePool, typeIndex);
AssignPoolByDepthRank(n1, count1, ..., deterministicPool, typeIndex);
AssignPoolByDepthRank(count1, targetCount, ..., sequencePool, typeIndex);
```

### 5.3 对比总结

| 维度 | V1 策略 | V2 策略 |
|------|--------|--------|
| **花色池** | 1 个统一池 | 3 个分离池 (shuffle / deterministic / sequence) |
| **打乱算法** | 步频交换（非 Fisher-Yates） | `shufflePool` + `sequencePool` 分别 Fisher-Yates；`deterministicPool` 不打乱 |
| **普通牌 vs 序列牌** | **共享同一份花色顺序**，交替取色 | **各自独立的子池**，序列牌有自己的花色分配和打乱 |
| **分配方式** | 按 Tiles 列表顺序逐次分配 | 按 Tile 覆盖深度排序后分配（深层的更难） |
| **去重约束** | 仅 A 类容器通过 `PrepareNextRandomTypeForSequence` 做 Prefer 级去重 | 同左 |

---

## 六、障碍 Tile 的生成

### 6.1 障碍类型定义（含序列容器标记）

**文件**: `Config/Tile/TileType.cs`

```
障碍枚举（5000 起）：
├─ Rocket        = 5000   火箭
├─ MagicBox      = 5010   魔法盒
├─ Butterfly     = 5020   蝴蝶
├─ ShellBox*     = 5030   贝壳盒 (可含序列)
├─ SlotMachine   = 5050   老虎机
├─ Clock         = 5060   时钟
├─ CandyCube     = 5070   糖果方块
├─ Volcano       = 5080   火山
├─ LightBulb     = 5100   灯泡
├─ Flip          = 5110   翻转 (序列容器)
├─ SodaBox*      = 5120   汽水盒
├─ SuitCase*     = 5130   行李箱 (序列容器)
├─ Switch*       = 5132   开关牌
├─ CardBox       = 5140   卡盒 (序列容器)
├─ JokerFlip     = 5150   小丑翻转
├─ Thief         = 5160   盗贼盒
├─ CandyCubeNx1* = 5180   长条糖果
└─ TrafficLights*= 5200   红绿灯
```

### 6.2 障碍 Tile 的生成方式

障碍 Tile **不是特殊生成的**，它们和普通花色 Tile 一样，都是在关卡 JSON 中预配置好 Position 和 TileType，然后通过统一的 `Board.AddLevelTiles()` → `TileService.CreateTile()` 流程创建。

**区分点**：

- 普通花色Tile：JSON 中 `TileType = Random`，由 `AssignTileTypeStrategy` 在运行时分配具体花色
- 障碍 Tile：JSON 中 `TileType = Flip / CardBox / MagicBox ...`，固定类型，不走花色分配

### 6.3 障碍 Tile 作为序列容器的特殊行为

当障碍 Tile（如 Flip）配置了 `SequenceCount` 或 `Sequences` 时：

1. 花色分配阶段：`RandomizeTileTypeWithLevelConfig()` 为它动态创建子牌块（`SequenceSource` 指向父级索引）
2. `InitializeDataList()` 阶段：子牌块获得父级别的 `SequenceId`
3. `InitializeSequenceControl()` 阶段：建立 `容器Id → [子牌Id列表]` 的映射
4. 游戏中子牌被消除时：`Board.RemoveTile()` 调用 `SequenceControl.RemoveFromOneSequence()` 清理关系

### 6.4 序列约束保护

```
A 类容器（Flip/CardBox/SuitCase）的序列内：
  - 初始分配时尽量花色不重复（Prefer 级别，非强制）
  - DDA 调控时不交换序列子牌（ProtectSequenceChildrenFromDDA = true）
  - 洗牌时交换进入这些序列的 Tile 也会检查花色去重

B 类容器（ShellBox/MagicBox/JokerFlip/Thief）的序列内：
  - 无任何花色约束
  - DDA 可能交换其子牌（无保护）
```

---

## 七、A 类容器详细行为解析

### 7.1 三者对比总览

| 维度 | Flip (5110) | CardBox (5140) | SuitCase (5130/5131) |
|------|------------|----------------|---------------------|
| **是否已上线** | ✅ | ❌ | ❌ |
| **序列变换** | ✅ `Rotate` 循环左移 | ❌ 无变换 | ❌ 无变换 |
| **显示策略** | `FirstNHighlight(1)` — 1 张高亮，其余不可见 | 打开前 `FirstNVisible(1)` / 打开后 `FirstNHighlight(1)` | `FirstNHighlight(3)` — 3 张高亮 |
| **Life 机制** | Life=1，序列空即销毁 | **Life=6**，扣到 0 才"打开"，打开后才能取子牌 | Life=1，变高亮即脱盖 |
| **覆盖穿透** | `CoveredTileIgnoreVisible: false` | `CoveredTileIgnoreVisible: true` | `CoveredTileIgnoreVisible: true` |
| **零血策略** | 默认（死亡销毁） | **`StayAlive`** — 0 血不销毁，需等序列空 | 默认（死亡销毁） |
| **布局** | 1×1 | 1×2 | **3×1 / 1×3**（`SequenceLayoutType: 1`） |
| **花色去重** | Prefer | Prefer | Prefer |
| **DDA 保护子牌** | ✅ | ✅ | ✅ |

### 7.2 Flip（翻转）— 核心机制：Rotate 循环左移

Flip 的本质是一个**循环队列**。每次有牌被点到 Bar（但 Flip 自身序列没变）且 Flip 已经高亮过，就会 `Rotate(1)` 把队首移到队尾。

#### 行为配置解析（Flip.json）

```
行为 5110001 — 初始化序列状态
  触发: LevelEnter 第一步结束
  条件: 序列数 >= 1
  动作: UpdateSequenceState (FirstNHighlight, Count=1)
        → 首个序列牌高亮，后续不可见

行为 5110002 — 点击其他牌时翻转
  触发: AddingToBarByClick（有牌被点到 Bar）
  条件: 自身序列没变(NOT SequenceCountChange)
        + 序列数 >= 2
        + 自身可见(Highlight)
        + 自身未锁定
        + HasBeenHighlighted == true
  动作: LockSelf → TransformSequence(Rotate, FirstNHighlight, Count=1)
        → 锁定自己，循环左移一位，新队首高亮

行为 5110003 — 自身的序列牌被取走时翻转
  触发: AfterAttack / AddingToBarByClick / AutoMatchUse
  条件: SequenceCountChange（自身序列变了）
        + 序列数 >= 1
        + 自身未锁定
  动作: LockSelf → TransformSequence(Rotate, FirstNHighlight, Count=1)
        → 同上

行为 5110004 — 最后一张序列牌被取走
  触发: 同 5110003
  条件: 序列数 <= 1
  动作: PlayDestroyAnim → UpdateSequenceState → DestroyTile
        → 销毁 Flip 容器

行为 5110005 — 序列牌被技能销毁后空序列
  触发: AfterAttack
  条件: 序列数 <= 0
  动作: PlayDestroyAnim → UpdateSequenceState → DestroyTile

行为 5110006 — 标记首次高亮
  触发: TileVisibilityChanged / LevelEnter
  条件: 自身变为 Highlight + 尚未标记
  动作: SetBlackboard(HasBeenHighlighted = true)
```

#### Rotate 变换逻辑

```
TransformSequenceAction.Execute():
  1. 从 SequenceControl.GetSequence(containerTile.Id) 取序列
  2. 过滤 Locked / WillDestroy / InBar 的 Tile
  3. RotateSequenceStrategy.Transform():
     [A, B, C, D] → 移除队首 → [B, C, D, A]
  4. 清空旧序列 → 写入新序列顺序
  5. 更新每个子牌的 SequenceIndex
  6. 用 SequenceDisplayService 重新设置可见性 (FirstNHighlight, Count=1)
  7. 锁定所有序列子牌
```

**关键点**：每次 Rotate 都是 `rotateCount=1`，所以 Flop 的牌永远是一张一张循环的，不存在跳转。

### 7.3 CardBox（卡盒）— 核心机制：Life 护盾 + 破盒开牌

CardBox 和 Flip 完全不同：它**不做序列变换**，而是有一个 Life 护盾（6 血），被打到 0 血才"打开盒子"，然后里面的序列牌才能被取。

#### 行为配置解析（CardBox.json）

```
行为 5140001 — 初始化序列状态
  触发: LevelEnter 第一步结束
  条件: 序列数 >= 1
  动作: UpdateSequenceState (FirstNVisible, Count=1)
        → 显示第一张序列牌（Visible，不可交互）
        注意：是 FirstNVisible 不是 FirstNHighlight！

行为 5140002 — 承受攻击（有血时）
  触发: Attack（被攻击）
  条件: DamageSourceType = 4（特殊伤害源）+ Life >= 1
  动作: HandleAttack（正常扣血）

行为 5140003 — 血量归零时开盒
  触发: Attack
  条件: Life <= 0
  动作: SetBlackboard(CardBox_OpenPending=1) → UpdateSequenceState(FirstNVisible, Count=1)
  标记: Once

行为 5140007 — AfterAttack 高亮序列牌
  触发: AfterAttack
  条件: Life <= 0 + CardBox_OpenPending == 1
  动作: UpdateSequenceState(FirstNHighlight, Count=1)
        → 现在序列牌变为可交互高亮状态！
        + SetBlackboard(CardBox_OpenPending=0)
  标记: Once

行为 5140004 — 保底：无其他可交互牌时自动破盒
  触发: LevelEnter / AddingToBarByClick / AutoMatchUse / ApplicationPendingEnd
  条件: 自身 Highlight + 棋盘无交互牌 + 无锁牌 + Life >= 1
  动作: ChangeTileLives(-999) → UpdateSequenceState(FirstNHighlight, Count=1)
  标记: Once
  说明: 防止死局（所有牌都被 CardBox 挡住取不了）

行为 5140005 — 开盒后子牌被取走时刷新
  触发: AddingToBarByClick / AfterAttack / AutoMatchUse
  条件: Life <= 0 + SequenceCountChange + 序列数 >= 1
  动作: UpdateSequenceState(FirstNHighlight, Count=1)

行为 5140006 — 开盒后序列空时自毁
  触发: 同 5140005
  条件: Life <= 0 + 序列数 <= 0
  动作: PlayDestroyAnim → DestroyTile
  标记: Once
```

#### CardBox 的关键设计意图

```
Life=6 ──────────────→ Life=0 ──────────────→ 序列空
  "闭盒"    攻击扣血    "开盒"    逐个取子牌    销毁
 子牌 Visible         子牌 Highlight
 (不可交互)           (可交互)
```

### 7.4 SuitCase（行李箱）— 核心机制：大格子脱盖

SuitCase 是一个 3×1（横）/ 1×3（竖）的大格子容器，有盖子遮挡。当容器变为 Highlight 时盖子自动脱落，里面的序列牌一次性全部暴露。

#### 行为配置解析（SuitCaseHorizontal.json）

```
行为 5130001 — 初始化序列状态
  触发: LevelEnter 第一步结束
  条件: 序列数 >= 1
  动作: RefreshSequenceState (FirstNHighlight, Count=3)
        → 显示前 3 张序列牌高亮

行为 5130002 — 容器变高亮时脱盖
  触发: TileVisibilityChanged
  条件: 自身变为 Highlight + 序列数 >= 1
  动作: RefreshSequenceState (FirstNHighlight, Count=3)

行为 5130003 — 序列牌全部取走后销毁
  触发: AddingToBarByClick / AfterAttack / AutoMatchUse
  条件: 序列数 <= 0
  动作: PlayDestroyAnim → DestroyTile
  标记: Once

行为 5130004 — 序列牌被技能销毁后空序列
  触发: AfterAttack
  条件: 序列数 <= 0
  动作: PlayDestroyAnim → DestroyTile
  标记: Once
```

#### SuitCase 特点

- 有 `SequenceLayoutType: 1`，子牌按特殊布局排列（横向或纵向一字排开）
- 一次暴露 3 张牌（Count=3），不像 Flip 每次只露 1 张
- 不做序列变换，子牌顺序固定
- 有盖子动画（`PlayCoverRemoveEffect`）

### 7.5 三者核心差异的设计意图

| 设计维度 | Flip | CardBox | SuitCase |
|---------|------|---------|----------|
| **子牌暴露方式** | 逐张循环，Rotate | 先闭盒(Visible)，破盒后 Highlight | 一次性脱盖全暴露 |
| **难度控制** | 序列顺序变化增加不确定性 | 需要特定伤害源攻击 6 次 | 需要先清掉覆盖的牌 |
| **序列变换** | Rotate（循环左移） | 无 | 无 |
| **死局保护** | 无（序列牌必然会露一张） | 有（保底自动破盒） | 无（容器露出来就能取） |

---

## 八、DDA（动态难度调整）与 Tile 交换

### 7.1 触发时机

当 Tile 可见性变化且有牌变为 Highlight/Visible 且未被玩家看到过时，该 Tile 被加入 `regulationList`。然后：

```csharp
Board.InvokeLevelDDA(regulationList)
  → dda.TryExchangeTile(tile)  // 逐个尝试交换
```

### 8.2 DDA 交换过滤

**文件**: `SequenceConstraintHelper.CanTileJoinDDA()`

以下条件**阻止** DDA 交换：
- `IsCanJoinDDA == false`（TileData 标记）
- `TileConfig.Capabilities.CanJoinDDA == false`（配置表禁止）
- `HasSeen == true`（玩家已经看到过的牌）
- 该 Tile 属于一个 `ProtectSequenceChildrenFromDDA` 的序列容器（A类：Flip/CardBox/SuitCase）

---

## 九、总结：关键设计要点

| 维度 | 机制 |
|------|------|
| **花色生成** | 每组 3 个均匀分布 (`GetColors`)，不会出现某花色过多 |
| **花色打乱 (V1)** | 步频交换，普通牌和序列牌**共享一个花色池**，一次打乱，交替取色 |
| **花色打乱 (V2)** | 分三池：shufflePool (Fisher-Yates) + deterministicPool (不打乱) + sequencePool (单独 Fisher-Yates)，按深度分配 |
| **序列容器类型** | 共 11 种：A 类 4 种 (Flip/CardBox/SuitCase) + B 类 7 种 (ShellBox×4/MagicBox/JokerFlip/Thief) |
| **A/B 类区别** | A 类有花色去重 + DDA 保护子牌；B 类无约束 |
| **序列模型** | 一对多父子关系，父 Tile 的 Id = SequenceId，子 Tile 共享此 Id |
| **序列子牌排列** | 运行时动态追加到 Tiles 列表，与容器共享 Position |
| **洗牌道具** | 两两一组交换位置 + 序列信息 + Effect（Golden 跟随），不是随机重排 |
| **障碍生成** | 在关卡 JSON 中预配置，与普通 Tile 走同一套 CreateTile 流程 |
| **Flip 机制** | Rotate 循环左移，每次点击/取牌触发，队首移到队尾；FirstNHighlight(1) 每次只露 1 张 |
| **CardBox 机制** | Life=6 护盾 + 攻击破盒 + 打开后子牌可交互；FirstNVisible→FirstNHighlight 切换；有死局保护 |
| **SuitCase 机制** | 大格子容器 + 变 Highlight 脱盖 + 一次暴露 3 张；无序列变换 |
| **序列变换策略** | Reverse（反转）、Rotate（循环左移 N 位）、Shuffle（Fisher-Yates，SlotMachine 用） |

---

## 十、关键文件索引

| 文件 | 职责 |
|------|------|
| `Config/Level/LevelConfig.cs` | 关卡/牌堆配置数据结构 |
| `GameLogic/TileMatchGameLogic.Config.cs` | 配置→TileData 转换，花色分配入口 |
| `GameLogic/TileMatchGameLogic.EntityInitializer.cs` | 实体初始化入口（Board/Sequence/Bar） |
| `Module/LevelTileType/Strategy/AssignTileTypeStrategy.cs` | 花色生成+打乱核心算法 |
| `Module/LevelTileType/LevelTileTypeInit.cs` | 花色策略选择器 |
| `Entity/Board.cs` | 棋盘 Tile 创建、索引、可见性 |
| `Data/SequenceData.cs` | 序列数据结构 (`Dictionary<long, List<long>>`) |
| `Entity/SequenceControl.cs` | 序列生命周期管理 |
| `Services/SequenceConstraints/SequenceConstraintHelper.cs` | 序列花色去重与 DDA 保护 |
| `Data/TileData.cs` | Tile 数据层（SequenceId/SequenceIndex） |
| `Services/TileService.cs` | Tile 创建/销毁/换牌/序列交换 |
| `Services/SequenceDisplayStrategies/FirstNHighlightStrategy.cs` | 序列显示策略 — 前N张高亮 |
| `Services/SequenceDisplayStrategies/FirstNVisibleStrategy.cs` | 序列显示策略 — 前N张可见 |
| `Services/SequenceDisplayStrategies/IndexHighlightStrategy.cs` | 序列显示策略 — 指定索引高亮 |
| `Behaviours/Action/Implementation/Strategies/ReverseSequenceStrategy.cs` | 序列反转变换 |
| `Behaviours/Action/Implementation/Strategies/RotateSequenceStrategy.cs` | 序列循环左移变换 |
| `Behaviours/Action/Implementation/Strategies/ShuffleSequenceStrategy.cs` | 序列随机打乱变换 |
| `Config/TileConfig/Flip.json` | Flip ECA 行为配置 |
| `Config/TileConfig/CardBox.json` | CardBox ECA 行为配置 |
| `Config/TileConfig/SuitCaseHorizontal.json` | SuitCase ECA 行为配置 |
